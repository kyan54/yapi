webpackJsonp([1,4],{

/***/ 0:
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(89);
	__webpack_require__(151);
	__webpack_require__(651);
	__webpack_require__(1702);
	__webpack_require__(1092);
	__webpack_require__(472);
	__webpack_require__(94);
	__webpack_require__(1551);
	__webpack_require__(1568);
	__webpack_require__(1616);
	__webpack_require__(1630);
	module.exports = __webpack_require__(1635);


/***/ },

/***/ 278:
/***/ function(module, exports, __webpack_require__) {

	var baseHas = __webpack_require__(279),
	    hasPath = __webpack_require__(280);

	/**
	 * Checks if `path` is a direct property of `object`.
	 *
	 * @static
	 * @since 0.1.0
	 * @memberOf _
	 * @category Object
	 * @param {Object} object The object to query.
	 * @param {Array|string} path The path to check.
	 * @returns {boolean} Returns `true` if `path` exists, else `false`.
	 * @example
	 *
	 * var object = { 'a': { 'b': 2 } };
	 * var other = _.create({ 'a': _.create({ 'b': 2 }) });
	 *
	 * _.has(object, 'a');
	 * // => true
	 *
	 * _.has(object, 'a.b');
	 * // => true
	 *
	 * _.has(object, ['a', 'b']);
	 * // => true
	 *
	 * _.has(other, 'a');
	 * // => false
	 */
	function has(object, path) {
	  return object != null && hasPath(object, path, baseHas);
	}

	module.exports = has;


/***/ },

/***/ 279:
/***/ function(module, exports) {

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * The base implementation of `_.has` without support for deep paths.
	 *
	 * @private
	 * @param {Object} [object] The object to query.
	 * @param {Array|string} key The key to check.
	 * @returns {boolean} Returns `true` if `key` exists, else `false`.
	 */
	function baseHas(object, key) {
	  return object != null && hasOwnProperty.call(object, key);
	}

	module.exports = baseHas;


/***/ },

/***/ 369:
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Copyright 2014-2015, Facebook, Inc.
	 * All rights reserved.
	 *
	 * This source code is licensed under the BSD-style license found in the
	 * LICENSE file in the root directory of this source tree. An additional grant
	 * of patent rights can be found in the PATENTS file in the same directory.
	 */

	'use strict';

	/**
	 * Similar to invariant but only logs a warning if the condition is not met.
	 * This can be used to log issues in development environments in critical
	 * paths. Removing the logging code for production environments will keep the
	 * same logic and follow the same code paths.
	 */

	var warning = function() {};

	if (false) {
	  warning = function(condition, format, args) {
	    var len = arguments.length;
	    args = new Array(len > 2 ? len - 2 : 0);
	    for (var key = 2; key < len; key++) {
	      args[key - 2] = arguments[key];
	    }
	    if (format === undefined) {
	      throw new Error(
	        '`warning(condition, format, ...args)` requires a warning ' +
	        'message argument'
	      );
	    }

	    if (format.length < 10 || (/^[s\W]*$/).test(format)) {
	      throw new Error(
	        'The warning format should be able to uniquely identify this ' +
	        'warning. Please, use a more descriptive format than: ' + format
	      );
	    }

	    if (!condition) {
	      var argIndex = 0;
	      var message = 'Warning: ' +
	        format.replace(/%s/g, function() {
	          return args[argIndex++];
	        });
	      if (typeof console !== 'undefined') {
	        console.error(message);
	      }
	      try {
	        // This error was thrown as a convenience so that you can use this stack
	        // to find the callsite that caused this warning to fire.
	        throw new Error(message);
	      } catch(x) {}
	    }
	  };
	}

	module.exports = warning;


/***/ },

/***/ 374:
/***/ function(module, exports, __webpack_require__) {

	var baseAssignValue = __webpack_require__(375),
	    eq = __webpack_require__(316);

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Assigns `value` to `key` of `object` if the existing value is not equivalent
	 * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
	 * for equality comparisons.
	 *
	 * @private
	 * @param {Object} object The object to modify.
	 * @param {string} key The key of the property to assign.
	 * @param {*} value The value to assign.
	 */
	function assignValue(object, key, value) {
	  var objValue = object[key];
	  if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) ||
	      (value === undefined && !(key in object))) {
	    baseAssignValue(object, key, value);
	  }
	}

	module.exports = assignValue;


/***/ },

/***/ 375:
/***/ function(module, exports, __webpack_require__) {

	var defineProperty = __webpack_require__(376);

	/**
	 * The base implementation of `assignValue` and `assignMergeValue` without
	 * value checks.
	 *
	 * @private
	 * @param {Object} object The object to modify.
	 * @param {string} key The key of the property to assign.
	 * @param {*} value The value to assign.
	 */
	function baseAssignValue(object, key, value) {
	  if (key == '__proto__' && defineProperty) {
	    defineProperty(object, key, {
	      'configurable': true,
	      'enumerable': true,
	      'value': value,
	      'writable': true
	    });
	  } else {
	    object[key] = value;
	  }
	}

	module.exports = baseAssignValue;


/***/ },

/***/ 380:
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Copyright 2015, Yahoo! Inc.
	 * Copyrights licensed under the New BSD License. See the accompanying LICENSE file for terms.
	 */
	(function (global, factory) {
	     true ? module.exports = factory() :
	    typeof define === 'function' && define.amd ? define(factory) :
	    (global.hoistNonReactStatics = factory());
	}(this, (function () {
	    'use strict';
	    
	    var REACT_STATICS = {
	        childContextTypes: true,
	        contextTypes: true,
	        defaultProps: true,
	        displayName: true,
	        getDefaultProps: true,
	        getDerivedStateFromProps: true,
	        mixins: true,
	        propTypes: true,
	        type: true
	    };
	    
	    var KNOWN_STATICS = {
	        name: true,
	        length: true,
	        prototype: true,
	        caller: true,
	        callee: true,
	        arguments: true,
	        arity: true
	    };
	    
	    var defineProperty = Object.defineProperty;
	    var getOwnPropertyNames = Object.getOwnPropertyNames;
	    var getOwnPropertySymbols = Object.getOwnPropertySymbols;
	    var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
	    var getPrototypeOf = Object.getPrototypeOf;
	    var objectPrototype = getPrototypeOf && getPrototypeOf(Object);
	    
	    return function hoistNonReactStatics(targetComponent, sourceComponent, blacklist) {
	        if (typeof sourceComponent !== 'string') { // don't hoist over string (html) components
	            
	            if (objectPrototype) {
	                var inheritedComponent = getPrototypeOf(sourceComponent);
	                if (inheritedComponent && inheritedComponent !== objectPrototype) {
	                    hoistNonReactStatics(targetComponent, inheritedComponent, blacklist);
	                }
	            }
	            
	            var keys = getOwnPropertyNames(sourceComponent);
	            
	            if (getOwnPropertySymbols) {
	                keys = keys.concat(getOwnPropertySymbols(sourceComponent));
	            }
	            
	            for (var i = 0; i < keys.length; ++i) {
	                var key = keys[i];
	                if (!REACT_STATICS[key] && !KNOWN_STATICS[key] && (!blacklist || !blacklist[key])) {
	                    var descriptor = getOwnPropertyDescriptor(sourceComponent, key);
	                    try { // Avoid failures from read-only properties
	                        defineProperty(targetComponent, key, descriptor);
	                    } catch (e) {}
	                }
	            }
	            
	            return targetComponent;
	        }
	        
	        return targetComponent;
	    };
	})));


/***/ },

/***/ 386:
/***/ function(module, exports) {

	/**
	 * lodash (Custom Build) <https://lodash.com/>
	 * Build: `lodash modularize exports="npm" -o ./`
	 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
	 * Released under MIT license <https://lodash.com/license>
	 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
	 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
	 */

	/** Used as references for various `Number` constants. */
	var MAX_SAFE_INTEGER = 9007199254740991;

	/** `Object#toString` result references. */
	var argsTag = '[object Arguments]',
	    funcTag = '[object Function]',
	    genTag = '[object GeneratorFunction]';

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Used to resolve the
	 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
	 * of values.
	 */
	var objectToString = objectProto.toString;

	/** Built-in value references. */
	var propertyIsEnumerable = objectProto.propertyIsEnumerable;

	/**
	 * Checks if `value` is likely an `arguments` object.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
	 *  else `false`.
	 * @example
	 *
	 * _.isArguments(function() { return arguments; }());
	 * // => true
	 *
	 * _.isArguments([1, 2, 3]);
	 * // => false
	 */
	function isArguments(value) {
	  // Safari 8.1 makes `arguments.callee` enumerable in strict mode.
	  return isArrayLikeObject(value) && hasOwnProperty.call(value, 'callee') &&
	    (!propertyIsEnumerable.call(value, 'callee') || objectToString.call(value) == argsTag);
	}

	/**
	 * Checks if `value` is array-like. A value is considered array-like if it's
	 * not a function and has a `value.length` that's an integer greater than or
	 * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
	 * @example
	 *
	 * _.isArrayLike([1, 2, 3]);
	 * // => true
	 *
	 * _.isArrayLike(document.body.children);
	 * // => true
	 *
	 * _.isArrayLike('abc');
	 * // => true
	 *
	 * _.isArrayLike(_.noop);
	 * // => false
	 */
	function isArrayLike(value) {
	  return value != null && isLength(value.length) && !isFunction(value);
	}

	/**
	 * This method is like `_.isArrayLike` except that it also checks if `value`
	 * is an object.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is an array-like object,
	 *  else `false`.
	 * @example
	 *
	 * _.isArrayLikeObject([1, 2, 3]);
	 * // => true
	 *
	 * _.isArrayLikeObject(document.body.children);
	 * // => true
	 *
	 * _.isArrayLikeObject('abc');
	 * // => false
	 *
	 * _.isArrayLikeObject(_.noop);
	 * // => false
	 */
	function isArrayLikeObject(value) {
	  return isObjectLike(value) && isArrayLike(value);
	}

	/**
	 * Checks if `value` is classified as a `Function` object.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
	 * @example
	 *
	 * _.isFunction(_);
	 * // => true
	 *
	 * _.isFunction(/abc/);
	 * // => false
	 */
	function isFunction(value) {
	  // The use of `Object#toString` avoids issues with the `typeof` operator
	  // in Safari 8-9 which returns 'object' for typed array and other constructors.
	  var tag = isObject(value) ? objectToString.call(value) : '';
	  return tag == funcTag || tag == genTag;
	}

	/**
	 * Checks if `value` is a valid array-like length.
	 *
	 * **Note:** This method is loosely based on
	 * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
	 * @example
	 *
	 * _.isLength(3);
	 * // => true
	 *
	 * _.isLength(Number.MIN_VALUE);
	 * // => false
	 *
	 * _.isLength(Infinity);
	 * // => false
	 *
	 * _.isLength('3');
	 * // => false
	 */
	function isLength(value) {
	  return typeof value == 'number' &&
	    value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
	}

	/**
	 * Checks if `value` is the
	 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
	 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
	 * @example
	 *
	 * _.isObject({});
	 * // => true
	 *
	 * _.isObject([1, 2, 3]);
	 * // => true
	 *
	 * _.isObject(_.noop);
	 * // => true
	 *
	 * _.isObject(null);
	 * // => false
	 */
	function isObject(value) {
	  var type = typeof value;
	  return !!value && (type == 'object' || type == 'function');
	}

	/**
	 * Checks if `value` is object-like. A value is object-like if it's not `null`
	 * and has a `typeof` result of "object".
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
	 * @example
	 *
	 * _.isObjectLike({});
	 * // => true
	 *
	 * _.isObjectLike([1, 2, 3]);
	 * // => true
	 *
	 * _.isObjectLike(_.noop);
	 * // => false
	 *
	 * _.isObjectLike(null);
	 * // => false
	 */
	function isObjectLike(value) {
	  return !!value && typeof value == 'object';
	}

	module.exports = isArguments;


/***/ },

/***/ 387:
/***/ function(module, exports) {

	/**
	 * lodash 3.0.4 (Custom Build) <https://lodash.com/>
	 * Build: `lodash modern modularize exports="npm" -o ./`
	 * Copyright 2012-2015 The Dojo Foundation <http://dojofoundation.org/>
	 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
	 * Copyright 2009-2015 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
	 * Available under MIT license <https://lodash.com/license>
	 */

	/** `Object#toString` result references. */
	var arrayTag = '[object Array]',
	    funcTag = '[object Function]';

	/** Used to detect host constructors (Safari > 5). */
	var reIsHostCtor = /^\[object .+?Constructor\]$/;

	/**
	 * Checks if `value` is object-like.
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
	 */
	function isObjectLike(value) {
	  return !!value && typeof value == 'object';
	}

	/** Used for native method references. */
	var objectProto = Object.prototype;

	/** Used to resolve the decompiled source of functions. */
	var fnToString = Function.prototype.toString;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Used to resolve the [`toStringTag`](http://ecma-international.org/ecma-262/6.0/#sec-object.prototype.tostring)
	 * of values.
	 */
	var objToString = objectProto.toString;

	/** Used to detect if a method is native. */
	var reIsNative = RegExp('^' +
	  fnToString.call(hasOwnProperty).replace(/[\\^$.*+?()[\]{}|]/g, '\\$&')
	  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
	);

	/* Native method references for those with the same name as other `lodash` methods. */
	var nativeIsArray = getNative(Array, 'isArray');

	/**
	 * Used as the [maximum length](http://ecma-international.org/ecma-262/6.0/#sec-number.max_safe_integer)
	 * of an array-like value.
	 */
	var MAX_SAFE_INTEGER = 9007199254740991;

	/**
	 * Gets the native function at `key` of `object`.
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @param {string} key The key of the method to get.
	 * @returns {*} Returns the function if it's native, else `undefined`.
	 */
	function getNative(object, key) {
	  var value = object == null ? undefined : object[key];
	  return isNative(value) ? value : undefined;
	}

	/**
	 * Checks if `value` is a valid array-like length.
	 *
	 * **Note:** This function is based on [`ToLength`](http://ecma-international.org/ecma-262/6.0/#sec-tolength).
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
	 */
	function isLength(value) {
	  return typeof value == 'number' && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
	}

	/**
	 * Checks if `value` is classified as an `Array` object.
	 *
	 * @static
	 * @memberOf _
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is correctly classified, else `false`.
	 * @example
	 *
	 * _.isArray([1, 2, 3]);
	 * // => true
	 *
	 * _.isArray(function() { return arguments; }());
	 * // => false
	 */
	var isArray = nativeIsArray || function(value) {
	  return isObjectLike(value) && isLength(value.length) && objToString.call(value) == arrayTag;
	};

	/**
	 * Checks if `value` is classified as a `Function` object.
	 *
	 * @static
	 * @memberOf _
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is correctly classified, else `false`.
	 * @example
	 *
	 * _.isFunction(_);
	 * // => true
	 *
	 * _.isFunction(/abc/);
	 * // => false
	 */
	function isFunction(value) {
	  // The use of `Object#toString` avoids issues with the `typeof` operator
	  // in older versions of Chrome and Safari which return 'function' for regexes
	  // and Safari 8 equivalents which return 'object' for typed array constructors.
	  return isObject(value) && objToString.call(value) == funcTag;
	}

	/**
	 * Checks if `value` is the [language type](https://es5.github.io/#x8) of `Object`.
	 * (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
	 *
	 * @static
	 * @memberOf _
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
	 * @example
	 *
	 * _.isObject({});
	 * // => true
	 *
	 * _.isObject([1, 2, 3]);
	 * // => true
	 *
	 * _.isObject(1);
	 * // => false
	 */
	function isObject(value) {
	  // Avoid a V8 JIT bug in Chrome 19-20.
	  // See https://code.google.com/p/v8/issues/detail?id=2291 for more details.
	  var type = typeof value;
	  return !!value && (type == 'object' || type == 'function');
	}

	/**
	 * Checks if `value` is a native function.
	 *
	 * @static
	 * @memberOf _
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a native function, else `false`.
	 * @example
	 *
	 * _.isNative(Array.prototype.push);
	 * // => true
	 *
	 * _.isNative(_);
	 * // => false
	 */
	function isNative(value) {
	  if (value == null) {
	    return false;
	  }
	  if (isFunction(value)) {
	    return reIsNative.test(fnToString.call(value));
	  }
	  return isObjectLike(value) && reIsHostCtor.test(value);
	}

	module.exports = isArray;


/***/ },

/***/ 472:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.withRouter = exports.matchPath = exports.Switch = exports.StaticRouter = exports.Router = exports.Route = exports.Redirect = exports.Prompt = exports.NavLink = exports.MemoryRouter = exports.Link = exports.HashRouter = exports.BrowserRouter = undefined;

	var _BrowserRouter2 = __webpack_require__(473);

	var _BrowserRouter3 = _interopRequireDefault(_BrowserRouter2);

	var _HashRouter2 = __webpack_require__(484);

	var _HashRouter3 = _interopRequireDefault(_HashRouter2);

	var _Link2 = __webpack_require__(486);

	var _Link3 = _interopRequireDefault(_Link2);

	var _MemoryRouter2 = __webpack_require__(487);

	var _MemoryRouter3 = _interopRequireDefault(_MemoryRouter2);

	var _NavLink2 = __webpack_require__(490);

	var _NavLink3 = _interopRequireDefault(_NavLink2);

	var _Prompt2 = __webpack_require__(496);

	var _Prompt3 = _interopRequireDefault(_Prompt2);

	var _Redirect2 = __webpack_require__(498);

	var _Redirect3 = _interopRequireDefault(_Redirect2);

	var _Route2 = __webpack_require__(491);

	var _Route3 = _interopRequireDefault(_Route2);

	var _Router2 = __webpack_require__(482);

	var _Router3 = _interopRequireDefault(_Router2);

	var _StaticRouter2 = __webpack_require__(501);

	var _StaticRouter3 = _interopRequireDefault(_StaticRouter2);

	var _Switch2 = __webpack_require__(503);

	var _Switch3 = _interopRequireDefault(_Switch2);

	var _matchPath2 = __webpack_require__(505);

	var _matchPath3 = _interopRequireDefault(_matchPath2);

	var _withRouter2 = __webpack_require__(506);

	var _withRouter3 = _interopRequireDefault(_withRouter2);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.BrowserRouter = _BrowserRouter3.default;
	exports.HashRouter = _HashRouter3.default;
	exports.Link = _Link3.default;
	exports.MemoryRouter = _MemoryRouter3.default;
	exports.NavLink = _NavLink3.default;
	exports.Prompt = _Prompt3.default;
	exports.Redirect = _Redirect3.default;
	exports.Route = _Route3.default;
	exports.Router = _Router3.default;
	exports.StaticRouter = _StaticRouter3.default;
	exports.Switch = _Switch3.default;
	exports.matchPath = _matchPath3.default;
	exports.withRouter = _withRouter3.default;

/***/ },

/***/ 473:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _createBrowserHistory = __webpack_require__(474);

	var _createBrowserHistory2 = _interopRequireDefault(_createBrowserHistory);

	var _Router = __webpack_require__(482);

	var _Router2 = _interopRequireDefault(_Router);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for a <Router> that uses HTML5 history.
	 */
	var BrowserRouter = function (_React$Component) {
	  _inherits(BrowserRouter, _React$Component);

	  function BrowserRouter() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, BrowserRouter);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.history = (0, _createBrowserHistory2.default)(_this.props), _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  BrowserRouter.prototype.componentWillMount = function componentWillMount() {
	    (0, _warning2.default)(!this.props.history, '<BrowserRouter> ignores the history prop. To use a custom history, ' + 'use `import { Router }` instead of `import { BrowserRouter as Router }`.');
	  };

	  BrowserRouter.prototype.render = function render() {
	    return _react2.default.createElement(_Router2.default, { history: this.history, children: this.props.children });
	  };

	  return BrowserRouter;
	}(_react2.default.Component);

	BrowserRouter.propTypes = {
	  basename: _propTypes2.default.string,
	  forceRefresh: _propTypes2.default.bool,
	  getUserConfirmation: _propTypes2.default.func,
	  keyLength: _propTypes2.default.number,
	  children: _propTypes2.default.node
	};
	exports.default = BrowserRouter;

/***/ },

/***/ 474:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _LocationUtils = __webpack_require__(476);

	var _PathUtils = __webpack_require__(479);

	var _createTransitionManager = __webpack_require__(480);

	var _createTransitionManager2 = _interopRequireDefault(_createTransitionManager);

	var _DOMUtils = __webpack_require__(481);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var PopStateEvent = 'popstate';
	var HashChangeEvent = 'hashchange';

	var getHistoryState = function getHistoryState() {
	  try {
	    return window.history.state || {};
	  } catch (e) {
	    // IE 11 sometimes throws when accessing window.history.state
	    // See https://github.com/ReactTraining/history/pull/289
	    return {};
	  }
	};

	/**
	 * Creates a history object that uses the HTML5 history API including
	 * pushState, replaceState, and the popstate event.
	 */
	var createBrowserHistory = function createBrowserHistory() {
	  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

	  (0, _invariant2.default)(_DOMUtils.canUseDOM, 'Browser history needs a DOM');

	  var globalHistory = window.history;
	  var canUseHistory = (0, _DOMUtils.supportsHistory)();
	  var needsHashChangeListener = !(0, _DOMUtils.supportsPopStateOnHashChange)();

	  var _props$forceRefresh = props.forceRefresh,
	      forceRefresh = _props$forceRefresh === undefined ? false : _props$forceRefresh,
	      _props$getUserConfirm = props.getUserConfirmation,
	      getUserConfirmation = _props$getUserConfirm === undefined ? _DOMUtils.getConfirmation : _props$getUserConfirm,
	      _props$keyLength = props.keyLength,
	      keyLength = _props$keyLength === undefined ? 6 : _props$keyLength;

	  var basename = props.basename ? (0, _PathUtils.stripTrailingSlash)((0, _PathUtils.addLeadingSlash)(props.basename)) : '';

	  var getDOMLocation = function getDOMLocation(historyState) {
	    var _ref = historyState || {},
	        key = _ref.key,
	        state = _ref.state;

	    var _window$location = window.location,
	        pathname = _window$location.pathname,
	        search = _window$location.search,
	        hash = _window$location.hash;


	    var path = pathname + search + hash;

	    (0, _warning2.default)(!basename || (0, _PathUtils.hasBasename)(path, basename), 'You are attempting to use a basename on a page whose URL path does not begin ' + 'with the basename. Expected path "' + path + '" to begin with "' + basename + '".');

	    if (basename) path = (0, _PathUtils.stripBasename)(path, basename);

	    return (0, _LocationUtils.createLocation)(path, state, key);
	  };

	  var createKey = function createKey() {
	    return Math.random().toString(36).substr(2, keyLength);
	  };

	  var transitionManager = (0, _createTransitionManager2.default)();

	  var setState = function setState(nextState) {
	    _extends(history, nextState);

	    history.length = globalHistory.length;

	    transitionManager.notifyListeners(history.location, history.action);
	  };

	  var handlePopState = function handlePopState(event) {
	    // Ignore extraneous popstate events in WebKit.
	    if ((0, _DOMUtils.isExtraneousPopstateEvent)(event)) return;

	    handlePop(getDOMLocation(event.state));
	  };

	  var handleHashChange = function handleHashChange() {
	    handlePop(getDOMLocation(getHistoryState()));
	  };

	  var forceNextPop = false;

	  var handlePop = function handlePop(location) {
	    if (forceNextPop) {
	      forceNextPop = false;
	      setState();
	    } else {
	      var action = 'POP';

	      transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	        if (ok) {
	          setState({ action: action, location: location });
	        } else {
	          revertPop(location);
	        }
	      });
	    }
	  };

	  var revertPop = function revertPop(fromLocation) {
	    var toLocation = history.location;

	    // TODO: We could probably make this more reliable by
	    // keeping a list of keys we've seen in sessionStorage.
	    // Instead, we just default to 0 for keys we don't know.

	    var toIndex = allKeys.indexOf(toLocation.key);

	    if (toIndex === -1) toIndex = 0;

	    var fromIndex = allKeys.indexOf(fromLocation.key);

	    if (fromIndex === -1) fromIndex = 0;

	    var delta = toIndex - fromIndex;

	    if (delta) {
	      forceNextPop = true;
	      go(delta);
	    }
	  };

	  var initialLocation = getDOMLocation(getHistoryState());
	  var allKeys = [initialLocation.key];

	  // Public interface

	  var createHref = function createHref(location) {
	    return basename + (0, _PathUtils.createPath)(location);
	  };

	  var push = function push(path, state) {
	    (0, _warning2.default)(!((typeof path === 'undefined' ? 'undefined' : _typeof(path)) === 'object' && path.state !== undefined && state !== undefined), 'You should avoid providing a 2nd state argument to push when the 1st ' + 'argument is a location-like object that already has state; it is ignored');

	    var action = 'PUSH';
	    var location = (0, _LocationUtils.createLocation)(path, state, createKey(), history.location);

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (!ok) return;

	      var href = createHref(location);
	      var key = location.key,
	          state = location.state;


	      if (canUseHistory) {
	        globalHistory.pushState({ key: key, state: state }, null, href);

	        if (forceRefresh) {
	          window.location.href = href;
	        } else {
	          var prevIndex = allKeys.indexOf(history.location.key);
	          var nextKeys = allKeys.slice(0, prevIndex === -1 ? 0 : prevIndex + 1);

	          nextKeys.push(location.key);
	          allKeys = nextKeys;

	          setState({ action: action, location: location });
	        }
	      } else {
	        (0, _warning2.default)(state === undefined, 'Browser history cannot push state in browsers that do not support HTML5 history');

	        window.location.href = href;
	      }
	    });
	  };

	  var replace = function replace(path, state) {
	    (0, _warning2.default)(!((typeof path === 'undefined' ? 'undefined' : _typeof(path)) === 'object' && path.state !== undefined && state !== undefined), 'You should avoid providing a 2nd state argument to replace when the 1st ' + 'argument is a location-like object that already has state; it is ignored');

	    var action = 'REPLACE';
	    var location = (0, _LocationUtils.createLocation)(path, state, createKey(), history.location);

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (!ok) return;

	      var href = createHref(location);
	      var key = location.key,
	          state = location.state;


	      if (canUseHistory) {
	        globalHistory.replaceState({ key: key, state: state }, null, href);

	        if (forceRefresh) {
	          window.location.replace(href);
	        } else {
	          var prevIndex = allKeys.indexOf(history.location.key);

	          if (prevIndex !== -1) allKeys[prevIndex] = location.key;

	          setState({ action: action, location: location });
	        }
	      } else {
	        (0, _warning2.default)(state === undefined, 'Browser history cannot replace state in browsers that do not support HTML5 history');

	        window.location.replace(href);
	      }
	    });
	  };

	  var go = function go(n) {
	    globalHistory.go(n);
	  };

	  var goBack = function goBack() {
	    return go(-1);
	  };

	  var goForward = function goForward() {
	    return go(1);
	  };

	  var listenerCount = 0;

	  var checkDOMListeners = function checkDOMListeners(delta) {
	    listenerCount += delta;

	    if (listenerCount === 1) {
	      (0, _DOMUtils.addEventListener)(window, PopStateEvent, handlePopState);

	      if (needsHashChangeListener) (0, _DOMUtils.addEventListener)(window, HashChangeEvent, handleHashChange);
	    } else if (listenerCount === 0) {
	      (0, _DOMUtils.removeEventListener)(window, PopStateEvent, handlePopState);

	      if (needsHashChangeListener) (0, _DOMUtils.removeEventListener)(window, HashChangeEvent, handleHashChange);
	    }
	  };

	  var isBlocked = false;

	  var block = function block() {
	    var prompt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

	    var unblock = transitionManager.setPrompt(prompt);

	    if (!isBlocked) {
	      checkDOMListeners(1);
	      isBlocked = true;
	    }

	    return function () {
	      if (isBlocked) {
	        isBlocked = false;
	        checkDOMListeners(-1);
	      }

	      return unblock();
	    };
	  };

	  var listen = function listen(listener) {
	    var unlisten = transitionManager.appendListener(listener);
	    checkDOMListeners(1);

	    return function () {
	      checkDOMListeners(-1);
	      unlisten();
	    };
	  };

	  var history = {
	    length: globalHistory.length,
	    action: 'POP',
	    location: initialLocation,
	    createHref: createHref,
	    push: push,
	    replace: replace,
	    go: go,
	    goBack: goBack,
	    goForward: goForward,
	    block: block,
	    listen: listen
	  };

	  return history;
	};

	exports.default = createBrowserHistory;

/***/ },

/***/ 475:
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Copyright (c) 2013-present, Facebook, Inc.
	 *
	 * This source code is licensed under the MIT license found in the
	 * LICENSE file in the root directory of this source tree.
	 */

	'use strict';

	/**
	 * Use invariant() to assert state which your program assumes to be true.
	 *
	 * Provide sprintf-style format (only %s is supported) and arguments
	 * to provide information about what broke and what you were
	 * expecting.
	 *
	 * The invariant message will be stripped in production, but the invariant
	 * will remain to ensure logic does not differ in production.
	 */

	var invariant = function(condition, format, a, b, c, d, e, f) {
	  if (false) {
	    if (format === undefined) {
	      throw new Error('invariant requires an error message argument');
	    }
	  }

	  if (!condition) {
	    var error;
	    if (format === undefined) {
	      error = new Error(
	        'Minified exception occurred; use the non-minified dev environment ' +
	        'for the full error message and additional helpful warnings.'
	      );
	    } else {
	      var args = [a, b, c, d, e, f];
	      var argIndex = 0;
	      error = new Error(
	        format.replace(/%s/g, function() { return args[argIndex++]; })
	      );
	      error.name = 'Invariant Violation';
	    }

	    error.framesToPop = 1; // we don't care about invariant's own frame
	    throw error;
	  }
	};

	module.exports = invariant;


/***/ },

/***/ 476:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.locationsAreEqual = exports.createLocation = undefined;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _resolvePathname = __webpack_require__(477);

	var _resolvePathname2 = _interopRequireDefault(_resolvePathname);

	var _valueEqual = __webpack_require__(478);

	var _valueEqual2 = _interopRequireDefault(_valueEqual);

	var _PathUtils = __webpack_require__(479);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var createLocation = exports.createLocation = function createLocation(path, state, key, currentLocation) {
	  var location = void 0;
	  if (typeof path === 'string') {
	    // Two-arg form: push(path, state)
	    location = (0, _PathUtils.parsePath)(path);
	    location.state = state;
	  } else {
	    // One-arg form: push(location)
	    location = _extends({}, path);

	    if (location.pathname === undefined) location.pathname = '';

	    if (location.search) {
	      if (location.search.charAt(0) !== '?') location.search = '?' + location.search;
	    } else {
	      location.search = '';
	    }

	    if (location.hash) {
	      if (location.hash.charAt(0) !== '#') location.hash = '#' + location.hash;
	    } else {
	      location.hash = '';
	    }

	    if (state !== undefined && location.state === undefined) location.state = state;
	  }

	  try {
	    location.pathname = decodeURI(location.pathname);
	  } catch (e) {
	    if (e instanceof URIError) {
	      throw new URIError('Pathname "' + location.pathname + '" could not be decoded. ' + 'This is likely caused by an invalid percent-encoding.');
	    } else {
	      throw e;
	    }
	  }

	  if (key) location.key = key;

	  if (currentLocation) {
	    // Resolve incomplete/relative pathname relative to current location.
	    if (!location.pathname) {
	      location.pathname = currentLocation.pathname;
	    } else if (location.pathname.charAt(0) !== '/') {
	      location.pathname = (0, _resolvePathname2.default)(location.pathname, currentLocation.pathname);
	    }
	  } else {
	    // When there is no prior location and pathname is empty, set it to /
	    if (!location.pathname) {
	      location.pathname = '/';
	    }
	  }

	  return location;
	};

	var locationsAreEqual = exports.locationsAreEqual = function locationsAreEqual(a, b) {
	  return a.pathname === b.pathname && a.search === b.search && a.hash === b.hash && a.key === b.key && (0, _valueEqual2.default)(a.state, b.state);
	};

/***/ },

/***/ 477:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;
	function isAbsolute(pathname) {
	  return pathname.charAt(0) === '/';
	}

	// About 1.5x faster than the two-arg version of Array#splice()
	function spliceOne(list, index) {
	  for (var i = index, k = i + 1, n = list.length; k < n; i += 1, k += 1) {
	    list[i] = list[k];
	  }

	  list.pop();
	}

	// This implementation is based heavily on node's url.parse
	function resolvePathname(to) {
	  var from = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

	  var toParts = to && to.split('/') || [];
	  var fromParts = from && from.split('/') || [];

	  var isToAbs = to && isAbsolute(to);
	  var isFromAbs = from && isAbsolute(from);
	  var mustEndAbs = isToAbs || isFromAbs;

	  if (to && isAbsolute(to)) {
	    // to is absolute
	    fromParts = toParts;
	  } else if (toParts.length) {
	    // to is relative, drop the filename
	    fromParts.pop();
	    fromParts = fromParts.concat(toParts);
	  }

	  if (!fromParts.length) return '/';

	  var hasTrailingSlash = void 0;
	  if (fromParts.length) {
	    var last = fromParts[fromParts.length - 1];
	    hasTrailingSlash = last === '.' || last === '..' || last === '';
	  } else {
	    hasTrailingSlash = false;
	  }

	  var up = 0;
	  for (var i = fromParts.length; i >= 0; i--) {
	    var part = fromParts[i];

	    if (part === '.') {
	      spliceOne(fromParts, i);
	    } else if (part === '..') {
	      spliceOne(fromParts, i);
	      up++;
	    } else if (up) {
	      spliceOne(fromParts, i);
	      up--;
	    }
	  }

	  if (!mustEndAbs) for (; up--; up) {
	    fromParts.unshift('..');
	  }if (mustEndAbs && fromParts[0] !== '' && (!fromParts[0] || !isAbsolute(fromParts[0]))) fromParts.unshift('');

	  var result = fromParts.join('/');

	  if (hasTrailingSlash && result.substr(-1) !== '/') result += '/';

	  return result;
	}

	exports.default = resolvePathname;
	module.exports = exports['default'];

/***/ },

/***/ 478:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	function valueEqual(a, b) {
	  if (a === b) return true;

	  if (a == null || b == null) return false;

	  if (Array.isArray(a)) {
	    return Array.isArray(b) && a.length === b.length && a.every(function (item, index) {
	      return valueEqual(item, b[index]);
	    });
	  }

	  var aType = typeof a === 'undefined' ? 'undefined' : _typeof(a);
	  var bType = typeof b === 'undefined' ? 'undefined' : _typeof(b);

	  if (aType !== bType) return false;

	  if (aType === 'object') {
	    var aValue = a.valueOf();
	    var bValue = b.valueOf();

	    if (aValue !== a || bValue !== b) return valueEqual(aValue, bValue);

	    var aKeys = Object.keys(a);
	    var bKeys = Object.keys(b);

	    if (aKeys.length !== bKeys.length) return false;

	    return aKeys.every(function (key) {
	      return valueEqual(a[key], b[key]);
	    });
	  }

	  return false;
	}

	exports.default = valueEqual;
	module.exports = exports['default'];

/***/ },

/***/ 479:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;
	var addLeadingSlash = exports.addLeadingSlash = function addLeadingSlash(path) {
	  return path.charAt(0) === '/' ? path : '/' + path;
	};

	var stripLeadingSlash = exports.stripLeadingSlash = function stripLeadingSlash(path) {
	  return path.charAt(0) === '/' ? path.substr(1) : path;
	};

	var hasBasename = exports.hasBasename = function hasBasename(path, prefix) {
	  return new RegExp('^' + prefix + '(\\/|\\?|#|$)', 'i').test(path);
	};

	var stripBasename = exports.stripBasename = function stripBasename(path, prefix) {
	  return hasBasename(path, prefix) ? path.substr(prefix.length) : path;
	};

	var stripTrailingSlash = exports.stripTrailingSlash = function stripTrailingSlash(path) {
	  return path.charAt(path.length - 1) === '/' ? path.slice(0, -1) : path;
	};

	var parsePath = exports.parsePath = function parsePath(path) {
	  var pathname = path || '/';
	  var search = '';
	  var hash = '';

	  var hashIndex = pathname.indexOf('#');
	  if (hashIndex !== -1) {
	    hash = pathname.substr(hashIndex);
	    pathname = pathname.substr(0, hashIndex);
	  }

	  var searchIndex = pathname.indexOf('?');
	  if (searchIndex !== -1) {
	    search = pathname.substr(searchIndex);
	    pathname = pathname.substr(0, searchIndex);
	  }

	  return {
	    pathname: pathname,
	    search: search === '?' ? '' : search,
	    hash: hash === '#' ? '' : hash
	  };
	};

	var createPath = exports.createPath = function createPath(location) {
	  var pathname = location.pathname,
	      search = location.search,
	      hash = location.hash;


	  var path = pathname || '/';

	  if (search && search !== '?') path += search.charAt(0) === '?' ? search : '?' + search;

	  if (hash && hash !== '#') path += hash.charAt(0) === '#' ? hash : '#' + hash;

	  return path;
	};

/***/ },

/***/ 480:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var createTransitionManager = function createTransitionManager() {
	  var prompt = null;

	  var setPrompt = function setPrompt(nextPrompt) {
	    (0, _warning2.default)(prompt == null, 'A history supports only one prompt at a time');

	    prompt = nextPrompt;

	    return function () {
	      if (prompt === nextPrompt) prompt = null;
	    };
	  };

	  var confirmTransitionTo = function confirmTransitionTo(location, action, getUserConfirmation, callback) {
	    // TODO: If another transition starts while we're still confirming
	    // the previous one, we may end up in a weird state. Figure out the
	    // best way to handle this.
	    if (prompt != null) {
	      var result = typeof prompt === 'function' ? prompt(location, action) : prompt;

	      if (typeof result === 'string') {
	        if (typeof getUserConfirmation === 'function') {
	          getUserConfirmation(result, callback);
	        } else {
	          (0, _warning2.default)(false, 'A history needs a getUserConfirmation function in order to use a prompt message');

	          callback(true);
	        }
	      } else {
	        // Return false from a transition hook to cancel the transition.
	        callback(result !== false);
	      }
	    } else {
	      callback(true);
	    }
	  };

	  var listeners = [];

	  var appendListener = function appendListener(fn) {
	    var isActive = true;

	    var listener = function listener() {
	      if (isActive) fn.apply(undefined, arguments);
	    };

	    listeners.push(listener);

	    return function () {
	      isActive = false;
	      listeners = listeners.filter(function (item) {
	        return item !== listener;
	      });
	    };
	  };

	  var notifyListeners = function notifyListeners() {
	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    listeners.forEach(function (listener) {
	      return listener.apply(undefined, args);
	    });
	  };

	  return {
	    setPrompt: setPrompt,
	    confirmTransitionTo: confirmTransitionTo,
	    appendListener: appendListener,
	    notifyListeners: notifyListeners
	  };
	};

	exports.default = createTransitionManager;

/***/ },

/***/ 481:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;
	var canUseDOM = exports.canUseDOM = !!(typeof window !== 'undefined' && window.document && window.document.createElement);

	var addEventListener = exports.addEventListener = function addEventListener(node, event, listener) {
	  return node.addEventListener ? node.addEventListener(event, listener, false) : node.attachEvent('on' + event, listener);
	};

	var removeEventListener = exports.removeEventListener = function removeEventListener(node, event, listener) {
	  return node.removeEventListener ? node.removeEventListener(event, listener, false) : node.detachEvent('on' + event, listener);
	};

	var getConfirmation = exports.getConfirmation = function getConfirmation(message, callback) {
	  return callback(window.confirm(message));
	}; // eslint-disable-line no-alert

	/**
	 * Returns true if the HTML5 history API is supported. Taken from Modernizr.
	 *
	 * https://github.com/Modernizr/Modernizr/blob/master/LICENSE
	 * https://github.com/Modernizr/Modernizr/blob/master/feature-detects/history.js
	 * changed to avoid false negatives for Windows Phones: https://github.com/reactjs/react-router/issues/586
	 */
	var supportsHistory = exports.supportsHistory = function supportsHistory() {
	  var ua = window.navigator.userAgent;

	  if ((ua.indexOf('Android 2.') !== -1 || ua.indexOf('Android 4.0') !== -1) && ua.indexOf('Mobile Safari') !== -1 && ua.indexOf('Chrome') === -1 && ua.indexOf('Windows Phone') === -1) return false;

	  return window.history && 'pushState' in window.history;
	};

	/**
	 * Returns true if browser fires popstate on hash change.
	 * IE10 and IE11 do not.
	 */
	var supportsPopStateOnHashChange = exports.supportsPopStateOnHashChange = function supportsPopStateOnHashChange() {
	  return window.navigator.userAgent.indexOf('Trident') === -1;
	};

	/**
	 * Returns false if using go(n) with hash history causes a full page reload.
	 */
	var supportsGoWithoutReloadUsingHash = exports.supportsGoWithoutReloadUsingHash = function supportsGoWithoutReloadUsingHash() {
	  return window.navigator.userAgent.indexOf('Firefox') === -1;
	};

	/**
	 * Returns true if a given popstate event is an extraneous WebKit event.
	 * Accounts for the fact that Chrome on iOS fires real popstate events
	 * containing undefined state when pressing the back button.
	 */
	var isExtraneousPopstateEvent = exports.isExtraneousPopstateEvent = function isExtraneousPopstateEvent(event) {
	  return event.state === undefined && navigator.userAgent.indexOf('CriOS') === -1;
	};

/***/ },

/***/ 482:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _Router = __webpack_require__(483);

	var _Router2 = _interopRequireDefault(_Router);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _Router2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 483:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for putting history on context.
	 */
	var Router = function (_React$Component) {
	  _inherits(Router, _React$Component);

	  function Router() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, Router);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
	      match: _this.computeMatch(_this.props.history.location.pathname)
	    }, _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  Router.prototype.getChildContext = function getChildContext() {
	    return {
	      router: _extends({}, this.context.router, {
	        history: this.props.history,
	        route: {
	          location: this.props.history.location,
	          match: this.state.match
	        }
	      })
	    };
	  };

	  Router.prototype.computeMatch = function computeMatch(pathname) {
	    return {
	      path: '/',
	      url: '/',
	      params: {},
	      isExact: pathname === '/'
	    };
	  };

	  Router.prototype.componentWillMount = function componentWillMount() {
	    var _this2 = this;

	    var _props = this.props,
	        children = _props.children,
	        history = _props.history;


	    (0, _invariant2.default)(children == null || _react2.default.Children.count(children) === 1, 'A <Router> may have only one child element');

	    // Do this here so we can setState when a <Redirect> changes the
	    // location in componentWillMount. This happens e.g. when doing
	    // server rendering using a <StaticRouter>.
	    this.unlisten = history.listen(function () {
	      _this2.setState({
	        match: _this2.computeMatch(history.location.pathname)
	      });
	    });
	  };

	  Router.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
	    (0, _warning2.default)(this.props.history === nextProps.history, 'You cannot change <Router history>');
	  };

	  Router.prototype.componentWillUnmount = function componentWillUnmount() {
	    this.unlisten();
	  };

	  Router.prototype.render = function render() {
	    var children = this.props.children;

	    return children ? _react2.default.Children.only(children) : null;
	  };

	  return Router;
	}(_react2.default.Component);

	Router.propTypes = {
	  history: _propTypes2.default.object.isRequired,
	  children: _propTypes2.default.node
	};
	Router.contextTypes = {
	  router: _propTypes2.default.object
	};
	Router.childContextTypes = {
	  router: _propTypes2.default.object.isRequired
	};
	exports.default = Router;

/***/ },

/***/ 484:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _createHashHistory = __webpack_require__(485);

	var _createHashHistory2 = _interopRequireDefault(_createHashHistory);

	var _Router = __webpack_require__(482);

	var _Router2 = _interopRequireDefault(_Router);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for a <Router> that uses window.location.hash.
	 */
	var HashRouter = function (_React$Component) {
	  _inherits(HashRouter, _React$Component);

	  function HashRouter() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, HashRouter);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.history = (0, _createHashHistory2.default)(_this.props), _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  HashRouter.prototype.componentWillMount = function componentWillMount() {
	    (0, _warning2.default)(!this.props.history, '<HashRouter> ignores the history prop. To use a custom history, ' + 'use `import { Router }` instead of `import { HashRouter as Router }`.');
	  };

	  HashRouter.prototype.render = function render() {
	    return _react2.default.createElement(_Router2.default, { history: this.history, children: this.props.children });
	  };

	  return HashRouter;
	}(_react2.default.Component);

	HashRouter.propTypes = {
	  basename: _propTypes2.default.string,
	  getUserConfirmation: _propTypes2.default.func,
	  hashType: _propTypes2.default.oneOf(['hashbang', 'noslash', 'slash']),
	  children: _propTypes2.default.node
	};
	exports.default = HashRouter;

/***/ },

/***/ 485:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _LocationUtils = __webpack_require__(476);

	var _PathUtils = __webpack_require__(479);

	var _createTransitionManager = __webpack_require__(480);

	var _createTransitionManager2 = _interopRequireDefault(_createTransitionManager);

	var _DOMUtils = __webpack_require__(481);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var HashChangeEvent = 'hashchange';

	var HashPathCoders = {
	  hashbang: {
	    encodePath: function encodePath(path) {
	      return path.charAt(0) === '!' ? path : '!/' + (0, _PathUtils.stripLeadingSlash)(path);
	    },
	    decodePath: function decodePath(path) {
	      return path.charAt(0) === '!' ? path.substr(1) : path;
	    }
	  },
	  noslash: {
	    encodePath: _PathUtils.stripLeadingSlash,
	    decodePath: _PathUtils.addLeadingSlash
	  },
	  slash: {
	    encodePath: _PathUtils.addLeadingSlash,
	    decodePath: _PathUtils.addLeadingSlash
	  }
	};

	var getHashPath = function getHashPath() {
	  // We can't use window.location.hash here because it's not
	  // consistent across browsers - Firefox will pre-decode it!
	  var href = window.location.href;
	  var hashIndex = href.indexOf('#');
	  return hashIndex === -1 ? '' : href.substring(hashIndex + 1);
	};

	var pushHashPath = function pushHashPath(path) {
	  return window.location.hash = path;
	};

	var replaceHashPath = function replaceHashPath(path) {
	  var hashIndex = window.location.href.indexOf('#');

	  window.location.replace(window.location.href.slice(0, hashIndex >= 0 ? hashIndex : 0) + '#' + path);
	};

	var createHashHistory = function createHashHistory() {
	  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

	  (0, _invariant2.default)(_DOMUtils.canUseDOM, 'Hash history needs a DOM');

	  var globalHistory = window.history;
	  var canGoWithoutReload = (0, _DOMUtils.supportsGoWithoutReloadUsingHash)();

	  var _props$getUserConfirm = props.getUserConfirmation,
	      getUserConfirmation = _props$getUserConfirm === undefined ? _DOMUtils.getConfirmation : _props$getUserConfirm,
	      _props$hashType = props.hashType,
	      hashType = _props$hashType === undefined ? 'slash' : _props$hashType;

	  var basename = props.basename ? (0, _PathUtils.stripTrailingSlash)((0, _PathUtils.addLeadingSlash)(props.basename)) : '';

	  var _HashPathCoders$hashT = HashPathCoders[hashType],
	      encodePath = _HashPathCoders$hashT.encodePath,
	      decodePath = _HashPathCoders$hashT.decodePath;


	  var getDOMLocation = function getDOMLocation() {
	    var path = decodePath(getHashPath());

	    (0, _warning2.default)(!basename || (0, _PathUtils.hasBasename)(path, basename), 'You are attempting to use a basename on a page whose URL path does not begin ' + 'with the basename. Expected path "' + path + '" to begin with "' + basename + '".');

	    if (basename) path = (0, _PathUtils.stripBasename)(path, basename);

	    return (0, _LocationUtils.createLocation)(path);
	  };

	  var transitionManager = (0, _createTransitionManager2.default)();

	  var setState = function setState(nextState) {
	    _extends(history, nextState);

	    history.length = globalHistory.length;

	    transitionManager.notifyListeners(history.location, history.action);
	  };

	  var forceNextPop = false;
	  var ignorePath = null;

	  var handleHashChange = function handleHashChange() {
	    var path = getHashPath();
	    var encodedPath = encodePath(path);

	    if (path !== encodedPath) {
	      // Ensure we always have a properly-encoded hash.
	      replaceHashPath(encodedPath);
	    } else {
	      var location = getDOMLocation();
	      var prevLocation = history.location;

	      if (!forceNextPop && (0, _LocationUtils.locationsAreEqual)(prevLocation, location)) return; // A hashchange doesn't always == location change.

	      if (ignorePath === (0, _PathUtils.createPath)(location)) return; // Ignore this change; we already setState in push/replace.

	      ignorePath = null;

	      handlePop(location);
	    }
	  };

	  var handlePop = function handlePop(location) {
	    if (forceNextPop) {
	      forceNextPop = false;
	      setState();
	    } else {
	      var action = 'POP';

	      transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	        if (ok) {
	          setState({ action: action, location: location });
	        } else {
	          revertPop(location);
	        }
	      });
	    }
	  };

	  var revertPop = function revertPop(fromLocation) {
	    var toLocation = history.location;

	    // TODO: We could probably make this more reliable by
	    // keeping a list of paths we've seen in sessionStorage.
	    // Instead, we just default to 0 for paths we don't know.

	    var toIndex = allPaths.lastIndexOf((0, _PathUtils.createPath)(toLocation));

	    if (toIndex === -1) toIndex = 0;

	    var fromIndex = allPaths.lastIndexOf((0, _PathUtils.createPath)(fromLocation));

	    if (fromIndex === -1) fromIndex = 0;

	    var delta = toIndex - fromIndex;

	    if (delta) {
	      forceNextPop = true;
	      go(delta);
	    }
	  };

	  // Ensure the hash is encoded properly before doing anything else.
	  var path = getHashPath();
	  var encodedPath = encodePath(path);

	  if (path !== encodedPath) replaceHashPath(encodedPath);

	  var initialLocation = getDOMLocation();
	  var allPaths = [(0, _PathUtils.createPath)(initialLocation)];

	  // Public interface

	  var createHref = function createHref(location) {
	    return '#' + encodePath(basename + (0, _PathUtils.createPath)(location));
	  };

	  var push = function push(path, state) {
	    (0, _warning2.default)(state === undefined, 'Hash history cannot push state; it is ignored');

	    var action = 'PUSH';
	    var location = (0, _LocationUtils.createLocation)(path, undefined, undefined, history.location);

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (!ok) return;

	      var path = (0, _PathUtils.createPath)(location);
	      var encodedPath = encodePath(basename + path);
	      var hashChanged = getHashPath() !== encodedPath;

	      if (hashChanged) {
	        // We cannot tell if a hashchange was caused by a PUSH, so we'd
	        // rather setState here and ignore the hashchange. The caveat here
	        // is that other hash histories in the page will consider it a POP.
	        ignorePath = path;
	        pushHashPath(encodedPath);

	        var prevIndex = allPaths.lastIndexOf((0, _PathUtils.createPath)(history.location));
	        var nextPaths = allPaths.slice(0, prevIndex === -1 ? 0 : prevIndex + 1);

	        nextPaths.push(path);
	        allPaths = nextPaths;

	        setState({ action: action, location: location });
	      } else {
	        (0, _warning2.default)(false, 'Hash history cannot PUSH the same path; a new entry will not be added to the history stack');

	        setState();
	      }
	    });
	  };

	  var replace = function replace(path, state) {
	    (0, _warning2.default)(state === undefined, 'Hash history cannot replace state; it is ignored');

	    var action = 'REPLACE';
	    var location = (0, _LocationUtils.createLocation)(path, undefined, undefined, history.location);

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (!ok) return;

	      var path = (0, _PathUtils.createPath)(location);
	      var encodedPath = encodePath(basename + path);
	      var hashChanged = getHashPath() !== encodedPath;

	      if (hashChanged) {
	        // We cannot tell if a hashchange was caused by a REPLACE, so we'd
	        // rather setState here and ignore the hashchange. The caveat here
	        // is that other hash histories in the page will consider it a POP.
	        ignorePath = path;
	        replaceHashPath(encodedPath);
	      }

	      var prevIndex = allPaths.indexOf((0, _PathUtils.createPath)(history.location));

	      if (prevIndex !== -1) allPaths[prevIndex] = path;

	      setState({ action: action, location: location });
	    });
	  };

	  var go = function go(n) {
	    (0, _warning2.default)(canGoWithoutReload, 'Hash history go(n) causes a full page reload in this browser');

	    globalHistory.go(n);
	  };

	  var goBack = function goBack() {
	    return go(-1);
	  };

	  var goForward = function goForward() {
	    return go(1);
	  };

	  var listenerCount = 0;

	  var checkDOMListeners = function checkDOMListeners(delta) {
	    listenerCount += delta;

	    if (listenerCount === 1) {
	      (0, _DOMUtils.addEventListener)(window, HashChangeEvent, handleHashChange);
	    } else if (listenerCount === 0) {
	      (0, _DOMUtils.removeEventListener)(window, HashChangeEvent, handleHashChange);
	    }
	  };

	  var isBlocked = false;

	  var block = function block() {
	    var prompt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

	    var unblock = transitionManager.setPrompt(prompt);

	    if (!isBlocked) {
	      checkDOMListeners(1);
	      isBlocked = true;
	    }

	    return function () {
	      if (isBlocked) {
	        isBlocked = false;
	        checkDOMListeners(-1);
	      }

	      return unblock();
	    };
	  };

	  var listen = function listen(listener) {
	    var unlisten = transitionManager.appendListener(listener);
	    checkDOMListeners(1);

	    return function () {
	      checkDOMListeners(-1);
	      unlisten();
	    };
	  };

	  var history = {
	    length: globalHistory.length,
	    action: 'POP',
	    location: initialLocation,
	    createHref: createHref,
	    push: push,
	    replace: replace,
	    go: go,
	    goBack: goBack,
	    goForward: goForward,
	    block: block,
	    listen: listen
	  };

	  return history;
	};

	exports.default = createHashHistory;

/***/ },

/***/ 486:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var isModifiedEvent = function isModifiedEvent(event) {
	  return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
	};

	/**
	 * The public API for rendering a history-aware <a>.
	 */

	var Link = function (_React$Component) {
	  _inherits(Link, _React$Component);

	  function Link() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, Link);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.handleClick = function (event) {
	      if (_this.props.onClick) _this.props.onClick(event);

	      if (!event.defaultPrevented && // onClick prevented default
	      event.button === 0 && // ignore right clicks
	      !_this.props.target && // let browser handle "target=_blank" etc.
	      !isModifiedEvent(event) // ignore clicks with modifier keys
	      ) {
	          event.preventDefault();

	          var history = _this.context.router.history;
	          var _this$props = _this.props,
	              replace = _this$props.replace,
	              to = _this$props.to;


	          if (replace) {
	            history.replace(to);
	          } else {
	            history.push(to);
	          }
	        }
	    }, _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  Link.prototype.render = function render() {
	    var _props = this.props,
	        replace = _props.replace,
	        to = _props.to,
	        innerRef = _props.innerRef,
	        props = _objectWithoutProperties(_props, ['replace', 'to', 'innerRef']); // eslint-disable-line no-unused-vars

	    (0, _invariant2.default)(this.context.router, 'You should not use <Link> outside a <Router>');

	    var href = this.context.router.history.createHref(typeof to === 'string' ? { pathname: to } : to);

	    return _react2.default.createElement('a', _extends({}, props, { onClick: this.handleClick, href: href, ref: innerRef }));
	  };

	  return Link;
	}(_react2.default.Component);

	Link.propTypes = {
	  onClick: _propTypes2.default.func,
	  target: _propTypes2.default.string,
	  replace: _propTypes2.default.bool,
	  to: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.object]).isRequired,
	  innerRef: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.func])
	};
	Link.defaultProps = {
	  replace: false
	};
	Link.contextTypes = {
	  router: _propTypes2.default.shape({
	    history: _propTypes2.default.shape({
	      push: _propTypes2.default.func.isRequired,
	      replace: _propTypes2.default.func.isRequired,
	      createHref: _propTypes2.default.func.isRequired
	    }).isRequired
	  }).isRequired
	};
	exports.default = Link;

/***/ },

/***/ 487:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _MemoryRouter = __webpack_require__(488);

	var _MemoryRouter2 = _interopRequireDefault(_MemoryRouter);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _MemoryRouter2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 488:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _createMemoryHistory = __webpack_require__(489);

	var _createMemoryHistory2 = _interopRequireDefault(_createMemoryHistory);

	var _Router = __webpack_require__(483);

	var _Router2 = _interopRequireDefault(_Router);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for a <Router> that stores location in memory.
	 */
	var MemoryRouter = function (_React$Component) {
	  _inherits(MemoryRouter, _React$Component);

	  function MemoryRouter() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, MemoryRouter);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.history = (0, _createMemoryHistory2.default)(_this.props), _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  MemoryRouter.prototype.componentWillMount = function componentWillMount() {
	    (0, _warning2.default)(!this.props.history, '<MemoryRouter> ignores the history prop. To use a custom history, ' + 'use `import { Router }` instead of `import { MemoryRouter as Router }`.');
	  };

	  MemoryRouter.prototype.render = function render() {
	    return _react2.default.createElement(_Router2.default, { history: this.history, children: this.props.children });
	  };

	  return MemoryRouter;
	}(_react2.default.Component);

	MemoryRouter.propTypes = {
	  initialEntries: _propTypes2.default.array,
	  initialIndex: _propTypes2.default.number,
	  getUserConfirmation: _propTypes2.default.func,
	  keyLength: _propTypes2.default.number,
	  children: _propTypes2.default.node
	};
	exports.default = MemoryRouter;

/***/ },

/***/ 489:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _PathUtils = __webpack_require__(479);

	var _LocationUtils = __webpack_require__(476);

	var _createTransitionManager = __webpack_require__(480);

	var _createTransitionManager2 = _interopRequireDefault(_createTransitionManager);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var clamp = function clamp(n, lowerBound, upperBound) {
	  return Math.min(Math.max(n, lowerBound), upperBound);
	};

	/**
	 * Creates a history object that stores locations in memory.
	 */
	var createMemoryHistory = function createMemoryHistory() {
	  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
	  var getUserConfirmation = props.getUserConfirmation,
	      _props$initialEntries = props.initialEntries,
	      initialEntries = _props$initialEntries === undefined ? ['/'] : _props$initialEntries,
	      _props$initialIndex = props.initialIndex,
	      initialIndex = _props$initialIndex === undefined ? 0 : _props$initialIndex,
	      _props$keyLength = props.keyLength,
	      keyLength = _props$keyLength === undefined ? 6 : _props$keyLength;


	  var transitionManager = (0, _createTransitionManager2.default)();

	  var setState = function setState(nextState) {
	    _extends(history, nextState);

	    history.length = history.entries.length;

	    transitionManager.notifyListeners(history.location, history.action);
	  };

	  var createKey = function createKey() {
	    return Math.random().toString(36).substr(2, keyLength);
	  };

	  var index = clamp(initialIndex, 0, initialEntries.length - 1);
	  var entries = initialEntries.map(function (entry) {
	    return typeof entry === 'string' ? (0, _LocationUtils.createLocation)(entry, undefined, createKey()) : (0, _LocationUtils.createLocation)(entry, undefined, entry.key || createKey());
	  });

	  // Public interface

	  var createHref = _PathUtils.createPath;

	  var push = function push(path, state) {
	    (0, _warning2.default)(!((typeof path === 'undefined' ? 'undefined' : _typeof(path)) === 'object' && path.state !== undefined && state !== undefined), 'You should avoid providing a 2nd state argument to push when the 1st ' + 'argument is a location-like object that already has state; it is ignored');

	    var action = 'PUSH';
	    var location = (0, _LocationUtils.createLocation)(path, state, createKey(), history.location);

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (!ok) return;

	      var prevIndex = history.index;
	      var nextIndex = prevIndex + 1;

	      var nextEntries = history.entries.slice(0);
	      if (nextEntries.length > nextIndex) {
	        nextEntries.splice(nextIndex, nextEntries.length - nextIndex, location);
	      } else {
	        nextEntries.push(location);
	      }

	      setState({
	        action: action,
	        location: location,
	        index: nextIndex,
	        entries: nextEntries
	      });
	    });
	  };

	  var replace = function replace(path, state) {
	    (0, _warning2.default)(!((typeof path === 'undefined' ? 'undefined' : _typeof(path)) === 'object' && path.state !== undefined && state !== undefined), 'You should avoid providing a 2nd state argument to replace when the 1st ' + 'argument is a location-like object that already has state; it is ignored');

	    var action = 'REPLACE';
	    var location = (0, _LocationUtils.createLocation)(path, state, createKey(), history.location);

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (!ok) return;

	      history.entries[history.index] = location;

	      setState({ action: action, location: location });
	    });
	  };

	  var go = function go(n) {
	    var nextIndex = clamp(history.index + n, 0, history.entries.length - 1);

	    var action = 'POP';
	    var location = history.entries[nextIndex];

	    transitionManager.confirmTransitionTo(location, action, getUserConfirmation, function (ok) {
	      if (ok) {
	        setState({
	          action: action,
	          location: location,
	          index: nextIndex
	        });
	      } else {
	        // Mimic the behavior of DOM histories by
	        // causing a render after a cancelled POP.
	        setState();
	      }
	    });
	  };

	  var goBack = function goBack() {
	    return go(-1);
	  };

	  var goForward = function goForward() {
	    return go(1);
	  };

	  var canGo = function canGo(n) {
	    var nextIndex = history.index + n;
	    return nextIndex >= 0 && nextIndex < history.entries.length;
	  };

	  var block = function block() {
	    var prompt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
	    return transitionManager.setPrompt(prompt);
	  };

	  var listen = function listen(listener) {
	    return transitionManager.appendListener(listener);
	  };

	  var history = {
	    length: entries.length,
	    action: 'POP',
	    location: entries[index],
	    index: index,
	    entries: entries,
	    createHref: createHref,
	    push: push,
	    replace: replace,
	    go: go,
	    goBack: goBack,
	    goForward: goForward,
	    canGo: canGo,
	    block: block,
	    listen: listen
	  };

	  return history;
	};

	exports.default = createMemoryHistory;

/***/ },

/***/ 490:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _Route = __webpack_require__(491);

	var _Route2 = _interopRequireDefault(_Route);

	var _Link = __webpack_require__(486);

	var _Link2 = _interopRequireDefault(_Link);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	/**
	 * A <Link> wrapper that knows if it's "active" or not.
	 */
	var NavLink = function NavLink(_ref) {
	  var to = _ref.to,
	      exact = _ref.exact,
	      strict = _ref.strict,
	      location = _ref.location,
	      activeClassName = _ref.activeClassName,
	      className = _ref.className,
	      activeStyle = _ref.activeStyle,
	      style = _ref.style,
	      getIsActive = _ref.isActive,
	      ariaCurrent = _ref.ariaCurrent,
	      rest = _objectWithoutProperties(_ref, ['to', 'exact', 'strict', 'location', 'activeClassName', 'className', 'activeStyle', 'style', 'isActive', 'ariaCurrent']);

	  return _react2.default.createElement(_Route2.default, {
	    path: (typeof to === 'undefined' ? 'undefined' : _typeof(to)) === 'object' ? to.pathname : to,
	    exact: exact,
	    strict: strict,
	    location: location,
	    children: function children(_ref2) {
	      var location = _ref2.location,
	          match = _ref2.match;

	      var isActive = !!(getIsActive ? getIsActive(match, location) : match);

	      return _react2.default.createElement(_Link2.default, _extends({
	        to: to,
	        className: isActive ? [className, activeClassName].filter(function (i) {
	          return i;
	        }).join(' ') : className,
	        style: isActive ? _extends({}, style, activeStyle) : style,
	        'aria-current': isActive && ariaCurrent
	      }, rest));
	    }
	  });
	};

	NavLink.propTypes = {
	  to: _Link2.default.propTypes.to,
	  exact: _propTypes2.default.bool,
	  strict: _propTypes2.default.bool,
	  location: _propTypes2.default.object,
	  activeClassName: _propTypes2.default.string,
	  className: _propTypes2.default.string,
	  activeStyle: _propTypes2.default.object,
	  style: _propTypes2.default.object,
	  isActive: _propTypes2.default.func,
	  ariaCurrent: _propTypes2.default.oneOf(['page', 'step', 'location', 'true'])
	};

	NavLink.defaultProps = {
	  activeClassName: 'active',
	  ariaCurrent: 'true'
	};

	exports.default = NavLink;

/***/ },

/***/ 491:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _Route = __webpack_require__(492);

	var _Route2 = _interopRequireDefault(_Route);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _Route2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 492:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _matchPath = __webpack_require__(493);

	var _matchPath2 = _interopRequireDefault(_matchPath);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var isEmptyChildren = function isEmptyChildren(children) {
	  return _react2.default.Children.count(children) === 0;
	};

	/**
	 * The public API for matching a single path and rendering.
	 */

	var Route = function (_React$Component) {
	  _inherits(Route, _React$Component);

	  function Route() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, Route);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
	      match: _this.computeMatch(_this.props, _this.context.router)
	    }, _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  Route.prototype.getChildContext = function getChildContext() {
	    return {
	      router: _extends({}, this.context.router, {
	        route: {
	          location: this.props.location || this.context.router.route.location,
	          match: this.state.match
	        }
	      })
	    };
	  };

	  Route.prototype.computeMatch = function computeMatch(_ref, router) {
	    var computedMatch = _ref.computedMatch,
	        location = _ref.location,
	        path = _ref.path,
	        strict = _ref.strict,
	        exact = _ref.exact,
	        sensitive = _ref.sensitive;

	    if (computedMatch) return computedMatch; // <Switch> already computed the match for us

	    (0, _invariant2.default)(router, 'You should not use <Route> or withRouter() outside a <Router>');

	    var route = router.route;

	    var pathname = (location || route.location).pathname;

	    return path ? (0, _matchPath2.default)(pathname, { path: path, strict: strict, exact: exact, sensitive: sensitive }) : route.match;
	  };

	  Route.prototype.componentWillMount = function componentWillMount() {
	    (0, _warning2.default)(!(this.props.component && this.props.render), 'You should not use <Route component> and <Route render> in the same route; <Route render> will be ignored');

	    (0, _warning2.default)(!(this.props.component && this.props.children && !isEmptyChildren(this.props.children)), 'You should not use <Route component> and <Route children> in the same route; <Route children> will be ignored');

	    (0, _warning2.default)(!(this.props.render && this.props.children && !isEmptyChildren(this.props.children)), 'You should not use <Route render> and <Route children> in the same route; <Route children> will be ignored');
	  };

	  Route.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps, nextContext) {
	    (0, _warning2.default)(!(nextProps.location && !this.props.location), '<Route> elements should not change from uncontrolled to controlled (or vice versa). You initially used no "location" prop and then provided one on a subsequent render.');

	    (0, _warning2.default)(!(!nextProps.location && this.props.location), '<Route> elements should not change from controlled to uncontrolled (or vice versa). You provided a "location" prop initially but omitted it on a subsequent render.');

	    this.setState({
	      match: this.computeMatch(nextProps, nextContext.router)
	    });
	  };

	  Route.prototype.render = function render() {
	    var match = this.state.match;
	    var _props = this.props,
	        children = _props.children,
	        component = _props.component,
	        render = _props.render;
	    var _context$router = this.context.router,
	        history = _context$router.history,
	        route = _context$router.route,
	        staticContext = _context$router.staticContext;

	    var location = this.props.location || route.location;
	    var props = { match: match, location: location, history: history, staticContext: staticContext };

	    return component ? // component prop gets first priority, only called if there's a match
	    match ? _react2.default.createElement(component, props) : null : render ? // render prop is next, only called if there's a match
	    match ? render(props) : null : children ? // children come last, always called
	    typeof children === 'function' ? children(props) : !isEmptyChildren(children) ? _react2.default.Children.only(children) : null : null;
	  };

	  return Route;
	}(_react2.default.Component);

	Route.propTypes = {
	  computedMatch: _propTypes2.default.object, // private, from <Switch>
	  path: _propTypes2.default.string,
	  exact: _propTypes2.default.bool,
	  strict: _propTypes2.default.bool,
	  sensitive: _propTypes2.default.bool,
	  component: _propTypes2.default.func,
	  render: _propTypes2.default.func,
	  children: _propTypes2.default.oneOfType([_propTypes2.default.func, _propTypes2.default.node]),
	  location: _propTypes2.default.object
	};
	Route.contextTypes = {
	  router: _propTypes2.default.shape({
	    history: _propTypes2.default.object.isRequired,
	    route: _propTypes2.default.object.isRequired,
	    staticContext: _propTypes2.default.object
	  })
	};
	Route.childContextTypes = {
	  router: _propTypes2.default.object.isRequired
	};
	exports.default = Route;

/***/ },

/***/ 493:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _pathToRegexp = __webpack_require__(494);

	var _pathToRegexp2 = _interopRequireDefault(_pathToRegexp);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var patternCache = {};
	var cacheLimit = 10000;
	var cacheCount = 0;

	var compilePath = function compilePath(pattern, options) {
	  var cacheKey = '' + options.end + options.strict + options.sensitive;
	  var cache = patternCache[cacheKey] || (patternCache[cacheKey] = {});

	  if (cache[pattern]) return cache[pattern];

	  var keys = [];
	  var re = (0, _pathToRegexp2.default)(pattern, keys, options);
	  var compiledPattern = { re: re, keys: keys };

	  if (cacheCount < cacheLimit) {
	    cache[pattern] = compiledPattern;
	    cacheCount++;
	  }

	  return compiledPattern;
	};

	/**
	 * Public API for matching a URL pathname to a path pattern.
	 */
	var matchPath = function matchPath(pathname) {
	  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

	  if (typeof options === 'string') options = { path: options };

	  var _options = options,
	      _options$path = _options.path,
	      path = _options$path === undefined ? '/' : _options$path,
	      _options$exact = _options.exact,
	      exact = _options$exact === undefined ? false : _options$exact,
	      _options$strict = _options.strict,
	      strict = _options$strict === undefined ? false : _options$strict,
	      _options$sensitive = _options.sensitive,
	      sensitive = _options$sensitive === undefined ? false : _options$sensitive;

	  var _compilePath = compilePath(path, { end: exact, strict: strict, sensitive: sensitive }),
	      re = _compilePath.re,
	      keys = _compilePath.keys;

	  var match = re.exec(pathname);

	  if (!match) return null;

	  var url = match[0],
	      values = match.slice(1);

	  var isExact = pathname === url;

	  if (exact && !isExact) return null;

	  return {
	    path: path, // the path pattern used to match
	    url: path === '/' && url === '' ? '/' : url, // the matched portion of the URL
	    isExact: isExact, // whether or not we matched exactly
	    params: keys.reduce(function (memo, key, index) {
	      memo[key.name] = values[index];
	      return memo;
	    }, {})
	  };
	};

	exports.default = matchPath;

/***/ },

/***/ 494:
/***/ function(module, exports, __webpack_require__) {

	var isarray = __webpack_require__(495)

	/**
	 * Expose `pathToRegexp`.
	 */
	module.exports = pathToRegexp
	module.exports.parse = parse
	module.exports.compile = compile
	module.exports.tokensToFunction = tokensToFunction
	module.exports.tokensToRegExp = tokensToRegExp

	/**
	 * The main path matching regexp utility.
	 *
	 * @type {RegExp}
	 */
	var PATH_REGEXP = new RegExp([
	  // Match escaped characters that would otherwise appear in future matches.
	  // This allows the user to escape special characters that won't transform.
	  '(\\\\.)',
	  // Match Express-style parameters and un-named parameters with a prefix
	  // and optional suffixes. Matches appear as:
	  //
	  // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
	  // "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
	  // "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
	  '([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))'
	].join('|'), 'g')

	/**
	 * Parse a string for the raw tokens.
	 *
	 * @param  {string}  str
	 * @param  {Object=} options
	 * @return {!Array}
	 */
	function parse (str, options) {
	  var tokens = []
	  var key = 0
	  var index = 0
	  var path = ''
	  var defaultDelimiter = options && options.delimiter || '/'
	  var res

	  while ((res = PATH_REGEXP.exec(str)) != null) {
	    var m = res[0]
	    var escaped = res[1]
	    var offset = res.index
	    path += str.slice(index, offset)
	    index = offset + m.length

	    // Ignore already escaped sequences.
	    if (escaped) {
	      path += escaped[1]
	      continue
	    }

	    var next = str[index]
	    var prefix = res[2]
	    var name = res[3]
	    var capture = res[4]
	    var group = res[5]
	    var modifier = res[6]
	    var asterisk = res[7]

	    // Push the current path onto the tokens.
	    if (path) {
	      tokens.push(path)
	      path = ''
	    }

	    var partial = prefix != null && next != null && next !== prefix
	    var repeat = modifier === '+' || modifier === '*'
	    var optional = modifier === '?' || modifier === '*'
	    var delimiter = res[2] || defaultDelimiter
	    var pattern = capture || group

	    tokens.push({
	      name: name || key++,
	      prefix: prefix || '',
	      delimiter: delimiter,
	      optional: optional,
	      repeat: repeat,
	      partial: partial,
	      asterisk: !!asterisk,
	      pattern: pattern ? escapeGroup(pattern) : (asterisk ? '.*' : '[^' + escapeString(delimiter) + ']+?')
	    })
	  }

	  // Match any characters still remaining.
	  if (index < str.length) {
	    path += str.substr(index)
	  }

	  // If the path exists, push it onto the end.
	  if (path) {
	    tokens.push(path)
	  }

	  return tokens
	}

	/**
	 * Compile a string to a template function for the path.
	 *
	 * @param  {string}             str
	 * @param  {Object=}            options
	 * @return {!function(Object=, Object=)}
	 */
	function compile (str, options) {
	  return tokensToFunction(parse(str, options))
	}

	/**
	 * Prettier encoding of URI path segments.
	 *
	 * @param  {string}
	 * @return {string}
	 */
	function encodeURIComponentPretty (str) {
	  return encodeURI(str).replace(/[\/?#]/g, function (c) {
	    return '%' + c.charCodeAt(0).toString(16).toUpperCase()
	  })
	}

	/**
	 * Encode the asterisk parameter. Similar to `pretty`, but allows slashes.
	 *
	 * @param  {string}
	 * @return {string}
	 */
	function encodeAsterisk (str) {
	  return encodeURI(str).replace(/[?#]/g, function (c) {
	    return '%' + c.charCodeAt(0).toString(16).toUpperCase()
	  })
	}

	/**
	 * Expose a method for transforming tokens into the path function.
	 */
	function tokensToFunction (tokens) {
	  // Compile all the tokens into regexps.
	  var matches = new Array(tokens.length)

	  // Compile all the patterns before compilation.
	  for (var i = 0; i < tokens.length; i++) {
	    if (typeof tokens[i] === 'object') {
	      matches[i] = new RegExp('^(?:' + tokens[i].pattern + ')$')
	    }
	  }

	  return function (obj, opts) {
	    var path = ''
	    var data = obj || {}
	    var options = opts || {}
	    var encode = options.pretty ? encodeURIComponentPretty : encodeURIComponent

	    for (var i = 0; i < tokens.length; i++) {
	      var token = tokens[i]

	      if (typeof token === 'string') {
	        path += token

	        continue
	      }

	      var value = data[token.name]
	      var segment

	      if (value == null) {
	        if (token.optional) {
	          // Prepend partial segment prefixes.
	          if (token.partial) {
	            path += token.prefix
	          }

	          continue
	        } else {
	          throw new TypeError('Expected "' + token.name + '" to be defined')
	        }
	      }

	      if (isarray(value)) {
	        if (!token.repeat) {
	          throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + '`')
	        }

	        if (value.length === 0) {
	          if (token.optional) {
	            continue
	          } else {
	            throw new TypeError('Expected "' + token.name + '" to not be empty')
	          }
	        }

	        for (var j = 0; j < value.length; j++) {
	          segment = encode(value[j])

	          if (!matches[i].test(segment)) {
	            throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + '`')
	          }

	          path += (j === 0 ? token.prefix : token.delimiter) + segment
	        }

	        continue
	      }

	      segment = token.asterisk ? encodeAsterisk(value) : encode(value)

	      if (!matches[i].test(segment)) {
	        throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"')
	      }

	      path += token.prefix + segment
	    }

	    return path
	  }
	}

	/**
	 * Escape a regular expression string.
	 *
	 * @param  {string} str
	 * @return {string}
	 */
	function escapeString (str) {
	  return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, '\\$1')
	}

	/**
	 * Escape the capturing group by escaping special characters and meaning.
	 *
	 * @param  {string} group
	 * @return {string}
	 */
	function escapeGroup (group) {
	  return group.replace(/([=!:$\/()])/g, '\\$1')
	}

	/**
	 * Attach the keys as a property of the regexp.
	 *
	 * @param  {!RegExp} re
	 * @param  {Array}   keys
	 * @return {!RegExp}
	 */
	function attachKeys (re, keys) {
	  re.keys = keys
	  return re
	}

	/**
	 * Get the flags for a regexp from the options.
	 *
	 * @param  {Object} options
	 * @return {string}
	 */
	function flags (options) {
	  return options.sensitive ? '' : 'i'
	}

	/**
	 * Pull out keys from a regexp.
	 *
	 * @param  {!RegExp} path
	 * @param  {!Array}  keys
	 * @return {!RegExp}
	 */
	function regexpToRegexp (path, keys) {
	  // Use a negative lookahead to match only capturing groups.
	  var groups = path.source.match(/\((?!\?)/g)

	  if (groups) {
	    for (var i = 0; i < groups.length; i++) {
	      keys.push({
	        name: i,
	        prefix: null,
	        delimiter: null,
	        optional: false,
	        repeat: false,
	        partial: false,
	        asterisk: false,
	        pattern: null
	      })
	    }
	  }

	  return attachKeys(path, keys)
	}

	/**
	 * Transform an array into a regexp.
	 *
	 * @param  {!Array}  path
	 * @param  {Array}   keys
	 * @param  {!Object} options
	 * @return {!RegExp}
	 */
	function arrayToRegexp (path, keys, options) {
	  var parts = []

	  for (var i = 0; i < path.length; i++) {
	    parts.push(pathToRegexp(path[i], keys, options).source)
	  }

	  var regexp = new RegExp('(?:' + parts.join('|') + ')', flags(options))

	  return attachKeys(regexp, keys)
	}

	/**
	 * Create a path regexp from string input.
	 *
	 * @param  {string}  path
	 * @param  {!Array}  keys
	 * @param  {!Object} options
	 * @return {!RegExp}
	 */
	function stringToRegexp (path, keys, options) {
	  return tokensToRegExp(parse(path, options), keys, options)
	}

	/**
	 * Expose a function for taking tokens and returning a RegExp.
	 *
	 * @param  {!Array}          tokens
	 * @param  {(Array|Object)=} keys
	 * @param  {Object=}         options
	 * @return {!RegExp}
	 */
	function tokensToRegExp (tokens, keys, options) {
	  if (!isarray(keys)) {
	    options = /** @type {!Object} */ (keys || options)
	    keys = []
	  }

	  options = options || {}

	  var strict = options.strict
	  var end = options.end !== false
	  var route = ''

	  // Iterate over the tokens and create our regexp string.
	  for (var i = 0; i < tokens.length; i++) {
	    var token = tokens[i]

	    if (typeof token === 'string') {
	      route += escapeString(token)
	    } else {
	      var prefix = escapeString(token.prefix)
	      var capture = '(?:' + token.pattern + ')'

	      keys.push(token)

	      if (token.repeat) {
	        capture += '(?:' + prefix + capture + ')*'
	      }

	      if (token.optional) {
	        if (!token.partial) {
	          capture = '(?:' + prefix + '(' + capture + '))?'
	        } else {
	          capture = prefix + '(' + capture + ')?'
	        }
	      } else {
	        capture = prefix + '(' + capture + ')'
	      }

	      route += capture
	    }
	  }

	  var delimiter = escapeString(options.delimiter || '/')
	  var endsWithDelimiter = route.slice(-delimiter.length) === delimiter

	  // In non-strict mode we allow a slash at the end of match. If the path to
	  // match already ends with a slash, we remove it for consistency. The slash
	  // is valid at the end of a path match, not in the middle. This is important
	  // in non-ending mode, where "/test/" shouldn't match "/test//route".
	  if (!strict) {
	    route = (endsWithDelimiter ? route.slice(0, -delimiter.length) : route) + '(?:' + delimiter + '(?=$))?'
	  }

	  if (end) {
	    route += '$'
	  } else {
	    // In non-ending mode, we need the capturing groups to match as much as
	    // possible by using a positive lookahead to the end or next path segment.
	    route += strict && endsWithDelimiter ? '' : '(?=' + delimiter + '|$)'
	  }

	  return attachKeys(new RegExp('^' + route, flags(options)), keys)
	}

	/**
	 * Normalize the given path string, returning a regular expression.
	 *
	 * An empty array can be passed in for the keys, which will hold the
	 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
	 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
	 *
	 * @param  {(string|RegExp|Array)} path
	 * @param  {(Array|Object)=}       keys
	 * @param  {Object=}               options
	 * @return {!RegExp}
	 */
	function pathToRegexp (path, keys, options) {
	  if (!isarray(keys)) {
	    options = /** @type {!Object} */ (keys || options)
	    keys = []
	  }

	  options = options || {}

	  if (path instanceof RegExp) {
	    return regexpToRegexp(path, /** @type {!Array} */ (keys))
	  }

	  if (isarray(path)) {
	    return arrayToRegexp(/** @type {!Array} */ (path), /** @type {!Array} */ (keys), options)
	  }

	  return stringToRegexp(/** @type {string} */ (path), /** @type {!Array} */ (keys), options)
	}


/***/ },

/***/ 495:
/***/ function(module, exports) {

	module.exports = Array.isArray || function (arr) {
	  return Object.prototype.toString.call(arr) == '[object Array]';
	};


/***/ },

/***/ 496:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _Prompt = __webpack_require__(497);

	var _Prompt2 = _interopRequireDefault(_Prompt);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _Prompt2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 497:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for prompting the user before navigating away
	 * from a screen with a component.
	 */
	var Prompt = function (_React$Component) {
	  _inherits(Prompt, _React$Component);

	  function Prompt() {
	    _classCallCheck(this, Prompt);

	    return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
	  }

	  Prompt.prototype.enable = function enable(message) {
	    if (this.unblock) this.unblock();

	    this.unblock = this.context.router.history.block(message);
	  };

	  Prompt.prototype.disable = function disable() {
	    if (this.unblock) {
	      this.unblock();
	      this.unblock = null;
	    }
	  };

	  Prompt.prototype.componentWillMount = function componentWillMount() {
	    (0, _invariant2.default)(this.context.router, 'You should not use <Prompt> outside a <Router>');

	    if (this.props.when) this.enable(this.props.message);
	  };

	  Prompt.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
	    if (nextProps.when) {
	      if (!this.props.when || this.props.message !== nextProps.message) this.enable(nextProps.message);
	    } else {
	      this.disable();
	    }
	  };

	  Prompt.prototype.componentWillUnmount = function componentWillUnmount() {
	    this.disable();
	  };

	  Prompt.prototype.render = function render() {
	    return null;
	  };

	  return Prompt;
	}(_react2.default.Component);

	Prompt.propTypes = {
	  when: _propTypes2.default.bool,
	  message: _propTypes2.default.oneOfType([_propTypes2.default.func, _propTypes2.default.string]).isRequired
	};
	Prompt.defaultProps = {
	  when: true
	};
	Prompt.contextTypes = {
	  router: _propTypes2.default.shape({
	    history: _propTypes2.default.shape({
	      block: _propTypes2.default.func.isRequired
	    }).isRequired
	  }).isRequired
	};
	exports.default = Prompt;

/***/ },

/***/ 498:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _Redirect = __webpack_require__(499);

	var _Redirect2 = _interopRequireDefault(_Redirect);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _Redirect2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 499:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _history = __webpack_require__(500);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for updating the location programmatically
	 * with a component.
	 */
	var Redirect = function (_React$Component) {
	  _inherits(Redirect, _React$Component);

	  function Redirect() {
	    _classCallCheck(this, Redirect);

	    return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
	  }

	  Redirect.prototype.isStatic = function isStatic() {
	    return this.context.router && this.context.router.staticContext;
	  };

	  Redirect.prototype.componentWillMount = function componentWillMount() {
	    (0, _invariant2.default)(this.context.router, 'You should not use <Redirect> outside a <Router>');

	    if (this.isStatic()) this.perform();
	  };

	  Redirect.prototype.componentDidMount = function componentDidMount() {
	    if (!this.isStatic()) this.perform();
	  };

	  Redirect.prototype.componentDidUpdate = function componentDidUpdate(prevProps) {
	    var prevTo = (0, _history.createLocation)(prevProps.to);
	    var nextTo = (0, _history.createLocation)(this.props.to);

	    if ((0, _history.locationsAreEqual)(prevTo, nextTo)) {
	      (0, _warning2.default)(false, 'You tried to redirect to the same route you\'re currently on: ' + ('"' + nextTo.pathname + nextTo.search + '"'));
	      return;
	    }

	    this.perform();
	  };

	  Redirect.prototype.perform = function perform() {
	    var history = this.context.router.history;
	    var _props = this.props,
	        push = _props.push,
	        to = _props.to;


	    if (push) {
	      history.push(to);
	    } else {
	      history.replace(to);
	    }
	  };

	  Redirect.prototype.render = function render() {
	    return null;
	  };

	  return Redirect;
	}(_react2.default.Component);

	Redirect.propTypes = {
	  push: _propTypes2.default.bool,
	  from: _propTypes2.default.string,
	  to: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.object]).isRequired
	};
	Redirect.defaultProps = {
	  push: false
	};
	Redirect.contextTypes = {
	  router: _propTypes2.default.shape({
	    history: _propTypes2.default.shape({
	      push: _propTypes2.default.func.isRequired,
	      replace: _propTypes2.default.func.isRequired
	    }).isRequired,
	    staticContext: _propTypes2.default.object
	  }).isRequired
	};
	exports.default = Redirect;

/***/ },

/***/ 500:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.createPath = exports.parsePath = exports.locationsAreEqual = exports.createLocation = exports.createMemoryHistory = exports.createHashHistory = exports.createBrowserHistory = undefined;

	var _LocationUtils = __webpack_require__(476);

	Object.defineProperty(exports, 'createLocation', {
	  enumerable: true,
	  get: function get() {
	    return _LocationUtils.createLocation;
	  }
	});
	Object.defineProperty(exports, 'locationsAreEqual', {
	  enumerable: true,
	  get: function get() {
	    return _LocationUtils.locationsAreEqual;
	  }
	});

	var _PathUtils = __webpack_require__(479);

	Object.defineProperty(exports, 'parsePath', {
	  enumerable: true,
	  get: function get() {
	    return _PathUtils.parsePath;
	  }
	});
	Object.defineProperty(exports, 'createPath', {
	  enumerable: true,
	  get: function get() {
	    return _PathUtils.createPath;
	  }
	});

	var _createBrowserHistory2 = __webpack_require__(474);

	var _createBrowserHistory3 = _interopRequireDefault(_createBrowserHistory2);

	var _createHashHistory2 = __webpack_require__(485);

	var _createHashHistory3 = _interopRequireDefault(_createHashHistory2);

	var _createMemoryHistory2 = __webpack_require__(489);

	var _createMemoryHistory3 = _interopRequireDefault(_createMemoryHistory2);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.createBrowserHistory = _createBrowserHistory3.default;
	exports.createHashHistory = _createHashHistory3.default;
	exports.createMemoryHistory = _createMemoryHistory3.default;

/***/ },

/***/ 501:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _StaticRouter = __webpack_require__(502);

	var _StaticRouter2 = _interopRequireDefault(_StaticRouter);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _StaticRouter2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 502:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _PathUtils = __webpack_require__(479);

	var _Router = __webpack_require__(483);

	var _Router2 = _interopRequireDefault(_Router);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var normalizeLocation = function normalizeLocation(object) {
	  var _object$pathname = object.pathname,
	      pathname = _object$pathname === undefined ? '/' : _object$pathname,
	      _object$search = object.search,
	      search = _object$search === undefined ? '' : _object$search,
	      _object$hash = object.hash,
	      hash = _object$hash === undefined ? '' : _object$hash;


	  return {
	    pathname: pathname,
	    search: search === '?' ? '' : search,
	    hash: hash === '#' ? '' : hash
	  };
	};

	var addBasename = function addBasename(basename, location) {
	  if (!basename) return location;

	  return _extends({}, location, {
	    pathname: (0, _PathUtils.addLeadingSlash)(basename) + location.pathname
	  });
	};

	var stripBasename = function stripBasename(basename, location) {
	  if (!basename) return location;

	  var base = (0, _PathUtils.addLeadingSlash)(basename);

	  if (location.pathname.indexOf(base) !== 0) return location;

	  return _extends({}, location, {
	    pathname: location.pathname.substr(base.length)
	  });
	};

	var createLocation = function createLocation(location) {
	  return typeof location === 'string' ? (0, _PathUtils.parsePath)(location) : normalizeLocation(location);
	};

	var createURL = function createURL(location) {
	  return typeof location === 'string' ? location : (0, _PathUtils.createPath)(location);
	};

	var staticHandler = function staticHandler(methodName) {
	  return function () {
	    (0, _invariant2.default)(false, 'You cannot %s with <StaticRouter>', methodName);
	  };
	};

	var noop = function noop() {};

	/**
	 * The public top-level API for a "static" <Router>, so-called because it
	 * can't actually change the current location. Instead, it just records
	 * location changes in a context object. Useful mainly in testing and
	 * server-rendering scenarios.
	 */

	var StaticRouter = function (_React$Component) {
	  _inherits(StaticRouter, _React$Component);

	  function StaticRouter() {
	    var _temp, _this, _ret;

	    _classCallCheck(this, StaticRouter);

	    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
	      args[_key] = arguments[_key];
	    }

	    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.createHref = function (path) {
	      return (0, _PathUtils.addLeadingSlash)(_this.props.basename + createURL(path));
	    }, _this.handlePush = function (location) {
	      var _this$props = _this.props,
	          basename = _this$props.basename,
	          context = _this$props.context;

	      context.action = 'PUSH';
	      context.location = addBasename(basename, createLocation(location));
	      context.url = createURL(context.location);
	    }, _this.handleReplace = function (location) {
	      var _this$props2 = _this.props,
	          basename = _this$props2.basename,
	          context = _this$props2.context;

	      context.action = 'REPLACE';
	      context.location = addBasename(basename, createLocation(location));
	      context.url = createURL(context.location);
	    }, _this.handleListen = function () {
	      return noop;
	    }, _this.handleBlock = function () {
	      return noop;
	    }, _temp), _possibleConstructorReturn(_this, _ret);
	  }

	  StaticRouter.prototype.getChildContext = function getChildContext() {
	    return {
	      router: {
	        staticContext: this.props.context
	      }
	    };
	  };

	  StaticRouter.prototype.componentWillMount = function componentWillMount() {
	    (0, _warning2.default)(!this.props.history, '<StaticRouter> ignores the history prop. To use a custom history, ' + 'use `import { Router }` instead of `import { StaticRouter as Router }`.');
	  };

	  StaticRouter.prototype.render = function render() {
	    var _props = this.props,
	        basename = _props.basename,
	        context = _props.context,
	        location = _props.location,
	        props = _objectWithoutProperties(_props, ['basename', 'context', 'location']);

	    var history = {
	      createHref: this.createHref,
	      action: 'POP',
	      location: stripBasename(basename, createLocation(location)),
	      push: this.handlePush,
	      replace: this.handleReplace,
	      go: staticHandler('go'),
	      goBack: staticHandler('goBack'),
	      goForward: staticHandler('goForward'),
	      listen: this.handleListen,
	      block: this.handleBlock
	    };

	    return _react2.default.createElement(_Router2.default, _extends({}, props, { history: history }));
	  };

	  return StaticRouter;
	}(_react2.default.Component);

	StaticRouter.propTypes = {
	  basename: _propTypes2.default.string,
	  context: _propTypes2.default.object.isRequired,
	  location: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.object])
	};
	StaticRouter.defaultProps = {
	  basename: '',
	  location: '/'
	};
	StaticRouter.childContextTypes = {
	  router: _propTypes2.default.object.isRequired
	};
	exports.default = StaticRouter;

/***/ },

/***/ 503:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _Switch = __webpack_require__(504);

	var _Switch2 = _interopRequireDefault(_Switch);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _Switch2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 504:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _warning = __webpack_require__(369);

	var _warning2 = _interopRequireDefault(_warning);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _matchPath = __webpack_require__(493);

	var _matchPath2 = _interopRequireDefault(_matchPath);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * The public API for rendering the first <Route> that matches.
	 */
	var Switch = function (_React$Component) {
	  _inherits(Switch, _React$Component);

	  function Switch() {
	    _classCallCheck(this, Switch);

	    return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
	  }

	  Switch.prototype.componentWillMount = function componentWillMount() {
	    (0, _invariant2.default)(this.context.router, 'You should not use <Switch> outside a <Router>');
	  };

	  Switch.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
	    (0, _warning2.default)(!(nextProps.location && !this.props.location), '<Switch> elements should not change from uncontrolled to controlled (or vice versa). You initially used no "location" prop and then provided one on a subsequent render.');

	    (0, _warning2.default)(!(!nextProps.location && this.props.location), '<Switch> elements should not change from controlled to uncontrolled (or vice versa). You provided a "location" prop initially but omitted it on a subsequent render.');
	  };

	  Switch.prototype.render = function render() {
	    var route = this.context.router.route;
	    var children = this.props.children;

	    var location = this.props.location || route.location;

	    var match = void 0,
	        child = void 0;
	    _react2.default.Children.forEach(children, function (element) {
	      if (!_react2.default.isValidElement(element)) return;

	      var _element$props = element.props,
	          pathProp = _element$props.path,
	          exact = _element$props.exact,
	          strict = _element$props.strict,
	          sensitive = _element$props.sensitive,
	          from = _element$props.from;

	      var path = pathProp || from;

	      if (match == null) {
	        child = element;
	        match = path ? (0, _matchPath2.default)(location.pathname, { path: path, exact: exact, strict: strict, sensitive: sensitive }) : route.match;
	      }
	    });

	    return match ? _react2.default.cloneElement(child, { location: location, computedMatch: match }) : null;
	  };

	  return Switch;
	}(_react2.default.Component);

	Switch.contextTypes = {
	  router: _propTypes2.default.shape({
	    route: _propTypes2.default.object.isRequired
	  }).isRequired
	};
	Switch.propTypes = {
	  children: _propTypes2.default.node,
	  location: _propTypes2.default.object
	};
	exports.default = Switch;

/***/ },

/***/ 505:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _matchPath = __webpack_require__(493);

	var _matchPath2 = _interopRequireDefault(_matchPath);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _matchPath2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 506:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _withRouter = __webpack_require__(507);

	var _withRouter2 = _interopRequireDefault(_withRouter);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = _withRouter2.default; // Written in this round about way for babel-transform-imports

/***/ },

/***/ 507:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _hoistNonReactStatics = __webpack_require__(380);

	var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

	var _Route = __webpack_require__(492);

	var _Route2 = _interopRequireDefault(_Route);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	/**
	 * A public higher-order component to access the imperative API
	 */
	var withRouter = function withRouter(Component) {
	  var C = function C(props) {
	    var wrappedComponentRef = props.wrappedComponentRef,
	        remainingProps = _objectWithoutProperties(props, ['wrappedComponentRef']);

	    return _react2.default.createElement(_Route2.default, { render: function render(routeComponentProps) {
	        return _react2.default.createElement(Component, _extends({}, remainingProps, routeComponentProps, { ref: wrappedComponentRef }));
	      } });
	  };

	  C.displayName = 'withRouter(' + (Component.displayName || Component.name) + ')';
	  C.WrappedComponent = Component;
	  C.propTypes = {
	    wrappedComponentRef: _propTypes2.default.func
	  };

	  return (0, _hoistNonReactStatics2.default)(C, Component);
	};

	exports.default = withRouter;

/***/ },

/***/ 520:
/***/ function(module, exports, __webpack_require__) {

	var Stack = __webpack_require__(521),
	    assignMergeValue = __webpack_require__(527),
	    baseFor = __webpack_require__(528),
	    baseMergeDeep = __webpack_require__(530),
	    isObject = __webpack_require__(303),
	    keysIn = __webpack_require__(553),
	    safeGet = __webpack_require__(550);

	/**
	 * The base implementation of `_.merge` without support for multiple sources.
	 *
	 * @private
	 * @param {Object} object The destination object.
	 * @param {Object} source The source object.
	 * @param {number} srcIndex The index of `source`.
	 * @param {Function} [customizer] The function to customize merged values.
	 * @param {Object} [stack] Tracks traversed source values and their merged
	 *  counterparts.
	 */
	function baseMerge(object, source, srcIndex, customizer, stack) {
	  if (object === source) {
	    return;
	  }
	  baseFor(source, function(srcValue, key) {
	    if (isObject(srcValue)) {
	      stack || (stack = new Stack);
	      baseMergeDeep(object, source, key, srcIndex, baseMerge, customizer, stack);
	    }
	    else {
	      var newValue = customizer
	        ? customizer(safeGet(object, key), srcValue, (key + ''), object, source, stack)
	        : undefined;

	      if (newValue === undefined) {
	        newValue = srcValue;
	      }
	      assignMergeValue(object, key, newValue);
	    }
	  }, keysIn);
	}

	module.exports = baseMerge;


/***/ },

/***/ 527:
/***/ function(module, exports, __webpack_require__) {

	var baseAssignValue = __webpack_require__(375),
	    eq = __webpack_require__(316);

	/**
	 * This function is like `assignValue` except that it doesn't assign
	 * `undefined` values.
	 *
	 * @private
	 * @param {Object} object The object to modify.
	 * @param {string} key The key of the property to assign.
	 * @param {*} value The value to assign.
	 */
	function assignMergeValue(object, key, value) {
	  if ((value !== undefined && !eq(object[key], value)) ||
	      (value === undefined && !(key in object))) {
	    baseAssignValue(object, key, value);
	  }
	}

	module.exports = assignMergeValue;


/***/ },

/***/ 530:
/***/ function(module, exports, __webpack_require__) {

	var assignMergeValue = __webpack_require__(527),
	    cloneBuffer = __webpack_require__(531),
	    cloneTypedArray = __webpack_require__(532),
	    copyArray = __webpack_require__(535),
	    initCloneObject = __webpack_require__(536),
	    isArguments = __webpack_require__(330),
	    isArray = __webpack_require__(282),
	    isArrayLikeObject = __webpack_require__(541),
	    isBuffer = __webpack_require__(543),
	    isFunction = __webpack_require__(302),
	    isObject = __webpack_require__(303),
	    isPlainObject = __webpack_require__(545),
	    isTypedArray = __webpack_require__(546),
	    safeGet = __webpack_require__(550),
	    toPlainObject = __webpack_require__(551);

	/**
	 * A specialized version of `baseMerge` for arrays and objects which performs
	 * deep merges and tracks traversed objects enabling objects with circular
	 * references to be merged.
	 *
	 * @private
	 * @param {Object} object The destination object.
	 * @param {Object} source The source object.
	 * @param {string} key The key of the value to merge.
	 * @param {number} srcIndex The index of `source`.
	 * @param {Function} mergeFunc The function to merge values.
	 * @param {Function} [customizer] The function to customize assigned values.
	 * @param {Object} [stack] Tracks traversed source values and their merged
	 *  counterparts.
	 */
	function baseMergeDeep(object, source, key, srcIndex, mergeFunc, customizer, stack) {
	  var objValue = safeGet(object, key),
	      srcValue = safeGet(source, key),
	      stacked = stack.get(srcValue);

	  if (stacked) {
	    assignMergeValue(object, key, stacked);
	    return;
	  }
	  var newValue = customizer
	    ? customizer(objValue, srcValue, (key + ''), object, source, stack)
	    : undefined;

	  var isCommon = newValue === undefined;

	  if (isCommon) {
	    var isArr = isArray(srcValue),
	        isBuff = !isArr && isBuffer(srcValue),
	        isTyped = !isArr && !isBuff && isTypedArray(srcValue);

	    newValue = srcValue;
	    if (isArr || isBuff || isTyped) {
	      if (isArray(objValue)) {
	        newValue = objValue;
	      }
	      else if (isArrayLikeObject(objValue)) {
	        newValue = copyArray(objValue);
	      }
	      else if (isBuff) {
	        isCommon = false;
	        newValue = cloneBuffer(srcValue, true);
	      }
	      else if (isTyped) {
	        isCommon = false;
	        newValue = cloneTypedArray(srcValue, true);
	      }
	      else {
	        newValue = [];
	      }
	    }
	    else if (isPlainObject(srcValue) || isArguments(srcValue)) {
	      newValue = objValue;
	      if (isArguments(objValue)) {
	        newValue = toPlainObject(objValue);
	      }
	      else if (!isObject(objValue) || (srcIndex && isFunction(objValue))) {
	        newValue = initCloneObject(srcValue);
	      }
	    }
	    else {
	      isCommon = false;
	    }
	  }
	  if (isCommon) {
	    // Recursively merge objects and arrays (susceptible to call stack limits).
	    stack.set(srcValue, newValue);
	    mergeFunc(newValue, srcValue, srcIndex, customizer, stack);
	    stack['delete'](srcValue);
	  }
	  assignMergeValue(object, key, newValue);
	}

	module.exports = baseMergeDeep;


/***/ },

/***/ 531:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(module) {var root = __webpack_require__(287);

	/** Detect free variable `exports`. */
	var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;

	/** Detect free variable `module`. */
	var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;

	/** Detect the popular CommonJS extension `module.exports`. */
	var moduleExports = freeModule && freeModule.exports === freeExports;

	/** Built-in value references. */
	var Buffer = moduleExports ? root.Buffer : undefined,
	    allocUnsafe = Buffer ? Buffer.allocUnsafe : undefined;

	/**
	 * Creates a clone of  `buffer`.
	 *
	 * @private
	 * @param {Buffer} buffer The buffer to clone.
	 * @param {boolean} [isDeep] Specify a deep clone.
	 * @returns {Buffer} Returns the cloned buffer.
	 */
	function cloneBuffer(buffer, isDeep) {
	  if (isDeep) {
	    return buffer.slice();
	  }
	  var length = buffer.length,
	      result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);

	  buffer.copy(result);
	  return result;
	}

	module.exports = cloneBuffer;

	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(99)(module)))

/***/ },

/***/ 532:
/***/ function(module, exports, __webpack_require__) {

	var cloneArrayBuffer = __webpack_require__(533);

	/**
	 * Creates a clone of `typedArray`.
	 *
	 * @private
	 * @param {Object} typedArray The typed array to clone.
	 * @param {boolean} [isDeep] Specify a deep clone.
	 * @returns {Object} Returns the cloned typed array.
	 */
	function cloneTypedArray(typedArray, isDeep) {
	  var buffer = isDeep ? cloneArrayBuffer(typedArray.buffer) : typedArray.buffer;
	  return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
	}

	module.exports = cloneTypedArray;


/***/ },

/***/ 533:
/***/ function(module, exports, __webpack_require__) {

	var Uint8Array = __webpack_require__(534);

	/**
	 * Creates a clone of `arrayBuffer`.
	 *
	 * @private
	 * @param {ArrayBuffer} arrayBuffer The array buffer to clone.
	 * @returns {ArrayBuffer} Returns the cloned array buffer.
	 */
	function cloneArrayBuffer(arrayBuffer) {
	  var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
	  new Uint8Array(result).set(new Uint8Array(arrayBuffer));
	  return result;
	}

	module.exports = cloneArrayBuffer;


/***/ },

/***/ 535:
/***/ function(module, exports) {

	/**
	 * Copies the values of `source` to `array`.
	 *
	 * @private
	 * @param {Array} source The array to copy values from.
	 * @param {Array} [array=[]] The array to copy values to.
	 * @returns {Array} Returns `array`.
	 */
	function copyArray(source, array) {
	  var index = -1,
	      length = source.length;

	  array || (array = Array(length));
	  while (++index < length) {
	    array[index] = source[index];
	  }
	  return array;
	}

	module.exports = copyArray;


/***/ },

/***/ 536:
/***/ function(module, exports, __webpack_require__) {

	var baseCreate = __webpack_require__(537),
	    getPrototype = __webpack_require__(538),
	    isPrototype = __webpack_require__(540);

	/**
	 * Initializes an object clone.
	 *
	 * @private
	 * @param {Object} object The object to clone.
	 * @returns {Object} Returns the initialized clone.
	 */
	function initCloneObject(object) {
	  return (typeof object.constructor == 'function' && !isPrototype(object))
	    ? baseCreate(getPrototype(object))
	    : {};
	}

	module.exports = initCloneObject;


/***/ },

/***/ 537:
/***/ function(module, exports, __webpack_require__) {

	var isObject = __webpack_require__(303);

	/** Built-in value references. */
	var objectCreate = Object.create;

	/**
	 * The base implementation of `_.create` without support for assigning
	 * properties to the created object.
	 *
	 * @private
	 * @param {Object} proto The object to inherit from.
	 * @returns {Object} Returns the new object.
	 */
	var baseCreate = (function() {
	  function object() {}
	  return function(proto) {
	    if (!isObject(proto)) {
	      return {};
	    }
	    if (objectCreate) {
	      return objectCreate(proto);
	    }
	    object.prototype = proto;
	    var result = new object;
	    object.prototype = undefined;
	    return result;
	  };
	}());

	module.exports = baseCreate;


/***/ },

/***/ 550:
/***/ function(module, exports) {

	/**
	 * Gets the value at `key`, unless `key` is "__proto__".
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @param {string} key The key of the property to get.
	 * @returns {*} Returns the property value.
	 */
	function safeGet(object, key) {
	  return key == '__proto__'
	    ? undefined
	    : object[key];
	}

	module.exports = safeGet;


/***/ },

/***/ 551:
/***/ function(module, exports, __webpack_require__) {

	var copyObject = __webpack_require__(552),
	    keysIn = __webpack_require__(553);

	/**
	 * Converts `value` to a plain object flattening inherited enumerable string
	 * keyed properties of `value` to own properties of the plain object.
	 *
	 * @static
	 * @memberOf _
	 * @since 3.0.0
	 * @category Lang
	 * @param {*} value The value to convert.
	 * @returns {Object} Returns the converted plain object.
	 * @example
	 *
	 * function Foo() {
	 *   this.b = 2;
	 * }
	 *
	 * Foo.prototype.c = 3;
	 *
	 * _.assign({ 'a': 1 }, new Foo);
	 * // => { 'a': 1, 'b': 2 }
	 *
	 * _.assign({ 'a': 1 }, _.toPlainObject(new Foo));
	 * // => { 'a': 1, 'b': 2, 'c': 3 }
	 */
	function toPlainObject(value) {
	  return copyObject(value, keysIn(value));
	}

	module.exports = toPlainObject;


/***/ },

/***/ 552:
/***/ function(module, exports, __webpack_require__) {

	var assignValue = __webpack_require__(374),
	    baseAssignValue = __webpack_require__(375);

	/**
	 * Copies properties of `source` to `object`.
	 *
	 * @private
	 * @param {Object} source The object to copy properties from.
	 * @param {Array} props The property identifiers to copy.
	 * @param {Object} [object={}] The object to copy properties to.
	 * @param {Function} [customizer] The function to customize copied values.
	 * @returns {Object} Returns `object`.
	 */
	function copyObject(source, props, object, customizer) {
	  var isNew = !object;
	  object || (object = {});

	  var index = -1,
	      length = props.length;

	  while (++index < length) {
	    var key = props[index];

	    var newValue = customizer
	      ? customizer(object[key], source[key], key, object, source)
	      : undefined;

	    if (newValue === undefined) {
	      newValue = source[key];
	    }
	    if (isNew) {
	      baseAssignValue(object, key, newValue);
	    } else {
	      assignValue(object, key, newValue);
	    }
	  }
	  return object;
	}

	module.exports = copyObject;


/***/ },

/***/ 553:
/***/ function(module, exports, __webpack_require__) {

	var arrayLikeKeys = __webpack_require__(554),
	    baseKeysIn = __webpack_require__(556),
	    isArrayLike = __webpack_require__(542);

	/**
	 * Creates an array of the own and inherited enumerable property names of `object`.
	 *
	 * **Note:** Non-object values are coerced to objects.
	 *
	 * @static
	 * @memberOf _
	 * @since 3.0.0
	 * @category Object
	 * @param {Object} object The object to query.
	 * @returns {Array} Returns the array of property names.
	 * @example
	 *
	 * function Foo() {
	 *   this.a = 1;
	 *   this.b = 2;
	 * }
	 *
	 * Foo.prototype.c = 3;
	 *
	 * _.keysIn(new Foo);
	 * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
	 */
	function keysIn(object) {
	  return isArrayLike(object) ? arrayLikeKeys(object, true) : baseKeysIn(object);
	}

	module.exports = keysIn;


/***/ },

/***/ 556:
/***/ function(module, exports, __webpack_require__) {

	var isObject = __webpack_require__(303),
	    isPrototype = __webpack_require__(540),
	    nativeKeysIn = __webpack_require__(557);

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * The base implementation of `_.keysIn` which doesn't treat sparse arrays as dense.
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @returns {Array} Returns the array of property names.
	 */
	function baseKeysIn(object) {
	  if (!isObject(object)) {
	    return nativeKeysIn(object);
	  }
	  var isProto = isPrototype(object),
	      result = [];

	  for (var key in object) {
	    if (!(key == 'constructor' && (isProto || !hasOwnProperty.call(object, key)))) {
	      result.push(key);
	    }
	  }
	  return result;
	}

	module.exports = baseKeysIn;


/***/ },

/***/ 557:
/***/ function(module, exports) {

	/**
	 * This function is like
	 * [`Object.keys`](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
	 * except that it includes inherited enumerable properties.
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @returns {Array} Returns the array of property names.
	 */
	function nativeKeysIn(object) {
	  var result = [];
	  if (object != null) {
	    for (var key in Object(object)) {
	      result.push(key);
	    }
	  }
	  return result;
	}

	module.exports = nativeKeysIn;


/***/ },

/***/ 558:
/***/ function(module, exports, __webpack_require__) {

	var baseRest = __webpack_require__(559),
	    isIterateeCall = __webpack_require__(567);

	/**
	 * Creates a function like `_.assign`.
	 *
	 * @private
	 * @param {Function} assigner The function to assign values.
	 * @returns {Function} Returns the new assigner function.
	 */
	function createAssigner(assigner) {
	  return baseRest(function(object, sources) {
	    var index = -1,
	        length = sources.length,
	        customizer = length > 1 ? sources[length - 1] : undefined,
	        guard = length > 2 ? sources[2] : undefined;

	    customizer = (assigner.length > 3 && typeof customizer == 'function')
	      ? (length--, customizer)
	      : undefined;

	    if (guard && isIterateeCall(sources[0], sources[1], guard)) {
	      customizer = length < 3 ? undefined : customizer;
	      length = 1;
	    }
	    object = Object(object);
	    while (++index < length) {
	      var source = sources[index];
	      if (source) {
	        assigner(object, source, index, customizer);
	      }
	    }
	    return object;
	  });
	}

	module.exports = createAssigner;


/***/ },

/***/ 651:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.compose = exports.applyMiddleware = exports.bindActionCreators = exports.combineReducers = exports.createStore = undefined;

	var _createStore = __webpack_require__(652);

	var _createStore2 = _interopRequireDefault(_createStore);

	var _combineReducers = __webpack_require__(655);

	var _combineReducers2 = _interopRequireDefault(_combineReducers);

	var _bindActionCreators = __webpack_require__(657);

	var _bindActionCreators2 = _interopRequireDefault(_bindActionCreators);

	var _applyMiddleware = __webpack_require__(658);

	var _applyMiddleware2 = _interopRequireDefault(_applyMiddleware);

	var _compose = __webpack_require__(659);

	var _compose2 = _interopRequireDefault(_compose);

	var _warning = __webpack_require__(656);

	var _warning2 = _interopRequireDefault(_warning);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	/*
	* This is a dummy function to check if the function name has been altered by minification.
	* If the function has been minified and NODE_ENV !== 'production', warn the user.
	*/
	function isCrushed() {}

	if (false) {
	  (0, _warning2['default'])('You are currently using minified code outside of NODE_ENV === \'production\'. ' + 'This means that you are running a slower development build of Redux. ' + 'You can use loose-envify (https://github.com/zertosh/loose-envify) for browserify ' + 'or DefinePlugin for webpack (http://stackoverflow.com/questions/30030031) ' + 'to ensure you have the correct code for your production build.');
	}

	exports.createStore = _createStore2['default'];
	exports.combineReducers = _combineReducers2['default'];
	exports.bindActionCreators = _bindActionCreators2['default'];
	exports.applyMiddleware = _applyMiddleware2['default'];
	exports.compose = _compose2['default'];

/***/ },

/***/ 652:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.ActionTypes = undefined;
	exports['default'] = createStore;

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	var _symbolObservable = __webpack_require__(653);

	var _symbolObservable2 = _interopRequireDefault(_symbolObservable);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	/**
	 * These are private action types reserved by Redux.
	 * For any unknown actions, you must return the current state.
	 * If the current state is undefined, you must return the initial state.
	 * Do not reference these action types directly in your code.
	 */
	var ActionTypes = exports.ActionTypes = {
	  INIT: '@@redux/INIT'

	  /**
	   * Creates a Redux store that holds the state tree.
	   * The only way to change the data in the store is to call `dispatch()` on it.
	   *
	   * There should only be a single store in your app. To specify how different
	   * parts of the state tree respond to actions, you may combine several reducers
	   * into a single reducer function by using `combineReducers`.
	   *
	   * @param {Function} reducer A function that returns the next state tree, given
	   * the current state tree and the action to handle.
	   *
	   * @param {any} [preloadedState] The initial state. You may optionally specify it
	   * to hydrate the state from the server in universal apps, or to restore a
	   * previously serialized user session.
	   * If you use `combineReducers` to produce the root reducer function, this must be
	   * an object with the same shape as `combineReducers` keys.
	   *
	   * @param {Function} [enhancer] The store enhancer. You may optionally specify it
	   * to enhance the store with third-party capabilities such as middleware,
	   * time travel, persistence, etc. The only store enhancer that ships with Redux
	   * is `applyMiddleware()`.
	   *
	   * @returns {Store} A Redux store that lets you read the state, dispatch actions
	   * and subscribe to changes.
	   */
	};function createStore(reducer, preloadedState, enhancer) {
	  var _ref2;

	  if (typeof preloadedState === 'function' && typeof enhancer === 'undefined') {
	    enhancer = preloadedState;
	    preloadedState = undefined;
	  }

	  if (typeof enhancer !== 'undefined') {
	    if (typeof enhancer !== 'function') {
	      throw new Error('Expected the enhancer to be a function.');
	    }

	    return enhancer(createStore)(reducer, preloadedState);
	  }

	  if (typeof reducer !== 'function') {
	    throw new Error('Expected the reducer to be a function.');
	  }

	  var currentReducer = reducer;
	  var currentState = preloadedState;
	  var currentListeners = [];
	  var nextListeners = currentListeners;
	  var isDispatching = false;

	  function ensureCanMutateNextListeners() {
	    if (nextListeners === currentListeners) {
	      nextListeners = currentListeners.slice();
	    }
	  }

	  /**
	   * Reads the state tree managed by the store.
	   *
	   * @returns {any} The current state tree of your application.
	   */
	  function getState() {
	    return currentState;
	  }

	  /**
	   * Adds a change listener. It will be called any time an action is dispatched,
	   * and some part of the state tree may potentially have changed. You may then
	   * call `getState()` to read the current state tree inside the callback.
	   *
	   * You may call `dispatch()` from a change listener, with the following
	   * caveats:
	   *
	   * 1. The subscriptions are snapshotted just before every `dispatch()` call.
	   * If you subscribe or unsubscribe while the listeners are being invoked, this
	   * will not have any effect on the `dispatch()` that is currently in progress.
	   * However, the next `dispatch()` call, whether nested or not, will use a more
	   * recent snapshot of the subscription list.
	   *
	   * 2. The listener should not expect to see all state changes, as the state
	   * might have been updated multiple times during a nested `dispatch()` before
	   * the listener is called. It is, however, guaranteed that all subscribers
	   * registered before the `dispatch()` started will be called with the latest
	   * state by the time it exits.
	   *
	   * @param {Function} listener A callback to be invoked on every dispatch.
	   * @returns {Function} A function to remove this change listener.
	   */
	  function subscribe(listener) {
	    if (typeof listener !== 'function') {
	      throw new Error('Expected listener to be a function.');
	    }

	    var isSubscribed = true;

	    ensureCanMutateNextListeners();
	    nextListeners.push(listener);

	    return function unsubscribe() {
	      if (!isSubscribed) {
	        return;
	      }

	      isSubscribed = false;

	      ensureCanMutateNextListeners();
	      var index = nextListeners.indexOf(listener);
	      nextListeners.splice(index, 1);
	    };
	  }

	  /**
	   * Dispatches an action. It is the only way to trigger a state change.
	   *
	   * The `reducer` function, used to create the store, will be called with the
	   * current state tree and the given `action`. Its return value will
	   * be considered the **next** state of the tree, and the change listeners
	   * will be notified.
	   *
	   * The base implementation only supports plain object actions. If you want to
	   * dispatch a Promise, an Observable, a thunk, or something else, you need to
	   * wrap your store creating function into the corresponding middleware. For
	   * example, see the documentation for the `redux-thunk` package. Even the
	   * middleware will eventually dispatch plain object actions using this method.
	   *
	   * @param {Object} action A plain object representing “what changed”. It is
	   * a good idea to keep actions serializable so you can record and replay user
	   * sessions, or use the time travelling `redux-devtools`. An action must have
	   * a `type` property which may not be `undefined`. It is a good idea to use
	   * string constants for action types.
	   *
	   * @returns {Object} For convenience, the same action object you dispatched.
	   *
	   * Note that, if you use a custom middleware, it may wrap `dispatch()` to
	   * return something else (for example, a Promise you can await).
	   */
	  function dispatch(action) {
	    if (!(0, _isPlainObject2['default'])(action)) {
	      throw new Error('Actions must be plain objects. ' + 'Use custom middleware for async actions.');
	    }

	    if (typeof action.type === 'undefined') {
	      throw new Error('Actions may not have an undefined "type" property. ' + 'Have you misspelled a constant?');
	    }

	    if (isDispatching) {
	      throw new Error('Reducers may not dispatch actions.');
	    }

	    try {
	      isDispatching = true;
	      currentState = currentReducer(currentState, action);
	    } finally {
	      isDispatching = false;
	    }

	    var listeners = currentListeners = nextListeners;
	    for (var i = 0; i < listeners.length; i++) {
	      var listener = listeners[i];
	      listener();
	    }

	    return action;
	  }

	  /**
	   * Replaces the reducer currently used by the store to calculate the state.
	   *
	   * You might need this if your app implements code splitting and you want to
	   * load some of the reducers dynamically. You might also need this if you
	   * implement a hot reloading mechanism for Redux.
	   *
	   * @param {Function} nextReducer The reducer for the store to use instead.
	   * @returns {void}
	   */
	  function replaceReducer(nextReducer) {
	    if (typeof nextReducer !== 'function') {
	      throw new Error('Expected the nextReducer to be a function.');
	    }

	    currentReducer = nextReducer;
	    dispatch({ type: ActionTypes.INIT });
	  }

	  /**
	   * Interoperability point for observable/reactive libraries.
	   * @returns {observable} A minimal observable of state changes.
	   * For more information, see the observable proposal:
	   * https://github.com/tc39/proposal-observable
	   */
	  function observable() {
	    var _ref;

	    var outerSubscribe = subscribe;
	    return _ref = {
	      /**
	       * The minimal observable subscription method.
	       * @param {Object} observer Any object that can be used as an observer.
	       * The observer object should have a `next` method.
	       * @returns {subscription} An object with an `unsubscribe` method that can
	       * be used to unsubscribe the observable from the store, and prevent further
	       * emission of values from the observable.
	       */
	      subscribe: function subscribe(observer) {
	        if (typeof observer !== 'object') {
	          throw new TypeError('Expected the observer to be an object.');
	        }

	        function observeState() {
	          if (observer.next) {
	            observer.next(getState());
	          }
	        }

	        observeState();
	        var unsubscribe = outerSubscribe(observeState);
	        return { unsubscribe: unsubscribe };
	      }
	    }, _ref[_symbolObservable2['default']] = function () {
	      return this;
	    }, _ref;
	  }

	  // When a store is created, an "INIT" action is dispatched so that every
	  // reducer returns their initial state. This effectively populates
	  // the initial state tree.
	  dispatch({ type: ActionTypes.INIT });

	  return _ref2 = {
	    dispatch: dispatch,
	    subscribe: subscribe,
	    getState: getState,
	    replaceReducer: replaceReducer
	  }, _ref2[_symbolObservable2['default']] = observable, _ref2;
	}

/***/ },

/***/ 653:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(global, module) {'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _ponyfill = __webpack_require__(654);

	var _ponyfill2 = _interopRequireDefault(_ponyfill);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var root; /* global window */


	if (typeof self !== 'undefined') {
	  root = self;
	} else if (typeof window !== 'undefined') {
	  root = window;
	} else if (typeof global !== 'undefined') {
	  root = global;
	} else if (true) {
	  root = module;
	} else {
	  root = Function('return this')();
	}

	var result = (0, _ponyfill2['default'])(root);
	exports['default'] = result;
	/* WEBPACK VAR INJECTION */}.call(exports, (function() { return this; }()), __webpack_require__(99)(module)))

/***/ },

/***/ 654:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports['default'] = symbolObservablePonyfill;
	function symbolObservablePonyfill(root) {
		var result;
		var _Symbol = root.Symbol;

		if (typeof _Symbol === 'function') {
			if (_Symbol.observable) {
				result = _Symbol.observable;
			} else {
				result = _Symbol('observable');
				_Symbol.observable = result;
			}
		} else {
			result = '@@observable';
		}

		return result;
	};

/***/ },

/***/ 655:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports['default'] = combineReducers;

	var _createStore = __webpack_require__(652);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	var _warning = __webpack_require__(656);

	var _warning2 = _interopRequireDefault(_warning);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function getUndefinedStateErrorMessage(key, action) {
	  var actionType = action && action.type;
	  var actionName = actionType && '"' + actionType.toString() + '"' || 'an action';

	  return 'Given action ' + actionName + ', reducer "' + key + '" returned undefined. ' + 'To ignore an action, you must explicitly return the previous state. ' + 'If you want this reducer to hold no value, you can return null instead of undefined.';
	}

	function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
	  var reducerKeys = Object.keys(reducers);
	  var argumentName = action && action.type === _createStore.ActionTypes.INIT ? 'preloadedState argument passed to createStore' : 'previous state received by the reducer';

	  if (reducerKeys.length === 0) {
	    return 'Store does not have a valid reducer. Make sure the argument passed ' + 'to combineReducers is an object whose values are reducers.';
	  }

	  if (!(0, _isPlainObject2['default'])(inputState)) {
	    return 'The ' + argumentName + ' has unexpected type of "' + {}.toString.call(inputState).match(/\s([a-z|A-Z]+)/)[1] + '". Expected argument to be an object with the following ' + ('keys: "' + reducerKeys.join('", "') + '"');
	  }

	  var unexpectedKeys = Object.keys(inputState).filter(function (key) {
	    return !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key];
	  });

	  unexpectedKeys.forEach(function (key) {
	    unexpectedKeyCache[key] = true;
	  });

	  if (unexpectedKeys.length > 0) {
	    return 'Unexpected ' + (unexpectedKeys.length > 1 ? 'keys' : 'key') + ' ' + ('"' + unexpectedKeys.join('", "') + '" found in ' + argumentName + '. ') + 'Expected to find one of the known reducer keys instead: ' + ('"' + reducerKeys.join('", "') + '". Unexpected keys will be ignored.');
	  }
	}

	function assertReducerShape(reducers) {
	  Object.keys(reducers).forEach(function (key) {
	    var reducer = reducers[key];
	    var initialState = reducer(undefined, { type: _createStore.ActionTypes.INIT });

	    if (typeof initialState === 'undefined') {
	      throw new Error('Reducer "' + key + '" returned undefined during initialization. ' + 'If the state passed to the reducer is undefined, you must ' + 'explicitly return the initial state. The initial state may ' + 'not be undefined. If you don\'t want to set a value for this reducer, ' + 'you can use null instead of undefined.');
	    }

	    var type = '@@redux/PROBE_UNKNOWN_ACTION_' + Math.random().toString(36).substring(7).split('').join('.');
	    if (typeof reducer(undefined, { type: type }) === 'undefined') {
	      throw new Error('Reducer "' + key + '" returned undefined when probed with a random type. ' + ('Don\'t try to handle ' + _createStore.ActionTypes.INIT + ' or other actions in "redux/*" ') + 'namespace. They are considered private. Instead, you must return the ' + 'current state for any unknown actions, unless it is undefined, ' + 'in which case you must return the initial state, regardless of the ' + 'action type. The initial state may not be undefined, but can be null.');
	    }
	  });
	}

	/**
	 * Turns an object whose values are different reducer functions, into a single
	 * reducer function. It will call every child reducer, and gather their results
	 * into a single state object, whose keys correspond to the keys of the passed
	 * reducer functions.
	 *
	 * @param {Object} reducers An object whose values correspond to different
	 * reducer functions that need to be combined into one. One handy way to obtain
	 * it is to use ES6 `import * as reducers` syntax. The reducers may never return
	 * undefined for any action. Instead, they should return their initial state
	 * if the state passed to them was undefined, and the current state for any
	 * unrecognized action.
	 *
	 * @returns {Function} A reducer function that invokes every reducer inside the
	 * passed object, and builds a state object with the same shape.
	 */
	function combineReducers(reducers) {
	  var reducerKeys = Object.keys(reducers);
	  var finalReducers = {};
	  for (var i = 0; i < reducerKeys.length; i++) {
	    var key = reducerKeys[i];

	    if (false) {
	      if (typeof reducers[key] === 'undefined') {
	        (0, _warning2['default'])('No reducer provided for key "' + key + '"');
	      }
	    }

	    if (typeof reducers[key] === 'function') {
	      finalReducers[key] = reducers[key];
	    }
	  }
	  var finalReducerKeys = Object.keys(finalReducers);

	  var unexpectedKeyCache = void 0;
	  if (false) {
	    unexpectedKeyCache = {};
	  }

	  var shapeAssertionError = void 0;
	  try {
	    assertReducerShape(finalReducers);
	  } catch (e) {
	    shapeAssertionError = e;
	  }

	  return function combination() {
	    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
	    var action = arguments[1];

	    if (shapeAssertionError) {
	      throw shapeAssertionError;
	    }

	    if (false) {
	      var warningMessage = getUnexpectedStateShapeWarningMessage(state, finalReducers, action, unexpectedKeyCache);
	      if (warningMessage) {
	        (0, _warning2['default'])(warningMessage);
	      }
	    }

	    var hasChanged = false;
	    var nextState = {};
	    for (var _i = 0; _i < finalReducerKeys.length; _i++) {
	      var _key = finalReducerKeys[_i];
	      var reducer = finalReducers[_key];
	      var previousStateForKey = state[_key];
	      var nextStateForKey = reducer(previousStateForKey, action);
	      if (typeof nextStateForKey === 'undefined') {
	        var errorMessage = getUndefinedStateErrorMessage(_key, action);
	        throw new Error(errorMessage);
	      }
	      nextState[_key] = nextStateForKey;
	      hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
	    }
	    return hasChanged ? nextState : state;
	  };
	}

/***/ },

/***/ 656:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;
	exports['default'] = warning;
	/**
	 * Prints a warning in the console if it exists.
	 *
	 * @param {String} message The warning message.
	 * @returns {void}
	 */
	function warning(message) {
	  /* eslint-disable no-console */
	  if (typeof console !== 'undefined' && typeof console.error === 'function') {
	    console.error(message);
	  }
	  /* eslint-enable no-console */
	  try {
	    // This error was thrown as a convenience so that if you enable
	    // "break on all exceptions" in your console,
	    // it would pause the execution at this line.
	    throw new Error(message);
	    /* eslint-disable no-empty */
	  } catch (e) {}
	  /* eslint-enable no-empty */
	}

/***/ },

/***/ 657:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;
	exports['default'] = bindActionCreators;
	function bindActionCreator(actionCreator, dispatch) {
	  return function () {
	    return dispatch(actionCreator.apply(undefined, arguments));
	  };
	}

	/**
	 * Turns an object whose values are action creators, into an object with the
	 * same keys, but with every function wrapped into a `dispatch` call so they
	 * may be invoked directly. This is just a convenience method, as you can call
	 * `store.dispatch(MyActionCreators.doSomething())` yourself just fine.
	 *
	 * For convenience, you can also pass a single function as the first argument,
	 * and get a function in return.
	 *
	 * @param {Function|Object} actionCreators An object whose values are action
	 * creator functions. One handy way to obtain it is to use ES6 `import * as`
	 * syntax. You may also pass a single function.
	 *
	 * @param {Function} dispatch The `dispatch` function available on your Redux
	 * store.
	 *
	 * @returns {Function|Object} The object mimicking the original object, but with
	 * every action creator wrapped into the `dispatch` call. If you passed a
	 * function as `actionCreators`, the return value will also be a single
	 * function.
	 */
	function bindActionCreators(actionCreators, dispatch) {
	  if (typeof actionCreators === 'function') {
	    return bindActionCreator(actionCreators, dispatch);
	  }

	  if (typeof actionCreators !== 'object' || actionCreators === null) {
	    throw new Error('bindActionCreators expected an object or a function, instead received ' + (actionCreators === null ? 'null' : typeof actionCreators) + '. ' + 'Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?');
	  }

	  var keys = Object.keys(actionCreators);
	  var boundActionCreators = {};
	  for (var i = 0; i < keys.length; i++) {
	    var key = keys[i];
	    var actionCreator = actionCreators[key];
	    if (typeof actionCreator === 'function') {
	      boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
	    }
	  }
	  return boundActionCreators;
	}

/***/ },

/***/ 658:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	exports['default'] = applyMiddleware;

	var _compose = __webpack_require__(659);

	var _compose2 = _interopRequireDefault(_compose);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	/**
	 * Creates a store enhancer that applies middleware to the dispatch method
	 * of the Redux store. This is handy for a variety of tasks, such as expressing
	 * asynchronous actions in a concise manner, or logging every action payload.
	 *
	 * See `redux-thunk` package as an example of the Redux middleware.
	 *
	 * Because middleware is potentially asynchronous, this should be the first
	 * store enhancer in the composition chain.
	 *
	 * Note that each middleware will be given the `dispatch` and `getState` functions
	 * as named arguments.
	 *
	 * @param {...Function} middlewares The middleware chain to be applied.
	 * @returns {Function} A store enhancer applying the middleware.
	 */
	function applyMiddleware() {
	  for (var _len = arguments.length, middlewares = Array(_len), _key = 0; _key < _len; _key++) {
	    middlewares[_key] = arguments[_key];
	  }

	  return function (createStore) {
	    return function (reducer, preloadedState, enhancer) {
	      var store = createStore(reducer, preloadedState, enhancer);
	      var _dispatch = store.dispatch;
	      var chain = [];

	      var middlewareAPI = {
	        getState: store.getState,
	        dispatch: function dispatch(action) {
	          return _dispatch(action);
	        }
	      };
	      chain = middlewares.map(function (middleware) {
	        return middleware(middlewareAPI);
	      });
	      _dispatch = _compose2['default'].apply(undefined, chain)(store.dispatch);

	      return _extends({}, store, {
	        dispatch: _dispatch
	      });
	    };
	  };
	}

/***/ },

/***/ 659:
/***/ function(module, exports) {

	"use strict";

	exports.__esModule = true;
	exports["default"] = compose;
	/**
	 * Composes single-argument functions from right to left. The rightmost
	 * function can take multiple arguments as it provides the signature for
	 * the resulting composite function.
	 *
	 * @param {...Function} funcs The functions to compose.
	 * @returns {Function} A function obtained by composing the argument functions
	 * from right to left. For example, compose(f, g, h) is identical to doing
	 * (...args) => f(g(h(...args))).
	 */

	function compose() {
	  for (var _len = arguments.length, funcs = Array(_len), _key = 0; _key < _len; _key++) {
	    funcs[_key] = arguments[_key];
	  }

	  if (funcs.length === 0) {
	    return function (arg) {
	      return arg;
	    };
	  }

	  if (funcs.length === 1) {
	    return funcs[0];
	  }

	  return funcs.reduce(function (a, b) {
	    return function () {
	      return a(b.apply(undefined, arguments));
	    };
	  });
	}

/***/ },

/***/ 728:
/***/ function(module, exports, __webpack_require__) {

	var toFinite = __webpack_require__(729);

	/**
	 * Converts `value` to an integer.
	 *
	 * **Note:** This method is loosely based on
	 * [`ToInteger`](http://www.ecma-international.org/ecma-262/7.0/#sec-tointeger).
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to convert.
	 * @returns {number} Returns the converted integer.
	 * @example
	 *
	 * _.toInteger(3.2);
	 * // => 3
	 *
	 * _.toInteger(Number.MIN_VALUE);
	 * // => 0
	 *
	 * _.toInteger(Infinity);
	 * // => 1.7976931348623157e+308
	 *
	 * _.toInteger('3.2');
	 * // => 3
	 */
	function toInteger(value) {
	  var result = toFinite(value),
	      remainder = result % 1;

	  return result === result ? (remainder ? result - remainder : result) : 0;
	}

	module.exports = toInteger;


/***/ },

/***/ 792:
/***/ function(module, exports, __webpack_require__) {

	var Stack = __webpack_require__(521),
	    arrayEach = __webpack_require__(793),
	    assignValue = __webpack_require__(374),
	    baseAssign = __webpack_require__(794),
	    baseAssignIn = __webpack_require__(795),
	    cloneBuffer = __webpack_require__(531),
	    copyArray = __webpack_require__(535),
	    copySymbols = __webpack_require__(796),
	    copySymbolsIn = __webpack_require__(800),
	    getAllKeys = __webpack_require__(803),
	    getAllKeysIn = __webpack_require__(805),
	    getTag = __webpack_require__(806),
	    initCloneArray = __webpack_require__(811),
	    initCloneByTag = __webpack_require__(812),
	    initCloneObject = __webpack_require__(536),
	    isArray = __webpack_require__(282),
	    isBuffer = __webpack_require__(543),
	    isMap = __webpack_require__(816),
	    isObject = __webpack_require__(303),
	    isSet = __webpack_require__(818),
	    keys = __webpack_require__(719);

	/** Used to compose bitmasks for cloning. */
	var CLONE_DEEP_FLAG = 1,
	    CLONE_FLAT_FLAG = 2,
	    CLONE_SYMBOLS_FLAG = 4;

	/** `Object#toString` result references. */
	var argsTag = '[object Arguments]',
	    arrayTag = '[object Array]',
	    boolTag = '[object Boolean]',
	    dateTag = '[object Date]',
	    errorTag = '[object Error]',
	    funcTag = '[object Function]',
	    genTag = '[object GeneratorFunction]',
	    mapTag = '[object Map]',
	    numberTag = '[object Number]',
	    objectTag = '[object Object]',
	    regexpTag = '[object RegExp]',
	    setTag = '[object Set]',
	    stringTag = '[object String]',
	    symbolTag = '[object Symbol]',
	    weakMapTag = '[object WeakMap]';

	var arrayBufferTag = '[object ArrayBuffer]',
	    dataViewTag = '[object DataView]',
	    float32Tag = '[object Float32Array]',
	    float64Tag = '[object Float64Array]',
	    int8Tag = '[object Int8Array]',
	    int16Tag = '[object Int16Array]',
	    int32Tag = '[object Int32Array]',
	    uint8Tag = '[object Uint8Array]',
	    uint8ClampedTag = '[object Uint8ClampedArray]',
	    uint16Tag = '[object Uint16Array]',
	    uint32Tag = '[object Uint32Array]';

	/** Used to identify `toStringTag` values supported by `_.clone`. */
	var cloneableTags = {};
	cloneableTags[argsTag] = cloneableTags[arrayTag] =
	cloneableTags[arrayBufferTag] = cloneableTags[dataViewTag] =
	cloneableTags[boolTag] = cloneableTags[dateTag] =
	cloneableTags[float32Tag] = cloneableTags[float64Tag] =
	cloneableTags[int8Tag] = cloneableTags[int16Tag] =
	cloneableTags[int32Tag] = cloneableTags[mapTag] =
	cloneableTags[numberTag] = cloneableTags[objectTag] =
	cloneableTags[regexpTag] = cloneableTags[setTag] =
	cloneableTags[stringTag] = cloneableTags[symbolTag] =
	cloneableTags[uint8Tag] = cloneableTags[uint8ClampedTag] =
	cloneableTags[uint16Tag] = cloneableTags[uint32Tag] = true;
	cloneableTags[errorTag] = cloneableTags[funcTag] =
	cloneableTags[weakMapTag] = false;

	/**
	 * The base implementation of `_.clone` and `_.cloneDeep` which tracks
	 * traversed objects.
	 *
	 * @private
	 * @param {*} value The value to clone.
	 * @param {boolean} bitmask The bitmask flags.
	 *  1 - Deep clone
	 *  2 - Flatten inherited properties
	 *  4 - Clone symbols
	 * @param {Function} [customizer] The function to customize cloning.
	 * @param {string} [key] The key of `value`.
	 * @param {Object} [object] The parent object of `value`.
	 * @param {Object} [stack] Tracks traversed objects and their clone counterparts.
	 * @returns {*} Returns the cloned value.
	 */
	function baseClone(value, bitmask, customizer, key, object, stack) {
	  var result,
	      isDeep = bitmask & CLONE_DEEP_FLAG,
	      isFlat = bitmask & CLONE_FLAT_FLAG,
	      isFull = bitmask & CLONE_SYMBOLS_FLAG;

	  if (customizer) {
	    result = object ? customizer(value, key, object, stack) : customizer(value);
	  }
	  if (result !== undefined) {
	    return result;
	  }
	  if (!isObject(value)) {
	    return value;
	  }
	  var isArr = isArray(value);
	  if (isArr) {
	    result = initCloneArray(value);
	    if (!isDeep) {
	      return copyArray(value, result);
	    }
	  } else {
	    var tag = getTag(value),
	        isFunc = tag == funcTag || tag == genTag;

	    if (isBuffer(value)) {
	      return cloneBuffer(value, isDeep);
	    }
	    if (tag == objectTag || tag == argsTag || (isFunc && !object)) {
	      result = (isFlat || isFunc) ? {} : initCloneObject(value);
	      if (!isDeep) {
	        return isFlat
	          ? copySymbolsIn(value, baseAssignIn(result, value))
	          : copySymbols(value, baseAssign(result, value));
	      }
	    } else {
	      if (!cloneableTags[tag]) {
	        return object ? value : {};
	      }
	      result = initCloneByTag(value, tag, isDeep);
	    }
	  }
	  // Check for circular references and return its corresponding clone.
	  stack || (stack = new Stack);
	  var stacked = stack.get(value);
	  if (stacked) {
	    return stacked;
	  }
	  stack.set(value, result);

	  if (isSet(value)) {
	    value.forEach(function(subValue) {
	      result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
	    });

	    return result;
	  }

	  if (isMap(value)) {
	    value.forEach(function(subValue, key) {
	      result.set(key, baseClone(subValue, bitmask, customizer, key, value, stack));
	    });

	    return result;
	  }

	  var keysFunc = isFull
	    ? (isFlat ? getAllKeysIn : getAllKeys)
	    : (isFlat ? keysIn : keys);

	  var props = isArr ? undefined : keysFunc(value);
	  arrayEach(props || value, function(subValue, key) {
	    if (props) {
	      key = subValue;
	      subValue = value[key];
	    }
	    // Recursively populate clone (susceptible to call stack limits).
	    assignValue(result, key, baseClone(subValue, bitmask, customizer, key, value, stack));
	  });
	  return result;
	}

	module.exports = baseClone;


/***/ },

/***/ 793:
/***/ function(module, exports) {

	/**
	 * A specialized version of `_.forEach` for arrays without support for
	 * iteratee shorthands.
	 *
	 * @private
	 * @param {Array} [array] The array to iterate over.
	 * @param {Function} iteratee The function invoked per iteration.
	 * @returns {Array} Returns `array`.
	 */
	function arrayEach(array, iteratee) {
	  var index = -1,
	      length = array == null ? 0 : array.length;

	  while (++index < length) {
	    if (iteratee(array[index], index, array) === false) {
	      break;
	    }
	  }
	  return array;
	}

	module.exports = arrayEach;


/***/ },

/***/ 794:
/***/ function(module, exports, __webpack_require__) {

	var copyObject = __webpack_require__(552),
	    keys = __webpack_require__(719);

	/**
	 * The base implementation of `_.assign` without support for multiple sources
	 * or `customizer` functions.
	 *
	 * @private
	 * @param {Object} object The destination object.
	 * @param {Object} source The source object.
	 * @returns {Object} Returns `object`.
	 */
	function baseAssign(object, source) {
	  return object && copyObject(source, keys(source), object);
	}

	module.exports = baseAssign;


/***/ },

/***/ 795:
/***/ function(module, exports, __webpack_require__) {

	var copyObject = __webpack_require__(552),
	    keysIn = __webpack_require__(553);

	/**
	 * The base implementation of `_.assignIn` without support for multiple sources
	 * or `customizer` functions.
	 *
	 * @private
	 * @param {Object} object The destination object.
	 * @param {Object} source The source object.
	 * @returns {Object} Returns `object`.
	 */
	function baseAssignIn(object, source) {
	  return object && copyObject(source, keysIn(source), object);
	}

	module.exports = baseAssignIn;


/***/ },

/***/ 796:
/***/ function(module, exports, __webpack_require__) {

	var copyObject = __webpack_require__(552),
	    getSymbols = __webpack_require__(797);

	/**
	 * Copies own symbols of `source` to `object`.
	 *
	 * @private
	 * @param {Object} source The object to copy symbols from.
	 * @param {Object} [object={}] The object to copy symbols to.
	 * @returns {Object} Returns `object`.
	 */
	function copySymbols(source, object) {
	  return copyObject(source, getSymbols(source), object);
	}

	module.exports = copySymbols;


/***/ },

/***/ 800:
/***/ function(module, exports, __webpack_require__) {

	var copyObject = __webpack_require__(552),
	    getSymbolsIn = __webpack_require__(801);

	/**
	 * Copies own and inherited symbols of `source` to `object`.
	 *
	 * @private
	 * @param {Object} source The object to copy symbols from.
	 * @param {Object} [object={}] The object to copy symbols to.
	 * @returns {Object} Returns `object`.
	 */
	function copySymbolsIn(source, object) {
	  return copyObject(source, getSymbolsIn(source), object);
	}

	module.exports = copySymbolsIn;


/***/ },

/***/ 801:
/***/ function(module, exports, __webpack_require__) {

	var arrayPush = __webpack_require__(802),
	    getPrototype = __webpack_require__(538),
	    getSymbols = __webpack_require__(797),
	    stubArray = __webpack_require__(799);

	/* Built-in method references for those with the same name as other `lodash` methods. */
	var nativeGetSymbols = Object.getOwnPropertySymbols;

	/**
	 * Creates an array of the own and inherited enumerable symbols of `object`.
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @returns {Array} Returns the array of symbols.
	 */
	var getSymbolsIn = !nativeGetSymbols ? stubArray : function(object) {
	  var result = [];
	  while (object) {
	    arrayPush(result, getSymbols(object));
	    object = getPrototype(object);
	  }
	  return result;
	};

	module.exports = getSymbolsIn;


/***/ },

/***/ 805:
/***/ function(module, exports, __webpack_require__) {

	var baseGetAllKeys = __webpack_require__(804),
	    getSymbolsIn = __webpack_require__(801),
	    keysIn = __webpack_require__(553);

	/**
	 * Creates an array of own and inherited enumerable property names and
	 * symbols of `object`.
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @returns {Array} Returns the array of property names and symbols.
	 */
	function getAllKeysIn(object) {
	  return baseGetAllKeys(object, keysIn, getSymbolsIn);
	}

	module.exports = getAllKeysIn;


/***/ },

/***/ 811:
/***/ function(module, exports) {

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Initializes an array clone.
	 *
	 * @private
	 * @param {Array} array The array to clone.
	 * @returns {Array} Returns the initialized clone.
	 */
	function initCloneArray(array) {
	  var length = array.length,
	      result = new array.constructor(length);

	  // Add properties assigned by `RegExp#exec`.
	  if (length && typeof array[0] == 'string' && hasOwnProperty.call(array, 'index')) {
	    result.index = array.index;
	    result.input = array.input;
	  }
	  return result;
	}

	module.exports = initCloneArray;


/***/ },

/***/ 812:
/***/ function(module, exports, __webpack_require__) {

	var cloneArrayBuffer = __webpack_require__(533),
	    cloneDataView = __webpack_require__(813),
	    cloneRegExp = __webpack_require__(814),
	    cloneSymbol = __webpack_require__(815),
	    cloneTypedArray = __webpack_require__(532);

	/** `Object#toString` result references. */
	var boolTag = '[object Boolean]',
	    dateTag = '[object Date]',
	    mapTag = '[object Map]',
	    numberTag = '[object Number]',
	    regexpTag = '[object RegExp]',
	    setTag = '[object Set]',
	    stringTag = '[object String]',
	    symbolTag = '[object Symbol]';

	var arrayBufferTag = '[object ArrayBuffer]',
	    dataViewTag = '[object DataView]',
	    float32Tag = '[object Float32Array]',
	    float64Tag = '[object Float64Array]',
	    int8Tag = '[object Int8Array]',
	    int16Tag = '[object Int16Array]',
	    int32Tag = '[object Int32Array]',
	    uint8Tag = '[object Uint8Array]',
	    uint8ClampedTag = '[object Uint8ClampedArray]',
	    uint16Tag = '[object Uint16Array]',
	    uint32Tag = '[object Uint32Array]';

	/**
	 * Initializes an object clone based on its `toStringTag`.
	 *
	 * **Note:** This function only supports cloning values with tags of
	 * `Boolean`, `Date`, `Error`, `Map`, `Number`, `RegExp`, `Set`, or `String`.
	 *
	 * @private
	 * @param {Object} object The object to clone.
	 * @param {string} tag The `toStringTag` of the object to clone.
	 * @param {boolean} [isDeep] Specify a deep clone.
	 * @returns {Object} Returns the initialized clone.
	 */
	function initCloneByTag(object, tag, isDeep) {
	  var Ctor = object.constructor;
	  switch (tag) {
	    case arrayBufferTag:
	      return cloneArrayBuffer(object);

	    case boolTag:
	    case dateTag:
	      return new Ctor(+object);

	    case dataViewTag:
	      return cloneDataView(object, isDeep);

	    case float32Tag: case float64Tag:
	    case int8Tag: case int16Tag: case int32Tag:
	    case uint8Tag: case uint8ClampedTag: case uint16Tag: case uint32Tag:
	      return cloneTypedArray(object, isDeep);

	    case mapTag:
	      return new Ctor;

	    case numberTag:
	    case stringTag:
	      return new Ctor(object);

	    case regexpTag:
	      return cloneRegExp(object);

	    case setTag:
	      return new Ctor;

	    case symbolTag:
	      return cloneSymbol(object);
	  }
	}

	module.exports = initCloneByTag;


/***/ },

/***/ 813:
/***/ function(module, exports, __webpack_require__) {

	var cloneArrayBuffer = __webpack_require__(533);

	/**
	 * Creates a clone of `dataView`.
	 *
	 * @private
	 * @param {Object} dataView The data view to clone.
	 * @param {boolean} [isDeep] Specify a deep clone.
	 * @returns {Object} Returns the cloned data view.
	 */
	function cloneDataView(dataView, isDeep) {
	  var buffer = isDeep ? cloneArrayBuffer(dataView.buffer) : dataView.buffer;
	  return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
	}

	module.exports = cloneDataView;


/***/ },

/***/ 814:
/***/ function(module, exports) {

	/** Used to match `RegExp` flags from their coerced string values. */
	var reFlags = /\w*$/;

	/**
	 * Creates a clone of `regexp`.
	 *
	 * @private
	 * @param {Object} regexp The regexp to clone.
	 * @returns {Object} Returns the cloned regexp.
	 */
	function cloneRegExp(regexp) {
	  var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
	  result.lastIndex = regexp.lastIndex;
	  return result;
	}

	module.exports = cloneRegExp;


/***/ },

/***/ 815:
/***/ function(module, exports, __webpack_require__) {

	var Symbol = __webpack_require__(286);

	/** Used to convert symbols to primitives and strings. */
	var symbolProto = Symbol ? Symbol.prototype : undefined,
	    symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

	/**
	 * Creates a clone of the `symbol` object.
	 *
	 * @private
	 * @param {Object} symbol The symbol object to clone.
	 * @returns {Object} Returns the cloned symbol object.
	 */
	function cloneSymbol(symbol) {
	  return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
	}

	module.exports = cloneSymbol;


/***/ },

/***/ 816:
/***/ function(module, exports, __webpack_require__) {

	var baseIsMap = __webpack_require__(817),
	    baseUnary = __webpack_require__(548),
	    nodeUtil = __webpack_require__(549);

	/* Node.js helper references. */
	var nodeIsMap = nodeUtil && nodeUtil.isMap;

	/**
	 * Checks if `value` is classified as a `Map` object.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.3.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a map, else `false`.
	 * @example
	 *
	 * _.isMap(new Map);
	 * // => true
	 *
	 * _.isMap(new WeakMap);
	 * // => false
	 */
	var isMap = nodeIsMap ? baseUnary(nodeIsMap) : baseIsMap;

	module.exports = isMap;


/***/ },

/***/ 817:
/***/ function(module, exports, __webpack_require__) {

	var getTag = __webpack_require__(806),
	    isObjectLike = __webpack_require__(291);

	/** `Object#toString` result references. */
	var mapTag = '[object Map]';

	/**
	 * The base implementation of `_.isMap` without Node.js optimizations.
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a map, else `false`.
	 */
	function baseIsMap(value) {
	  return isObjectLike(value) && getTag(value) == mapTag;
	}

	module.exports = baseIsMap;


/***/ },

/***/ 818:
/***/ function(module, exports, __webpack_require__) {

	var baseIsSet = __webpack_require__(819),
	    baseUnary = __webpack_require__(548),
	    nodeUtil = __webpack_require__(549);

	/* Node.js helper references. */
	var nodeIsSet = nodeUtil && nodeUtil.isSet;

	/**
	 * Checks if `value` is classified as a `Set` object.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.3.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a set, else `false`.
	 * @example
	 *
	 * _.isSet(new Set);
	 * // => true
	 *
	 * _.isSet(new WeakSet);
	 * // => false
	 */
	var isSet = nodeIsSet ? baseUnary(nodeIsSet) : baseIsSet;

	module.exports = isSet;


/***/ },

/***/ 819:
/***/ function(module, exports, __webpack_require__) {

	var getTag = __webpack_require__(806),
	    isObjectLike = __webpack_require__(291);

	/** `Object#toString` result references. */
	var setTag = '[object Set]';

	/**
	 * The base implementation of `_.isSet` without Node.js optimizations.
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a set, else `false`.
	 */
	function baseIsSet(value) {
	  return isObjectLike(value) && getTag(value) == setTag;
	}

	module.exports = baseIsSet;


/***/ },

/***/ 846:
/***/ function(module, exports, __webpack_require__) {

	var baseFindIndex = __webpack_require__(847),
	    baseIteratee = __webpack_require__(822),
	    toInteger = __webpack_require__(728);

	/* Built-in method references for those with the same name as other `lodash` methods. */
	var nativeMax = Math.max;

	/**
	 * This method is like `_.find` except that it returns the index of the first
	 * element `predicate` returns truthy for instead of the element itself.
	 *
	 * @static
	 * @memberOf _
	 * @since 1.1.0
	 * @category Array
	 * @param {Array} array The array to inspect.
	 * @param {Function} [predicate=_.identity] The function invoked per iteration.
	 * @param {number} [fromIndex=0] The index to search from.
	 * @returns {number} Returns the index of the found element, else `-1`.
	 * @example
	 *
	 * var users = [
	 *   { 'user': 'barney',  'active': false },
	 *   { 'user': 'fred',    'active': false },
	 *   { 'user': 'pebbles', 'active': true }
	 * ];
	 *
	 * _.findIndex(users, function(o) { return o.user == 'barney'; });
	 * // => 0
	 *
	 * // The `_.matches` iteratee shorthand.
	 * _.findIndex(users, { 'user': 'fred', 'active': false });
	 * // => 1
	 *
	 * // The `_.matchesProperty` iteratee shorthand.
	 * _.findIndex(users, ['active', false]);
	 * // => 0
	 *
	 * // The `_.property` iteratee shorthand.
	 * _.findIndex(users, 'active');
	 * // => 2
	 */
	function findIndex(array, predicate, fromIndex) {
	  var length = array == null ? 0 : array.length;
	  if (!length) {
	    return -1;
	  }
	  var index = fromIndex == null ? 0 : toInteger(fromIndex);
	  if (index < 0) {
	    index = nativeMax(length + index, 0);
	  }
	  return baseFindIndex(array, baseIteratee(predicate, 3), index);
	}

	module.exports = findIndex;


/***/ },

/***/ 852:
/***/ function(module, exports, __webpack_require__) {

	var flatten = __webpack_require__(853),
	    overRest = __webpack_require__(561),
	    setToString = __webpack_require__(563);

	/**
	 * A specialized version of `baseRest` which flattens the rest array.
	 *
	 * @private
	 * @param {Function} func The function to apply a rest parameter to.
	 * @returns {Function} Returns the new function.
	 */
	function flatRest(func) {
	  return setToString(overRest(func, undefined, flatten), func + '');
	}

	module.exports = flatRest;


/***/ },

/***/ 853:
/***/ function(module, exports, __webpack_require__) {

	var baseFlatten = __webpack_require__(854);

	/**
	 * Flattens `array` a single level deep.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Array
	 * @param {Array} array The array to flatten.
	 * @returns {Array} Returns the new flattened array.
	 * @example
	 *
	 * _.flatten([1, [2, [3, [4]], 5]]);
	 * // => [1, 2, [3, [4]], 5]
	 */
	function flatten(array) {
	  var length = array == null ? 0 : array.length;
	  return length ? baseFlatten(array, 1) : [];
	}

	module.exports = flatten;


/***/ },

/***/ 1092:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.withRouter = exports.matchPath = exports.Switch = exports.StaticRouter = exports.Router = exports.Route = exports.Redirect = exports.Prompt = exports.MemoryRouter = undefined;

	var _MemoryRouter2 = __webpack_require__(488);

	var _MemoryRouter3 = _interopRequireDefault(_MemoryRouter2);

	var _Prompt2 = __webpack_require__(497);

	var _Prompt3 = _interopRequireDefault(_Prompt2);

	var _Redirect2 = __webpack_require__(499);

	var _Redirect3 = _interopRequireDefault(_Redirect2);

	var _Route2 = __webpack_require__(492);

	var _Route3 = _interopRequireDefault(_Route2);

	var _Router2 = __webpack_require__(483);

	var _Router3 = _interopRequireDefault(_Router2);

	var _StaticRouter2 = __webpack_require__(502);

	var _StaticRouter3 = _interopRequireDefault(_StaticRouter2);

	var _Switch2 = __webpack_require__(504);

	var _Switch3 = _interopRequireDefault(_Switch2);

	var _matchPath2 = __webpack_require__(493);

	var _matchPath3 = _interopRequireDefault(_matchPath2);

	var _withRouter2 = __webpack_require__(507);

	var _withRouter3 = _interopRequireDefault(_withRouter2);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.MemoryRouter = _MemoryRouter3.default;
	exports.Prompt = _Prompt3.default;
	exports.Redirect = _Redirect3.default;
	exports.Route = _Route3.default;
	exports.Router = _Router3.default;
	exports.StaticRouter = _StaticRouter3.default;
	exports.Switch = _Switch3.default;
	exports.matchPath = _matchPath3.default;
	exports.withRouter = _withRouter3.default;

/***/ },

/***/ 1551:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.getEmptyImage = exports.NativeTypes = undefined;
	exports.default = createHTML5Backend;

	var _HTML5Backend = __webpack_require__(1552);

	var _HTML5Backend2 = _interopRequireDefault(_HTML5Backend);

	var _getEmptyImage = __webpack_require__(1567);

	var _getEmptyImage2 = _interopRequireDefault(_getEmptyImage);

	var _NativeTypes = __webpack_require__(1566);

	var NativeTypes = _interopRequireWildcard(_NativeTypes);

	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.NativeTypes = NativeTypes;
	exports.getEmptyImage = _getEmptyImage2.default;
	function createHTML5Backend(manager) {
		return new _HTML5Backend2.default(manager);
	}

/***/ },

/***/ 1552:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /* eslint-disable no-underscore-dangle */


	var _defaults = __webpack_require__(1553);

	var _defaults2 = _interopRequireDefault(_defaults);

	var _shallowEqual = __webpack_require__(1554);

	var _shallowEqual2 = _interopRequireDefault(_shallowEqual);

	var _EnterLeaveCounter = __webpack_require__(1555);

	var _EnterLeaveCounter2 = _interopRequireDefault(_EnterLeaveCounter);

	var _BrowserDetector = __webpack_require__(1562);

	var _OffsetUtils = __webpack_require__(1563);

	var _NativeDragSources = __webpack_require__(1565);

	var _NativeTypes = __webpack_require__(1566);

	var NativeTypes = _interopRequireWildcard(_NativeTypes);

	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var HTML5Backend = function () {
		function HTML5Backend(manager) {
			_classCallCheck(this, HTML5Backend);

			this.actions = manager.getActions();
			this.monitor = manager.getMonitor();
			this.registry = manager.getRegistry();
			this.context = manager.getContext();

			this.sourcePreviewNodes = {};
			this.sourcePreviewNodeOptions = {};
			this.sourceNodes = {};
			this.sourceNodeOptions = {};
			this.enterLeaveCounter = new _EnterLeaveCounter2.default();

			this.dragStartSourceIds = [];
			this.dropTargetIds = [];
			this.dragEnterTargetIds = [];
			this.currentNativeSource = null;
			this.currentNativeHandle = null;
			this.currentDragSourceNode = null;
			this.currentDragSourceNodeOffset = null;
			this.currentDragSourceNodeOffsetChanged = false;
			this.altKeyPressed = false;

			this.getSourceClientOffset = this.getSourceClientOffset.bind(this);
			this.handleTopDragStart = this.handleTopDragStart.bind(this);
			this.handleTopDragStartCapture = this.handleTopDragStartCapture.bind(this);
			this.handleTopDragEndCapture = this.handleTopDragEndCapture.bind(this);
			this.handleTopDragEnter = this.handleTopDragEnter.bind(this);
			this.handleTopDragEnterCapture = this.handleTopDragEnterCapture.bind(this);
			this.handleTopDragLeaveCapture = this.handleTopDragLeaveCapture.bind(this);
			this.handleTopDragOver = this.handleTopDragOver.bind(this);
			this.handleTopDragOverCapture = this.handleTopDragOverCapture.bind(this);
			this.handleTopDrop = this.handleTopDrop.bind(this);
			this.handleTopDropCapture = this.handleTopDropCapture.bind(this);
			this.handleSelectStart = this.handleSelectStart.bind(this);
			this.endDragIfSourceWasRemovedFromDOM = this.endDragIfSourceWasRemovedFromDOM.bind(this);
			this.endDragNativeItem = this.endDragNativeItem.bind(this);
			this.asyncEndDragNativeItem = this.asyncEndDragNativeItem.bind(this);
			this.isNodeInDocument = this.isNodeInDocument.bind(this);
		}

		_createClass(HTML5Backend, [{
			key: 'setup',
			value: function setup() {
				if (this.window === undefined) {
					return;
				}

				if (this.window.__isReactDndBackendSetUp) {
					throw new Error('Cannot have two HTML5 backends at the same time.');
				}
				this.window.__isReactDndBackendSetUp = true;
				this.addEventListeners(this.window);
			}
		}, {
			key: 'teardown',
			value: function teardown() {
				if (this.window === undefined) {
					return;
				}

				this.window.__isReactDndBackendSetUp = false;
				this.removeEventListeners(this.window);
				this.clearCurrentDragSourceNode();
				if (this.asyncEndDragFrameId) {
					this.window.cancelAnimationFrame(this.asyncEndDragFrameId);
				}
			}
		}, {
			key: 'addEventListeners',
			value: function addEventListeners(target) {
				// SSR Fix (https://github.com/react-dnd/react-dnd/pull/813
				if (!target.addEventListener) {
					return;
				}
				target.addEventListener('dragstart', this.handleTopDragStart);
				target.addEventListener('dragstart', this.handleTopDragStartCapture, true);
				target.addEventListener('dragend', this.handleTopDragEndCapture, true);
				target.addEventListener('dragenter', this.handleTopDragEnter);
				target.addEventListener('dragenter', this.handleTopDragEnterCapture, true);
				target.addEventListener('dragleave', this.handleTopDragLeaveCapture, true);
				target.addEventListener('dragover', this.handleTopDragOver);
				target.addEventListener('dragover', this.handleTopDragOverCapture, true);
				target.addEventListener('drop', this.handleTopDrop);
				target.addEventListener('drop', this.handleTopDropCapture, true);
			}
		}, {
			key: 'removeEventListeners',
			value: function removeEventListeners(target) {
				// SSR Fix (https://github.com/react-dnd/react-dnd/pull/813
				if (!target.removeEventListener) {
					return;
				}
				target.removeEventListener('dragstart', this.handleTopDragStart);
				target.removeEventListener('dragstart', this.handleTopDragStartCapture, true);
				target.removeEventListener('dragend', this.handleTopDragEndCapture, true);
				target.removeEventListener('dragenter', this.handleTopDragEnter);
				target.removeEventListener('dragenter', this.handleTopDragEnterCapture, true);
				target.removeEventListener('dragleave', this.handleTopDragLeaveCapture, true);
				target.removeEventListener('dragover', this.handleTopDragOver);
				target.removeEventListener('dragover', this.handleTopDragOverCapture, true);
				target.removeEventListener('drop', this.handleTopDrop);
				target.removeEventListener('drop', this.handleTopDropCapture, true);
			}
		}, {
			key: 'connectDragPreview',
			value: function connectDragPreview(sourceId, node, options) {
				var _this = this;

				this.sourcePreviewNodeOptions[sourceId] = options;
				this.sourcePreviewNodes[sourceId] = node;

				return function () {
					delete _this.sourcePreviewNodes[sourceId];
					delete _this.sourcePreviewNodeOptions[sourceId];
				};
			}
		}, {
			key: 'connectDragSource',
			value: function connectDragSource(sourceId, node, options) {
				var _this2 = this;

				this.sourceNodes[sourceId] = node;
				this.sourceNodeOptions[sourceId] = options;

				var handleDragStart = function handleDragStart(e) {
					return _this2.handleDragStart(e, sourceId);
				};
				var handleSelectStart = function handleSelectStart(e) {
					return _this2.handleSelectStart(e, sourceId);
				};

				node.setAttribute('draggable', true);
				node.addEventListener('dragstart', handleDragStart);
				node.addEventListener('selectstart', handleSelectStart);

				return function () {
					delete _this2.sourceNodes[sourceId];
					delete _this2.sourceNodeOptions[sourceId];

					node.removeEventListener('dragstart', handleDragStart);
					node.removeEventListener('selectstart', handleSelectStart);
					node.setAttribute('draggable', false);
				};
			}
		}, {
			key: 'connectDropTarget',
			value: function connectDropTarget(targetId, node) {
				var _this3 = this;

				var handleDragEnter = function handleDragEnter(e) {
					return _this3.handleDragEnter(e, targetId);
				};
				var handleDragOver = function handleDragOver(e) {
					return _this3.handleDragOver(e, targetId);
				};
				var handleDrop = function handleDrop(e) {
					return _this3.handleDrop(e, targetId);
				};

				node.addEventListener('dragenter', handleDragEnter);
				node.addEventListener('dragover', handleDragOver);
				node.addEventListener('drop', handleDrop);

				return function () {
					node.removeEventListener('dragenter', handleDragEnter);
					node.removeEventListener('dragover', handleDragOver);
					node.removeEventListener('drop', handleDrop);
				};
			}
		}, {
			key: 'getCurrentSourceNodeOptions',
			value: function getCurrentSourceNodeOptions() {
				var sourceId = this.monitor.getSourceId();
				var sourceNodeOptions = this.sourceNodeOptions[sourceId];

				return (0, _defaults2.default)(sourceNodeOptions || {}, {
					dropEffect: this.altKeyPressed ? 'copy' : 'move'
				});
			}
		}, {
			key: 'getCurrentDropEffect',
			value: function getCurrentDropEffect() {
				if (this.isDraggingNativeItem()) {
					// It makes more sense to default to 'copy' for native resources
					return 'copy';
				}

				return this.getCurrentSourceNodeOptions().dropEffect;
			}
		}, {
			key: 'getCurrentSourcePreviewNodeOptions',
			value: function getCurrentSourcePreviewNodeOptions() {
				var sourceId = this.monitor.getSourceId();
				var sourcePreviewNodeOptions = this.sourcePreviewNodeOptions[sourceId];

				return (0, _defaults2.default)(sourcePreviewNodeOptions || {}, {
					anchorX: 0.5,
					anchorY: 0.5,
					captureDraggingState: false
				});
			}
		}, {
			key: 'getSourceClientOffset',
			value: function getSourceClientOffset(sourceId) {
				return (0, _OffsetUtils.getNodeClientOffset)(this.sourceNodes[sourceId]);
			}
		}, {
			key: 'isDraggingNativeItem',
			value: function isDraggingNativeItem() {
				var itemType = this.monitor.getItemType();
				return Object.keys(NativeTypes).some(function (key) {
					return NativeTypes[key] === itemType;
				});
			}
		}, {
			key: 'beginDragNativeItem',
			value: function beginDragNativeItem(type) {
				this.clearCurrentDragSourceNode();

				var SourceType = (0, _NativeDragSources.createNativeDragSource)(type);
				this.currentNativeSource = new SourceType();
				this.currentNativeHandle = this.registry.addSource(type, this.currentNativeSource);
				this.actions.beginDrag([this.currentNativeHandle]);

				// On Firefox, if mouseover fires, the drag is over but browser failed to tell us.
				// See https://bugzilla.mozilla.org/show_bug.cgi?id=656164
				// This is not true for other browsers.
				if ((0, _BrowserDetector.isFirefox)()) {
					this.window.addEventListener('mouseover', this.asyncEndDragNativeItem, true);
				}
			}
		}, {
			key: 'asyncEndDragNativeItem',
			value: function asyncEndDragNativeItem() {
				this.asyncEndDragFrameId = this.window.requestAnimationFrame(this.endDragNativeItem);
				if ((0, _BrowserDetector.isFirefox)()) {
					this.window.removeEventListener('mouseover', this.asyncEndDragNativeItem, true);
					this.enterLeaveCounter.reset();
				}
			}
		}, {
			key: 'endDragNativeItem',
			value: function endDragNativeItem() {
				if (!this.isDraggingNativeItem()) {
					return;
				}

				this.actions.endDrag();
				this.registry.removeSource(this.currentNativeHandle);
				this.currentNativeHandle = null;
				this.currentNativeSource = null;
			}
		}, {
			key: 'isNodeInDocument',
			value: function isNodeInDocument(node) {
				// Check the node either in the main document or in the current context
				return document.body.contains(node) || this.window ? this.window.document.body.contains(node) : false;
			}
		}, {
			key: 'endDragIfSourceWasRemovedFromDOM',
			value: function endDragIfSourceWasRemovedFromDOM() {
				var node = this.currentDragSourceNode;
				if (this.isNodeInDocument(node)) {
					return;
				}

				if (this.clearCurrentDragSourceNode()) {
					this.actions.endDrag();
				}
			}
		}, {
			key: 'setCurrentDragSourceNode',
			value: function setCurrentDragSourceNode(node) {
				this.clearCurrentDragSourceNode();
				this.currentDragSourceNode = node;
				this.currentDragSourceNodeOffset = (0, _OffsetUtils.getNodeClientOffset)(node);
				this.currentDragSourceNodeOffsetChanged = false;

				// Receiving a mouse event in the middle of a dragging operation
				// means it has ended and the drag source node disappeared from DOM,
				// so the browser didn't dispatch the dragend event.
				this.window.addEventListener('mousemove', this.endDragIfSourceWasRemovedFromDOM, true);
			}
		}, {
			key: 'clearCurrentDragSourceNode',
			value: function clearCurrentDragSourceNode() {
				if (this.currentDragSourceNode) {
					this.currentDragSourceNode = null;
					this.currentDragSourceNodeOffset = null;
					this.currentDragSourceNodeOffsetChanged = false;
					this.window.removeEventListener('mousemove', this.endDragIfSourceWasRemovedFromDOM, true);
					return true;
				}

				return false;
			}
		}, {
			key: 'checkIfCurrentDragSourceRectChanged',
			value: function checkIfCurrentDragSourceRectChanged() {
				var node = this.currentDragSourceNode;
				if (!node) {
					return false;
				}

				if (this.currentDragSourceNodeOffsetChanged) {
					return true;
				}

				this.currentDragSourceNodeOffsetChanged = !(0, _shallowEqual2.default)((0, _OffsetUtils.getNodeClientOffset)(node), this.currentDragSourceNodeOffset);

				return this.currentDragSourceNodeOffsetChanged;
			}
		}, {
			key: 'handleTopDragStartCapture',
			value: function handleTopDragStartCapture() {
				this.clearCurrentDragSourceNode();
				this.dragStartSourceIds = [];
			}
		}, {
			key: 'handleDragStart',
			value: function handleDragStart(e, sourceId) {
				this.dragStartSourceIds.unshift(sourceId);
			}
		}, {
			key: 'handleTopDragStart',
			value: function handleTopDragStart(e) {
				var _this4 = this;

				var dragStartSourceIds = this.dragStartSourceIds;

				this.dragStartSourceIds = null;

				var clientOffset = (0, _OffsetUtils.getEventClientOffset)(e);

				// Avoid crashing if we missed a drop event or our previous drag died
				if (this.monitor.isDragging()) {
					this.actions.endDrag();
				}

				// Don't publish the source just yet (see why below)
				this.actions.beginDrag(dragStartSourceIds, {
					publishSource: false,
					getSourceClientOffset: this.getSourceClientOffset,
					clientOffset: clientOffset
				});

				var dataTransfer = e.dataTransfer;

				var nativeType = (0, _NativeDragSources.matchNativeItemType)(dataTransfer);

				if (this.monitor.isDragging()) {
					if (typeof dataTransfer.setDragImage === 'function') {
						// Use custom drag image if user specifies it.
						// If child drag source refuses drag but parent agrees,
						// use parent's node as drag image. Neither works in IE though.
						var sourceId = this.monitor.getSourceId();
						var sourceNode = this.sourceNodes[sourceId];
						var dragPreview = this.sourcePreviewNodes[sourceId] || sourceNode;

						var _getCurrentSourcePrev = this.getCurrentSourcePreviewNodeOptions(),
						    anchorX = _getCurrentSourcePrev.anchorX,
						    anchorY = _getCurrentSourcePrev.anchorY,
						    offsetX = _getCurrentSourcePrev.offsetX,
						    offsetY = _getCurrentSourcePrev.offsetY;

						var anchorPoint = { anchorX: anchorX, anchorY: anchorY };
						var offsetPoint = { offsetX: offsetX, offsetY: offsetY };
						var dragPreviewOffset = (0, _OffsetUtils.getDragPreviewOffset)(sourceNode, dragPreview, clientOffset, anchorPoint, offsetPoint);

						dataTransfer.setDragImage(dragPreview, dragPreviewOffset.x, dragPreviewOffset.y);
					}

					try {
						// Firefox won't drag without setting data
						dataTransfer.setData('application/json', {});
					} catch (err) {}
					// IE doesn't support MIME types in setData


					// Store drag source node so we can check whether
					// it is removed from DOM and trigger endDrag manually.
					this.setCurrentDragSourceNode(e.target);

					// Now we are ready to publish the drag source.. or are we not?

					var _getCurrentSourcePrev2 = this.getCurrentSourcePreviewNodeOptions(),
					    captureDraggingState = _getCurrentSourcePrev2.captureDraggingState;

					if (!captureDraggingState) {
						// Usually we want to publish it in the next tick so that browser
						// is able to screenshot the current (not yet dragging) state.
						//
						// It also neatly avoids a situation where render() returns null
						// in the same tick for the source element, and browser freaks out.
						setTimeout(function () {
							return _this4.actions.publishDragSource();
						});
					} else {
						// In some cases the user may want to override this behavior, e.g.
						// to work around IE not supporting custom drag previews.
						//
						// When using a custom drag layer, the only way to prevent
						// the default drag preview from drawing in IE is to screenshot
						// the dragging state in which the node itself has zero opacity
						// and height. In this case, though, returning null from render()
						// will abruptly end the dragging, which is not obvious.
						//
						// This is the reason such behavior is strictly opt-in.
						this.actions.publishDragSource();
					}
				} else if (nativeType) {
					// A native item (such as URL) dragged from inside the document
					this.beginDragNativeItem(nativeType);
				} else if (!dataTransfer.types && (!e.target.hasAttribute || !e.target.hasAttribute('draggable'))) {
					// Looks like a Safari bug: dataTransfer.types is null, but there was no draggable.
					// Just let it drag. It's a native type (URL or text) and will be picked up in
					// dragenter handler.
					return; // eslint-disable-line no-useless-return
				} else {
					// If by this time no drag source reacted, tell browser not to drag.
					e.preventDefault();
				}
			}
		}, {
			key: 'handleTopDragEndCapture',
			value: function handleTopDragEndCapture() {
				if (this.clearCurrentDragSourceNode()) {
					// Firefox can dispatch this event in an infinite loop
					// if dragend handler does something like showing an alert.
					// Only proceed if we have not handled it already.
					this.actions.endDrag();
				}
			}
		}, {
			key: 'handleTopDragEnterCapture',
			value: function handleTopDragEnterCapture(e) {
				this.dragEnterTargetIds = [];

				var isFirstEnter = this.enterLeaveCounter.enter(e.target);
				if (!isFirstEnter || this.monitor.isDragging()) {
					return;
				}

				var dataTransfer = e.dataTransfer;

				var nativeType = (0, _NativeDragSources.matchNativeItemType)(dataTransfer);

				if (nativeType) {
					// A native item (such as file or URL) dragged from outside the document
					this.beginDragNativeItem(nativeType);
				}
			}
		}, {
			key: 'handleDragEnter',
			value: function handleDragEnter(e, targetId) {
				this.dragEnterTargetIds.unshift(targetId);
			}
		}, {
			key: 'handleTopDragEnter',
			value: function handleTopDragEnter(e) {
				var _this5 = this;

				var dragEnterTargetIds = this.dragEnterTargetIds;

				this.dragEnterTargetIds = [];

				if (!this.monitor.isDragging()) {
					// This is probably a native item type we don't understand.
					return;
				}

				this.altKeyPressed = e.altKey;

				if (!(0, _BrowserDetector.isFirefox)()) {
					// Don't emit hover in `dragenter` on Firefox due to an edge case.
					// If the target changes position as the result of `dragenter`, Firefox
					// will still happily dispatch `dragover` despite target being no longer
					// there. The easy solution is to only fire `hover` in `dragover` on FF.
					this.actions.hover(dragEnterTargetIds, {
						clientOffset: (0, _OffsetUtils.getEventClientOffset)(e)
					});
				}

				var canDrop = dragEnterTargetIds.some(function (targetId) {
					return _this5.monitor.canDropOnTarget(targetId);
				});

				if (canDrop) {
					// IE requires this to fire dragover events
					e.preventDefault();
					e.dataTransfer.dropEffect = this.getCurrentDropEffect();
				}
			}
		}, {
			key: 'handleTopDragOverCapture',
			value: function handleTopDragOverCapture() {
				this.dragOverTargetIds = [];
			}
		}, {
			key: 'handleDragOver',
			value: function handleDragOver(e, targetId) {
				this.dragOverTargetIds.unshift(targetId);
			}
		}, {
			key: 'handleTopDragOver',
			value: function handleTopDragOver(e) {
				var _this6 = this;

				var dragOverTargetIds = this.dragOverTargetIds;

				this.dragOverTargetIds = [];

				if (!this.monitor.isDragging()) {
					// This is probably a native item type we don't understand.
					// Prevent default "drop and blow away the whole document" action.
					e.preventDefault();
					e.dataTransfer.dropEffect = 'none';
					return;
				}

				this.altKeyPressed = e.altKey;

				this.actions.hover(dragOverTargetIds, {
					clientOffset: (0, _OffsetUtils.getEventClientOffset)(e)
				});

				var canDrop = dragOverTargetIds.some(function (targetId) {
					return _this6.monitor.canDropOnTarget(targetId);
				});

				if (canDrop) {
					// Show user-specified drop effect.
					e.preventDefault();
					e.dataTransfer.dropEffect = this.getCurrentDropEffect();
				} else if (this.isDraggingNativeItem()) {
					// Don't show a nice cursor but still prevent default
					// "drop and blow away the whole document" action.
					e.preventDefault();
					e.dataTransfer.dropEffect = 'none';
				} else if (this.checkIfCurrentDragSourceRectChanged()) {
					// Prevent animating to incorrect position.
					// Drop effect must be other than 'none' to prevent animation.
					e.preventDefault();
					e.dataTransfer.dropEffect = 'move';
				}
			}
		}, {
			key: 'handleTopDragLeaveCapture',
			value: function handleTopDragLeaveCapture(e) {
				if (this.isDraggingNativeItem()) {
					e.preventDefault();
				}

				var isLastLeave = this.enterLeaveCounter.leave(e.target);
				if (!isLastLeave) {
					return;
				}

				if (this.isDraggingNativeItem()) {
					this.endDragNativeItem();
				}
			}
		}, {
			key: 'handleTopDropCapture',
			value: function handleTopDropCapture(e) {
				this.dropTargetIds = [];
				e.preventDefault();

				if (this.isDraggingNativeItem()) {
					this.currentNativeSource.mutateItemByReadingDataTransfer(e.dataTransfer);
				}

				this.enterLeaveCounter.reset();
			}
		}, {
			key: 'handleDrop',
			value: function handleDrop(e, targetId) {
				this.dropTargetIds.unshift(targetId);
			}
		}, {
			key: 'handleTopDrop',
			value: function handleTopDrop(e) {
				var dropTargetIds = this.dropTargetIds;

				this.dropTargetIds = [];

				this.actions.hover(dropTargetIds, {
					clientOffset: (0, _OffsetUtils.getEventClientOffset)(e)
				});
				this.actions.drop({ dropEffect: this.getCurrentDropEffect() });

				if (this.isDraggingNativeItem()) {
					this.endDragNativeItem();
				} else {
					this.endDragIfSourceWasRemovedFromDOM();
				}
			}
		}, {
			key: 'handleSelectStart',
			value: function handleSelectStart(e) {
				var target = e.target;

				// Only IE requires us to explicitly say
				// we want drag drop operation to start

				if (typeof target.dragDrop !== 'function') {
					return;
				}

				// Inputs and textareas should be selectable
				if (target.tagName === 'INPUT' || target.tagName === 'SELECT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
					return;
				}

				// For other targets, ask IE
				// to enable drag and drop
				e.preventDefault();
				target.dragDrop();
			}
		}, {
			key: 'window',
			get: function get() {
				if (this.context && this.context.window) {
					return this.context.window;
				} else if (typeof window !== 'undefined') {
					return window;
				}
				return undefined;
			}
		}]);

		return HTML5Backend;
	}();

	exports.default = HTML5Backend;

/***/ },

/***/ 1553:
/***/ function(module, exports, __webpack_require__) {

	var baseRest = __webpack_require__(559),
	    eq = __webpack_require__(316),
	    isIterateeCall = __webpack_require__(567),
	    keysIn = __webpack_require__(553);

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Assigns own and inherited enumerable string keyed properties of source
	 * objects to the destination object for all destination properties that
	 * resolve to `undefined`. Source objects are applied from left to right.
	 * Once a property is set, additional values of the same property are ignored.
	 *
	 * **Note:** This method mutates `object`.
	 *
	 * @static
	 * @since 0.1.0
	 * @memberOf _
	 * @category Object
	 * @param {Object} object The destination object.
	 * @param {...Object} [sources] The source objects.
	 * @returns {Object} Returns `object`.
	 * @see _.defaultsDeep
	 * @example
	 *
	 * _.defaults({ 'a': 1 }, { 'b': 2 }, { 'a': 3 });
	 * // => { 'a': 1, 'b': 2 }
	 */
	var defaults = baseRest(function(object, sources) {
	  object = Object(object);

	  var index = -1;
	  var length = sources.length;
	  var guard = length > 2 ? sources[2] : undefined;

	  if (guard && isIterateeCall(sources[0], sources[1], guard)) {
	    length = 1;
	  }

	  while (++index < length) {
	    var source = sources[index];
	    var props = keysIn(source);
	    var propsIndex = -1;
	    var propsLength = props.length;

	    while (++propsIndex < propsLength) {
	      var key = props[propsIndex];
	      var value = object[key];

	      if (value === undefined ||
	          (eq(value, objectProto[key]) && !hasOwnProperty.call(object, key))) {
	        object[key] = source[key];
	      }
	    }
	  }

	  return object;
	});

	module.exports = defaults;


/***/ },

/***/ 1554:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = shallowEqual;
	function shallowEqual(objA, objB) {
		if (objA === objB) {
			return true;
		}

		var keysA = Object.keys(objA);
		var keysB = Object.keys(objB);

		if (keysA.length !== keysB.length) {
			return false;
		}

		// Test for A's keys different from B.
		var hasOwn = Object.prototype.hasOwnProperty;
		for (var i = 0; i < keysA.length; i += 1) {
			if (!hasOwn.call(objB, keysA[i]) || objA[keysA[i]] !== objB[keysA[i]]) {
				return false;
			}

			var valA = objA[keysA[i]];
			var valB = objB[keysA[i]];

			if (valA !== valB) {
				return false;
			}
		}

		return true;
	}

/***/ },

/***/ 1555:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _union = __webpack_require__(1556);

	var _union2 = _interopRequireDefault(_union);

	var _without = __webpack_require__(1560);

	var _without2 = _interopRequireDefault(_without);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var EnterLeaveCounter = function () {
		function EnterLeaveCounter() {
			_classCallCheck(this, EnterLeaveCounter);

			this.entered = [];
		}

		_createClass(EnterLeaveCounter, [{
			key: 'enter',
			value: function enter(enteringNode) {
				var previousLength = this.entered.length;

				var isNodeEntered = function isNodeEntered(node) {
					return document.documentElement.contains(node) && (!node.contains || node.contains(enteringNode));
				};

				this.entered = (0, _union2.default)(this.entered.filter(isNodeEntered), [enteringNode]);

				return previousLength === 0 && this.entered.length > 0;
			}
		}, {
			key: 'leave',
			value: function leave(leavingNode) {
				var previousLength = this.entered.length;

				this.entered = (0, _without2.default)(this.entered.filter(function (node) {
					return document.documentElement.contains(node);
				}), leavingNode);

				return previousLength > 0 && this.entered.length === 0;
			}
		}, {
			key: 'reset',
			value: function reset() {
				this.entered = [];
			}
		}]);

		return EnterLeaveCounter;
	}();

	exports.default = EnterLeaveCounter;

/***/ },

/***/ 1556:
/***/ function(module, exports, __webpack_require__) {

	var baseFlatten = __webpack_require__(854),
	    baseRest = __webpack_require__(559),
	    baseUniq = __webpack_require__(1557),
	    isArrayLikeObject = __webpack_require__(541);

	/**
	 * Creates an array of unique values, in order, from all given arrays using
	 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
	 * for equality comparisons.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Array
	 * @param {...Array} [arrays] The arrays to inspect.
	 * @returns {Array} Returns the new array of combined values.
	 * @example
	 *
	 * _.union([2], [1, 2]);
	 * // => [2, 1]
	 */
	var union = baseRest(function(arrays) {
	  return baseUniq(baseFlatten(arrays, 1, isArrayLikeObject, true));
	});

	module.exports = union;


/***/ },

/***/ 1557:
/***/ function(module, exports, __webpack_require__) {

	var SetCache = __webpack_require__(828),
	    arrayIncludes = __webpack_require__(937),
	    arrayIncludesWith = __webpack_require__(941),
	    cacheHas = __webpack_require__(832),
	    createSet = __webpack_require__(1558),
	    setToArray = __webpack_require__(835);

	/** Used as the size to enable large array optimizations. */
	var LARGE_ARRAY_SIZE = 200;

	/**
	 * The base implementation of `_.uniqBy` without support for iteratee shorthands.
	 *
	 * @private
	 * @param {Array} array The array to inspect.
	 * @param {Function} [iteratee] The iteratee invoked per element.
	 * @param {Function} [comparator] The comparator invoked per element.
	 * @returns {Array} Returns the new duplicate free array.
	 */
	function baseUniq(array, iteratee, comparator) {
	  var index = -1,
	      includes = arrayIncludes,
	      length = array.length,
	      isCommon = true,
	      result = [],
	      seen = result;

	  if (comparator) {
	    isCommon = false;
	    includes = arrayIncludesWith;
	  }
	  else if (length >= LARGE_ARRAY_SIZE) {
	    var set = iteratee ? null : createSet(array);
	    if (set) {
	      return setToArray(set);
	    }
	    isCommon = false;
	    includes = cacheHas;
	    seen = new SetCache;
	  }
	  else {
	    seen = iteratee ? [] : result;
	  }
	  outer:
	  while (++index < length) {
	    var value = array[index],
	        computed = iteratee ? iteratee(value) : value;

	    value = (comparator || value !== 0) ? value : 0;
	    if (isCommon && computed === computed) {
	      var seenIndex = seen.length;
	      while (seenIndex--) {
	        if (seen[seenIndex] === computed) {
	          continue outer;
	        }
	      }
	      if (iteratee) {
	        seen.push(computed);
	      }
	      result.push(value);
	    }
	    else if (!includes(seen, computed, comparator)) {
	      if (seen !== result) {
	        seen.push(computed);
	      }
	      result.push(value);
	    }
	  }
	  return result;
	}

	module.exports = baseUniq;


/***/ },

/***/ 1558:
/***/ function(module, exports, __webpack_require__) {

	var Set = __webpack_require__(809),
	    noop = __webpack_require__(1559),
	    setToArray = __webpack_require__(835);

	/** Used as references for various `Number` constants. */
	var INFINITY = 1 / 0;

	/**
	 * Creates a set object of `values`.
	 *
	 * @private
	 * @param {Array} values The values to add to the set.
	 * @returns {Object} Returns the new set.
	 */
	var createSet = !(Set && (1 / setToArray(new Set([,-0]))[1]) == INFINITY) ? noop : function(values) {
	  return new Set(values);
	};

	module.exports = createSet;


/***/ },

/***/ 1559:
/***/ function(module, exports) {

	/**
	 * This method returns `undefined`.
	 *
	 * @static
	 * @memberOf _
	 * @since 2.3.0
	 * @category Util
	 * @example
	 *
	 * _.times(2, _.noop);
	 * // => [undefined, undefined]
	 */
	function noop() {
	  // No operation performed.
	}

	module.exports = noop;


/***/ },

/***/ 1560:
/***/ function(module, exports, __webpack_require__) {

	var baseDifference = __webpack_require__(1561),
	    baseRest = __webpack_require__(559),
	    isArrayLikeObject = __webpack_require__(541);

	/**
	 * Creates an array excluding all given values using
	 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
	 * for equality comparisons.
	 *
	 * **Note:** Unlike `_.pull`, this method returns a new array.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Array
	 * @param {Array} array The array to inspect.
	 * @param {...*} [values] The values to exclude.
	 * @returns {Array} Returns the new array of filtered values.
	 * @see _.difference, _.xor
	 * @example
	 *
	 * _.without([2, 1, 2, 3], 1, 2);
	 * // => [3]
	 */
	var without = baseRest(function(array, values) {
	  return isArrayLikeObject(array)
	    ? baseDifference(array, values)
	    : [];
	});

	module.exports = without;


/***/ },

/***/ 1561:
/***/ function(module, exports, __webpack_require__) {

	var SetCache = __webpack_require__(828),
	    arrayIncludes = __webpack_require__(937),
	    arrayIncludesWith = __webpack_require__(941),
	    arrayMap = __webpack_require__(329),
	    baseUnary = __webpack_require__(548),
	    cacheHas = __webpack_require__(832);

	/** Used as the size to enable large array optimizations. */
	var LARGE_ARRAY_SIZE = 200;

	/**
	 * The base implementation of methods like `_.difference` without support
	 * for excluding multiple arrays or iteratee shorthands.
	 *
	 * @private
	 * @param {Array} array The array to inspect.
	 * @param {Array} values The values to exclude.
	 * @param {Function} [iteratee] The iteratee invoked per element.
	 * @param {Function} [comparator] The comparator invoked per element.
	 * @returns {Array} Returns the new array of filtered values.
	 */
	function baseDifference(array, values, iteratee, comparator) {
	  var index = -1,
	      includes = arrayIncludes,
	      isCommon = true,
	      length = array.length,
	      result = [],
	      valuesLength = values.length;

	  if (!length) {
	    return result;
	  }
	  if (iteratee) {
	    values = arrayMap(values, baseUnary(iteratee));
	  }
	  if (comparator) {
	    includes = arrayIncludesWith;
	    isCommon = false;
	  }
	  else if (values.length >= LARGE_ARRAY_SIZE) {
	    includes = cacheHas;
	    isCommon = false;
	    values = new SetCache(values);
	  }
	  outer:
	  while (++index < length) {
	    var value = array[index],
	        computed = iteratee == null ? value : iteratee(value);

	    value = (comparator || value !== 0) ? value : 0;
	    if (isCommon && computed === computed) {
	      var valuesIndex = valuesLength;
	      while (valuesIndex--) {
	        if (values[valuesIndex] === computed) {
	          continue outer;
	        }
	      }
	      result.push(value);
	    }
	    else if (!includes(values, computed, comparator)) {
	      result.push(value);
	    }
	  }
	  return result;
	}

	module.exports = baseDifference;


/***/ },

/***/ 1562:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.isSafari = exports.isFirefox = undefined;

	var _memoize = __webpack_require__(294);

	var _memoize2 = _interopRequireDefault(_memoize);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var isFirefox = exports.isFirefox = (0, _memoize2.default)(function () {
	  return (/firefox/i.test(navigator.userAgent)
	  );
	});
	var isSafari = exports.isSafari = (0, _memoize2.default)(function () {
	  return Boolean(window.safari);
	});

/***/ },

/***/ 1563:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.getNodeClientOffset = getNodeClientOffset;
	exports.getEventClientOffset = getEventClientOffset;
	exports.getDragPreviewOffset = getDragPreviewOffset;

	var _BrowserDetector = __webpack_require__(1562);

	var _MonotonicInterpolant = __webpack_require__(1564);

	var _MonotonicInterpolant2 = _interopRequireDefault(_MonotonicInterpolant);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint
	   no-mixed-operators: off
	*/
	var ELEMENT_NODE = 1;

	function getNodeClientOffset(node) {
		var el = node.nodeType === ELEMENT_NODE ? node : node.parentElement;

		if (!el) {
			return null;
		}

		var _el$getBoundingClient = el.getBoundingClientRect(),
		    top = _el$getBoundingClient.top,
		    left = _el$getBoundingClient.left;

		return { x: left, y: top };
	}

	function getEventClientOffset(e) {
		return {
			x: e.clientX,
			y: e.clientY
		};
	}

	function isImageNode(node) {
		return node.nodeName === 'IMG' && ((0, _BrowserDetector.isFirefox)() || !document.documentElement.contains(node));
	}

	function getDragPreviewSize(isImage, dragPreview, sourceWidth, sourceHeight) {
		var dragPreviewWidth = isImage ? dragPreview.width : sourceWidth;
		var dragPreviewHeight = isImage ? dragPreview.height : sourceHeight;

		// Work around @2x coordinate discrepancies in browsers
		if ((0, _BrowserDetector.isSafari)() && isImage) {
			dragPreviewHeight /= window.devicePixelRatio;
			dragPreviewWidth /= window.devicePixelRatio;
		}
		return { dragPreviewWidth: dragPreviewWidth, dragPreviewHeight: dragPreviewHeight };
	}

	function getDragPreviewOffset(sourceNode, dragPreview, clientOffset, anchorPoint, offsetPoint) {
		// The browsers will use the image intrinsic size under different conditions.
		// Firefox only cares if it's an image, but WebKit also wants it to be detached.
		var isImage = isImageNode(dragPreview);
		var dragPreviewNode = isImage ? sourceNode : dragPreview;
		var dragPreviewNodeOffsetFromClient = getNodeClientOffset(dragPreviewNode);
		var offsetFromDragPreview = {
			x: clientOffset.x - dragPreviewNodeOffsetFromClient.x,
			y: clientOffset.y - dragPreviewNodeOffsetFromClient.y
		};
		var sourceWidth = sourceNode.offsetWidth,
		    sourceHeight = sourceNode.offsetHeight;
		var anchorX = anchorPoint.anchorX,
		    anchorY = anchorPoint.anchorY;

		var _getDragPreviewSize = getDragPreviewSize(isImage, dragPreview, sourceWidth, sourceHeight),
		    dragPreviewWidth = _getDragPreviewSize.dragPreviewWidth,
		    dragPreviewHeight = _getDragPreviewSize.dragPreviewHeight;

		var calculateYOffset = function calculateYOffset() {
			var interpolantY = new _MonotonicInterpolant2.default([0, 0.5, 1], [
			// Dock to the top
			offsetFromDragPreview.y,
			// Align at the center
			offsetFromDragPreview.y / sourceHeight * dragPreviewHeight,
			// Dock to the bottom
			offsetFromDragPreview.y + dragPreviewHeight - sourceHeight]);
			var y = interpolantY.interpolate(anchorY);
			// Work around Safari 8 positioning bug
			if ((0, _BrowserDetector.isSafari)() && isImage) {
				// We'll have to wait for @3x to see if this is entirely correct
				y += (window.devicePixelRatio - 1) * dragPreviewHeight;
			}
			return y;
		};

		var calculateXOffset = function calculateXOffset() {
			// Interpolate coordinates depending on anchor point
			// If you know a simpler way to do this, let me know
			var interpolantX = new _MonotonicInterpolant2.default([0, 0.5, 1], [
			// Dock to the left
			offsetFromDragPreview.x,
			// Align at the center
			offsetFromDragPreview.x / sourceWidth * dragPreviewWidth,
			// Dock to the right
			offsetFromDragPreview.x + dragPreviewWidth - sourceWidth]);
			return interpolantX.interpolate(anchorX);
		};

		// Force offsets if specified in the options.
		var offsetX = offsetPoint.offsetX,
		    offsetY = offsetPoint.offsetY;

		var isManualOffsetX = offsetX === 0 || offsetX;
		var isManualOffsetY = offsetY === 0 || offsetY;
		return {
			x: isManualOffsetX ? offsetX : calculateXOffset(),
			y: isManualOffsetY ? offsetY : calculateYOffset()
		};
	}

/***/ },

/***/ 1564:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	/* eslint
	   no-plusplus: off,
	   no-mixed-operators: off
	*/
	var MonotonicInterpolant = function () {
		function MonotonicInterpolant(xs, ys) {
			_classCallCheck(this, MonotonicInterpolant);

			var length = xs.length;

			// Rearrange xs and ys so that xs is sorted
			var indexes = [];
			for (var i = 0; i < length; i++) {
				indexes.push(i);
			}
			indexes.sort(function (a, b) {
				return xs[a] < xs[b] ? -1 : 1;
			});

			// Get consecutive differences and slopes
			var dys = [];
			var dxs = [];
			var ms = [];
			var dx = void 0;
			var dy = void 0;
			for (var _i = 0; _i < length - 1; _i++) {
				dx = xs[_i + 1] - xs[_i];
				dy = ys[_i + 1] - ys[_i];
				dxs.push(dx);
				dys.push(dy);
				ms.push(dy / dx);
			}

			// Get degree-1 coefficients
			var c1s = [ms[0]];
			for (var _i2 = 0; _i2 < dxs.length - 1; _i2++) {
				var _m = ms[_i2];
				var mNext = ms[_i2 + 1];
				if (_m * mNext <= 0) {
					c1s.push(0);
				} else {
					dx = dxs[_i2];
					var dxNext = dxs[_i2 + 1];
					var common = dx + dxNext;
					c1s.push(3 * common / ((common + dxNext) / _m + (common + dx) / mNext));
				}
			}
			c1s.push(ms[ms.length - 1]);

			// Get degree-2 and degree-3 coefficients
			var c2s = [];
			var c3s = [];
			var m = void 0;
			for (var _i3 = 0; _i3 < c1s.length - 1; _i3++) {
				m = ms[_i3];
				var c1 = c1s[_i3];
				var invDx = 1 / dxs[_i3];
				var _common = c1 + c1s[_i3 + 1] - m - m;
				c2s.push((m - c1 - _common) * invDx);
				c3s.push(_common * invDx * invDx);
			}

			this.xs = xs;
			this.ys = ys;
			this.c1s = c1s;
			this.c2s = c2s;
			this.c3s = c3s;
		}

		_createClass(MonotonicInterpolant, [{
			key: "interpolate",
			value: function interpolate(x) {
				var xs = this.xs,
				    ys = this.ys,
				    c1s = this.c1s,
				    c2s = this.c2s,
				    c3s = this.c3s;

				// The rightmost point in the dataset should give an exact result

				var i = xs.length - 1;
				if (x === xs[i]) {
					return ys[i];
				}

				// Search for the interval x is in, returning the corresponding y if x is one of the original xs
				var low = 0;
				var high = c3s.length - 1;
				var mid = void 0;
				while (low <= high) {
					mid = Math.floor(0.5 * (low + high));
					var xHere = xs[mid];
					if (xHere < x) {
						low = mid + 1;
					} else if (xHere > x) {
						high = mid - 1;
					} else {
						return ys[mid];
					}
				}
				i = Math.max(0, high);

				// Interpolate
				var diff = x - xs[i];
				var diffSq = diff * diff;
				return ys[i] + c1s[i] * diff + c2s[i] * diffSq + c3s[i] * diff * diffSq;
			}
		}]);

		return MonotonicInterpolant;
	}();

	exports.default = MonotonicInterpolant;

/***/ },

/***/ 1565:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _nativeTypesConfig;

	exports.createNativeDragSource = createNativeDragSource;
	exports.matchNativeItemType = matchNativeItemType;

	var _NativeTypes = __webpack_require__(1566);

	var NativeTypes = _interopRequireWildcard(_NativeTypes);

	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

	function _defineEnumerableProperties(obj, descs) { for (var key in descs) { var desc = descs[key]; desc.configurable = desc.enumerable = true; if ("value" in desc) desc.writable = true; Object.defineProperty(obj, key, desc); } return obj; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function getDataFromDataTransfer(dataTransfer, typesToTry, defaultValue) {
		var result = typesToTry.reduce(function (resultSoFar, typeToTry) {
			return resultSoFar || dataTransfer.getData(typeToTry);
		}, null);

		return result != null // eslint-disable-line eqeqeq
		? result : defaultValue;
	}

	var nativeTypesConfig = (_nativeTypesConfig = {}, _defineProperty(_nativeTypesConfig, NativeTypes.FILE, {
		exposeProperty: 'files',
		matchesTypes: ['Files'],
		getData: function getData(dataTransfer) {
			return Array.prototype.slice.call(dataTransfer.files);
		}
	}), _defineProperty(_nativeTypesConfig, NativeTypes.URL, {
		exposeProperty: 'urls',
		matchesTypes: ['Url', 'text/uri-list'],
		getData: function getData(dataTransfer, matchesTypes) {
			return getDataFromDataTransfer(dataTransfer, matchesTypes, '').split('\n');
		}
	}), _defineProperty(_nativeTypesConfig, NativeTypes.TEXT, {
		exposeProperty: 'text',
		matchesTypes: ['Text', 'text/plain'],
		getData: function getData(dataTransfer, matchesTypes) {
			return getDataFromDataTransfer(dataTransfer, matchesTypes, '');
		}
	}), _nativeTypesConfig);

	function createNativeDragSource(type) {
		var _nativeTypesConfig$ty = nativeTypesConfig[type],
		    exposeProperty = _nativeTypesConfig$ty.exposeProperty,
		    matchesTypes = _nativeTypesConfig$ty.matchesTypes,
		    getData = _nativeTypesConfig$ty.getData;


		return function () {
			function NativeDragSource() {
				var _item, _mutatorMap;

				_classCallCheck(this, NativeDragSource);

				this.item = (_item = {}, _mutatorMap = {}, _mutatorMap[exposeProperty] = _mutatorMap[exposeProperty] || {}, _mutatorMap[exposeProperty].get = function () {
					// eslint-disable-next-line no-console
					console.warn('Browser doesn\'t allow reading "' + exposeProperty + '" until the drop event.');
					return null;
				}, _defineEnumerableProperties(_item, _mutatorMap), _item);
			}

			_createClass(NativeDragSource, [{
				key: 'mutateItemByReadingDataTransfer',
				value: function mutateItemByReadingDataTransfer(dataTransfer) {
					delete this.item[exposeProperty];
					this.item[exposeProperty] = getData(dataTransfer, matchesTypes);
				}
			}, {
				key: 'canDrag',
				value: function canDrag() {
					return true;
				}
			}, {
				key: 'beginDrag',
				value: function beginDrag() {
					return this.item;
				}
			}, {
				key: 'isDragging',
				value: function isDragging(monitor, handle) {
					return handle === monitor.getSourceId();
				}
			}, {
				key: 'endDrag',
				value: function endDrag() {}
			}]);

			return NativeDragSource;
		}();
	}

	function matchNativeItemType(dataTransfer) {
		var dataTransferTypes = Array.prototype.slice.call(dataTransfer.types || []);

		return Object.keys(nativeTypesConfig).filter(function (nativeItemType) {
			var matchesTypes = nativeTypesConfig[nativeItemType].matchesTypes;

			return matchesTypes.some(function (t) {
				return dataTransferTypes.indexOf(t) > -1;
			});
		})[0] || null;
	}

/***/ },

/***/ 1566:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var FILE = exports.FILE = '__NATIVE_FILE__';
	var URL = exports.URL = '__NATIVE_URL__';
	var TEXT = exports.TEXT = '__NATIVE_TEXT__';

/***/ },

/***/ 1567:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = getEmptyImage;
	var emptyImage = void 0;
	function getEmptyImage() {
		if (!emptyImage) {
			emptyImage = new Image();
			emptyImage.src = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
		}

		return emptyImage;
	}

/***/ },

/***/ 1568:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _DragDropContext = __webpack_require__(1569);

	Object.defineProperty(exports, 'DragDropContext', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DragDropContext).default;
	  }
	});

	var _DragDropContextProvider = __webpack_require__(1592);

	Object.defineProperty(exports, 'DragDropContextProvider', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DragDropContextProvider).default;
	  }
	});

	var _DragLayer = __webpack_require__(1593);

	Object.defineProperty(exports, 'DragLayer', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DragLayer).default;
	  }
	});

	var _DragSource = __webpack_require__(1596);

	Object.defineProperty(exports, 'DragSource', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DragSource).default;
	  }
	});

	var _DropTarget = __webpack_require__(1611);

	Object.defineProperty(exports, 'DropTarget', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DropTarget).default;
	  }
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ },

/***/ 1569:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.unpackBackendForEs5Users = exports.createChildContext = exports.CHILD_CONTEXT_TYPES = undefined;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	exports.default = DragDropContext;

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _dndCore = __webpack_require__(1570);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _hoistNonReactStatics = __webpack_require__(380);

	var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

	var _checkDecoratorArguments = __webpack_require__(1591);

	var _checkDecoratorArguments2 = _interopRequireDefault(_checkDecoratorArguments);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var CHILD_CONTEXT_TYPES = exports.CHILD_CONTEXT_TYPES = {
		dragDropManager: _propTypes2.default.object.isRequired
	};

	var createChildContext = exports.createChildContext = function createChildContext(backend, context) {
		return {
			dragDropManager: new _dndCore.DragDropManager(backend, context)
		};
	};

	var unpackBackendForEs5Users = exports.unpackBackendForEs5Users = function unpackBackendForEs5Users(backendOrModule) {
		// Auto-detect ES6 default export for people still using ES5
		var backend = backendOrModule;
		if ((typeof backend === 'undefined' ? 'undefined' : _typeof(backend)) === 'object' && typeof backend.default === 'function') {
			backend = backend.default;
		}
		(0, _invariant2.default)(typeof backend === 'function', 'Expected the backend to be a function or an ES6 module exporting a default function. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-drop-context.html');
		return backend;
	};

	function DragDropContext(backendOrModule) {
		_checkDecoratorArguments2.default.apply(undefined, ['DragDropContext', 'backend'].concat(Array.prototype.slice.call(arguments))); // eslint-disable-line prefer-rest-params

		var backend = unpackBackendForEs5Users(backendOrModule);
		var childContext = createChildContext(backend);

		return function decorateContext(DecoratedComponent) {
			var _class, _temp;

			var displayName = DecoratedComponent.displayName || DecoratedComponent.name || 'Component';

			var DragDropContextContainer = (_temp = _class = function (_Component) {
				_inherits(DragDropContextContainer, _Component);

				function DragDropContextContainer() {
					_classCallCheck(this, DragDropContextContainer);

					return _possibleConstructorReturn(this, (DragDropContextContainer.__proto__ || Object.getPrototypeOf(DragDropContextContainer)).apply(this, arguments));
				}

				_createClass(DragDropContextContainer, [{
					key: 'getDecoratedComponentInstance',
					value: function getDecoratedComponentInstance() {
						(0, _invariant2.default)(this.child, 'In order to access an instance of the decorated component it can not be a stateless component.');
						return this.child;
					}
				}, {
					key: 'getManager',
					value: function getManager() {
						return childContext.dragDropManager;
					}
				}, {
					key: 'getChildContext',
					value: function getChildContext() {
						return childContext;
					}
				}, {
					key: 'render',
					value: function render() {
						var _this2 = this;

						return _react2.default.createElement(DecoratedComponent, _extends({}, this.props, {
							ref: function ref(child) {
								_this2.child = child;
							}
						}));
					}
				}]);

				return DragDropContextContainer;
			}(_react.Component), _class.DecoratedComponent = DecoratedComponent, _class.displayName = 'DragDropContext(' + displayName + ')', _class.childContextTypes = CHILD_CONTEXT_TYPES, _temp);


			return (0, _hoistNonReactStatics2.default)(DragDropContextContainer, DecoratedComponent);
		};
	}

/***/ },

/***/ 1570:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _DragDropManager = __webpack_require__(1571);

	Object.defineProperty(exports, 'DragDropManager', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DragDropManager).default;
	  }
	});

	var _DragSource = __webpack_require__(1588);

	Object.defineProperty(exports, 'DragSource', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DragSource).default;
	  }
	});

	var _DropTarget = __webpack_require__(1589);

	Object.defineProperty(exports, 'DropTarget', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_DropTarget).default;
	  }
	});

	var _createTestBackend = __webpack_require__(1590);

	Object.defineProperty(exports, 'createTestBackend', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_createTestBackend).default;
	  }
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ },

/***/ 1571:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _createStore = __webpack_require__(652);

	var _createStore2 = _interopRequireDefault(_createStore);

	var _reducers = __webpack_require__(1572);

	var _reducers2 = _interopRequireDefault(_reducers);

	var _dragDrop = __webpack_require__(1574);

	var dragDropActions = _interopRequireWildcard(_dragDrop);

	var _DragDropMonitor = __webpack_require__(1583);

	var _DragDropMonitor2 = _interopRequireDefault(_DragDropMonitor);

	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var DragDropManager = function () {
		function DragDropManager(createBackend) {
			var context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

			_classCallCheck(this, DragDropManager);

			var store = (0, _createStore2.default)(_reducers2.default);
			this.context = context;
			this.store = store;
			this.monitor = new _DragDropMonitor2.default(store);
			this.registry = this.monitor.registry;
			this.backend = createBackend(this);

			store.subscribe(this.handleRefCountChange.bind(this));
		}

		_createClass(DragDropManager, [{
			key: 'handleRefCountChange',
			value: function handleRefCountChange() {
				var shouldSetUp = this.store.getState().refCount > 0;
				if (shouldSetUp && !this.isSetUp) {
					this.backend.setup();
					this.isSetUp = true;
				} else if (!shouldSetUp && this.isSetUp) {
					this.backend.teardown();
					this.isSetUp = false;
				}
			}
		}, {
			key: 'getContext',
			value: function getContext() {
				return this.context;
			}
		}, {
			key: 'getMonitor',
			value: function getMonitor() {
				return this.monitor;
			}
		}, {
			key: 'getBackend',
			value: function getBackend() {
				return this.backend;
			}
		}, {
			key: 'getRegistry',
			value: function getRegistry() {
				return this.registry;
			}
		}, {
			key: 'getActions',
			value: function getActions() {
				var manager = this;
				var dispatch = this.store.dispatch;


				function bindActionCreator(actionCreator) {
					return function () {
						for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
							args[_key] = arguments[_key];
						}

						var action = actionCreator.apply(manager, args);
						if (typeof action !== 'undefined') {
							dispatch(action);
						}
					};
				}

				return Object.keys(dragDropActions).filter(function (key) {
					return typeof dragDropActions[key] === 'function';
				}).reduce(function (boundActions, key) {
					var action = dragDropActions[key];
					boundActions[key] = bindActionCreator(action); // eslint-disable-line no-param-reassign
					return boundActions;
				}, {});
			}
		}]);

		return DragDropManager;
	}();

	exports.default = DragDropManager;

/***/ },

/***/ 1572:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = reduce;

	var _dragOffset = __webpack_require__(1573);

	var _dragOffset2 = _interopRequireDefault(_dragOffset);

	var _dragOperation = __webpack_require__(1576);

	var _dragOperation2 = _interopRequireDefault(_dragOperation);

	var _refCount = __webpack_require__(1578);

	var _refCount2 = _interopRequireDefault(_refCount);

	var _dirtyHandlerIds = __webpack_require__(1579);

	var _dirtyHandlerIds2 = _interopRequireDefault(_dirtyHandlerIds);

	var _stateId = __webpack_require__(1582);

	var _stateId2 = _interopRequireDefault(_stateId);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function reduce() {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
		var action = arguments[1];

		return {
			dirtyHandlerIds: (0, _dirtyHandlerIds2.default)(state.dirtyHandlerIds, action, state.dragOperation),
			dragOffset: (0, _dragOffset2.default)(state.dragOffset, action),
			refCount: (0, _refCount2.default)(state.refCount, action),
			dragOperation: (0, _dragOperation2.default)(state.dragOperation, action),
			stateId: (0, _stateId2.default)(state.stateId)
		};
	}

/***/ },

/***/ 1573:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	exports.default = dragOffset;
	exports.getSourceClientOffset = getSourceClientOffset;
	exports.getDifferenceFromInitialOffset = getDifferenceFromInitialOffset;

	var _dragDrop = __webpack_require__(1574);

	var initialState = {
		initialSourceClientOffset: null,
		initialClientOffset: null,
		clientOffset: null
	};

	function areOffsetsEqual(offsetA, offsetB) {
		if (offsetA === offsetB) {
			return true;
		}
		return offsetA && offsetB && offsetA.x === offsetB.x && offsetA.y === offsetB.y;
	}

	function dragOffset() {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
		var action = arguments[1];

		switch (action.type) {
			case _dragDrop.BEGIN_DRAG:
				return {
					initialSourceClientOffset: action.sourceClientOffset,
					initialClientOffset: action.clientOffset,
					clientOffset: action.clientOffset
				};
			case _dragDrop.HOVER:
				if (areOffsetsEqual(state.clientOffset, action.clientOffset)) {
					return state;
				}
				return _extends({}, state, {
					clientOffset: action.clientOffset
				});
			case _dragDrop.END_DRAG:
			case _dragDrop.DROP:
				return initialState;
			default:
				return state;
		}
	}

	function getSourceClientOffset(state) {
		var clientOffset = state.clientOffset,
		    initialClientOffset = state.initialClientOffset,
		    initialSourceClientOffset = state.initialSourceClientOffset;

		if (!clientOffset || !initialClientOffset || !initialSourceClientOffset) {
			return null;
		}
		return {
			x: clientOffset.x + initialSourceClientOffset.x - initialClientOffset.x,
			y: clientOffset.y + initialSourceClientOffset.y - initialClientOffset.y
		};
	}

	function getDifferenceFromInitialOffset(state) {
		var clientOffset = state.clientOffset,
		    initialClientOffset = state.initialClientOffset;

		if (!clientOffset || !initialClientOffset) {
			return null;
		}
		return {
			x: clientOffset.x - initialClientOffset.x,
			y: clientOffset.y - initialClientOffset.y
		};
	}

/***/ },

/***/ 1574:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.END_DRAG = exports.DROP = exports.HOVER = exports.PUBLISH_DRAG_SOURCE = exports.BEGIN_DRAG = undefined;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	exports.beginDrag = beginDrag;
	exports.publishDragSource = publishDragSource;
	exports.hover = hover;
	exports.drop = drop;
	exports.endDrag = endDrag;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isArray = __webpack_require__(282);

	var _isArray2 = _interopRequireDefault(_isArray);

	var _isObject = __webpack_require__(303);

	var _isObject2 = _interopRequireDefault(_isObject);

	var _matchesType = __webpack_require__(1575);

	var _matchesType2 = _interopRequireDefault(_matchesType);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var BEGIN_DRAG = exports.BEGIN_DRAG = 'dnd-core/BEGIN_DRAG';
	var PUBLISH_DRAG_SOURCE = exports.PUBLISH_DRAG_SOURCE = 'dnd-core/PUBLISH_DRAG_SOURCE';
	var HOVER = exports.HOVER = 'dnd-core/HOVER';
	var DROP = exports.DROP = 'dnd-core/DROP';
	var END_DRAG = exports.END_DRAG = 'dnd-core/END_DRAG';

	function beginDrag(sourceIds) {
		var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { publishSource: true, clientOffset: null };
		var publishSource = options.publishSource,
		    clientOffset = options.clientOffset,
		    getSourceClientOffset = options.getSourceClientOffset;

		(0, _invariant2.default)((0, _isArray2.default)(sourceIds), 'Expected sourceIds to be an array.');

		var monitor = this.getMonitor();
		var registry = this.getRegistry();
		(0, _invariant2.default)(!monitor.isDragging(), 'Cannot call beginDrag while dragging.');

		for (var i = 0; i < sourceIds.length; i++) {
			(0, _invariant2.default)(registry.getSource(sourceIds[i]), 'Expected sourceIds to be registered.');
		}

		var sourceId = null;
		for (var _i = sourceIds.length - 1; _i >= 0; _i--) {
			if (monitor.canDragSource(sourceIds[_i])) {
				sourceId = sourceIds[_i];
				break;
			}
		}
		if (sourceId === null) {
			return;
		}

		var sourceClientOffset = null;
		if (clientOffset) {
			(0, _invariant2.default)(typeof getSourceClientOffset === 'function', 'When clientOffset is provided, getSourceClientOffset must be a function.');
			sourceClientOffset = getSourceClientOffset(sourceId);
		}

		var source = registry.getSource(sourceId);
		var item = source.beginDrag(monitor, sourceId);
		(0, _invariant2.default)((0, _isObject2.default)(item), 'Item must be an object.');

		registry.pinSource(sourceId);

		var itemType = registry.getSourceType(sourceId);
		return {
			type: BEGIN_DRAG,
			itemType: itemType,
			item: item,
			sourceId: sourceId,
			clientOffset: clientOffset,
			sourceClientOffset: sourceClientOffset,
			isSourcePublic: publishSource
		};
	}

	function publishDragSource() {
		var monitor = this.getMonitor();
		if (!monitor.isDragging()) {
			return;
		}

		return { type: PUBLISH_DRAG_SOURCE };
	}

	function hover(targetIdsArg) {
		var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
		    _ref$clientOffset = _ref.clientOffset,
		    clientOffset = _ref$clientOffset === undefined ? null : _ref$clientOffset;

		(0, _invariant2.default)((0, _isArray2.default)(targetIdsArg), 'Expected targetIds to be an array.');
		var targetIds = targetIdsArg.slice(0);

		var monitor = this.getMonitor();
		var registry = this.getRegistry();
		(0, _invariant2.default)(monitor.isDragging(), 'Cannot call hover while not dragging.');
		(0, _invariant2.default)(!monitor.didDrop(), 'Cannot call hover after drop.');

		// First check invariants.
		for (var i = 0; i < targetIds.length; i++) {
			var targetId = targetIds[i];
			(0, _invariant2.default)(targetIds.lastIndexOf(targetId) === i, 'Expected targetIds to be unique in the passed array.');

			var target = registry.getTarget(targetId);
			(0, _invariant2.default)(target, 'Expected targetIds to be registered.');
		}

		var draggedItemType = monitor.getItemType();

		// Remove those targetIds that don't match the targetType.  This
		// fixes shallow isOver which would only be non-shallow because of
		// non-matching targets.
		for (var _i2 = targetIds.length - 1; _i2 >= 0; _i2--) {
			var _targetId = targetIds[_i2];
			var targetType = registry.getTargetType(_targetId);
			if (!(0, _matchesType2.default)(targetType, draggedItemType)) {
				targetIds.splice(_i2, 1);
			}
		}

		// Finally call hover on all matching targets.
		for (var _i3 = 0; _i3 < targetIds.length; _i3++) {
			var _targetId2 = targetIds[_i3];
			var _target = registry.getTarget(_targetId2);
			_target.hover(monitor, _targetId2);
		}

		return {
			type: HOVER,
			targetIds: targetIds,
			clientOffset: clientOffset
		};
	}

	function drop() {
		var _this = this;

		var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

		var monitor = this.getMonitor();
		var registry = this.getRegistry();
		(0, _invariant2.default)(monitor.isDragging(), 'Cannot call drop while not dragging.');
		(0, _invariant2.default)(!monitor.didDrop(), 'Cannot call drop twice during one drag operation.');

		var targetIds = monitor.getTargetIds().filter(monitor.canDropOnTarget, monitor);

		targetIds.reverse();
		targetIds.forEach(function (targetId, index) {
			var target = registry.getTarget(targetId);

			var dropResult = target.drop(monitor, targetId);
			(0, _invariant2.default)(typeof dropResult === 'undefined' || (0, _isObject2.default)(dropResult), 'Drop result must either be an object or undefined.');
			if (typeof dropResult === 'undefined') {
				dropResult = index === 0 ? {} : monitor.getDropResult();
			}

			_this.store.dispatch({
				type: DROP,
				dropResult: _extends({}, options, dropResult)
			});
		});
	}

	function endDrag() {
		var monitor = this.getMonitor();
		var registry = this.getRegistry();
		(0, _invariant2.default)(monitor.isDragging(), 'Cannot call endDrag while not dragging.');

		var sourceId = monitor.getSourceId();
		var source = registry.getSource(sourceId, true);
		source.endDrag(monitor, sourceId);

		registry.unpinSource();

		return { type: END_DRAG };
	}

/***/ },

/***/ 1575:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = matchesType;

	var _isArray = __webpack_require__(282);

	var _isArray2 = _interopRequireDefault(_isArray);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function matchesType(targetType, draggedItemType) {
		if ((0, _isArray2.default)(targetType)) {
			return targetType.some(function (t) {
				return t === draggedItemType;
			});
		} else {
			return targetType === draggedItemType;
		}
	}

/***/ },

/***/ 1576:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	exports.default = dragOperation;

	var _without = __webpack_require__(1560);

	var _without2 = _interopRequireDefault(_without);

	var _dragDrop = __webpack_require__(1574);

	var _registry = __webpack_require__(1577);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var initialState = {
		itemType: null,
		item: null,
		sourceId: null,
		targetIds: [],
		dropResult: null,
		didDrop: false,
		isSourcePublic: null
	};

	function dragOperation() {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
		var action = arguments[1];

		switch (action.type) {
			case _dragDrop.BEGIN_DRAG:
				return _extends({}, state, {
					itemType: action.itemType,
					item: action.item,
					sourceId: action.sourceId,
					isSourcePublic: action.isSourcePublic,
					dropResult: null,
					didDrop: false
				});
			case _dragDrop.PUBLISH_DRAG_SOURCE:
				return _extends({}, state, {
					isSourcePublic: true
				});
			case _dragDrop.HOVER:
				return _extends({}, state, {
					targetIds: action.targetIds
				});
			case _registry.REMOVE_TARGET:
				if (state.targetIds.indexOf(action.targetId) === -1) {
					return state;
				}
				return _extends({}, state, {
					targetIds: (0, _without2.default)(state.targetIds, action.targetId)
				});
			case _dragDrop.DROP:
				return _extends({}, state, {
					dropResult: action.dropResult,
					didDrop: true,
					targetIds: []
				});
			case _dragDrop.END_DRAG:
				return _extends({}, state, {
					itemType: null,
					item: null,
					sourceId: null,
					dropResult: null,
					didDrop: false,
					isSourcePublic: null,
					targetIds: []
				});
			default:
				return state;
		}
	}

/***/ },

/***/ 1577:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.addSource = addSource;
	exports.addTarget = addTarget;
	exports.removeSource = removeSource;
	exports.removeTarget = removeTarget;
	var ADD_SOURCE = exports.ADD_SOURCE = 'dnd-core/ADD_SOURCE';
	var ADD_TARGET = exports.ADD_TARGET = 'dnd-core/ADD_TARGET';
	var REMOVE_SOURCE = exports.REMOVE_SOURCE = 'dnd-core/REMOVE_SOURCE';
	var REMOVE_TARGET = exports.REMOVE_TARGET = 'dnd-core/REMOVE_TARGET';

	function addSource(sourceId) {
		return {
			type: ADD_SOURCE,
			sourceId: sourceId
		};
	}

	function addTarget(targetId) {
		return {
			type: ADD_TARGET,
			targetId: targetId
		};
	}

	function removeSource(sourceId) {
		return {
			type: REMOVE_SOURCE,
			sourceId: sourceId
		};
	}

	function removeTarget(targetId) {
		return {
			type: REMOVE_TARGET,
			targetId: targetId
		};
	}

/***/ },

/***/ 1578:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = refCount;

	var _registry = __webpack_require__(1577);

	function refCount() {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
		var action = arguments[1];

		switch (action.type) {
			case _registry.ADD_SOURCE:
			case _registry.ADD_TARGET:
				return state + 1;
			case _registry.REMOVE_SOURCE:
			case _registry.REMOVE_TARGET:
				return state - 1;
			default:
				return state;
		}
	}

/***/ },

/***/ 1579:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = dirtyHandlerIds;
	exports.areDirty = areDirty;

	var _xor = __webpack_require__(1580);

	var _xor2 = _interopRequireDefault(_xor);

	var _intersection = __webpack_require__(935);

	var _intersection2 = _interopRequireDefault(_intersection);

	var _dragDrop = __webpack_require__(1574);

	var _registry = __webpack_require__(1577);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var NONE = [];
	var ALL = [];

	function dirtyHandlerIds() {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : NONE;
		var action = arguments[1];
		var dragOperation = arguments[2];

		switch (action.type) {
			case _dragDrop.HOVER:
				break;
			case _registry.ADD_SOURCE:
			case _registry.ADD_TARGET:
			case _registry.REMOVE_TARGET:
			case _registry.REMOVE_SOURCE:
				return NONE;
			case _dragDrop.BEGIN_DRAG:
			case _dragDrop.PUBLISH_DRAG_SOURCE:
			case _dragDrop.END_DRAG:
			case _dragDrop.DROP:
			default:
				return ALL;
		}

		var targetIds = action.targetIds;
		var prevTargetIds = dragOperation.targetIds;

		var result = (0, _xor2.default)(targetIds, prevTargetIds);

		var didChange = false;
		if (result.length === 0) {
			for (var i = 0; i < targetIds.length; i++) {
				if (targetIds[i] !== prevTargetIds[i]) {
					didChange = true;
					break;
				}
			}
		} else {
			didChange = true;
		}

		if (!didChange) {
			return NONE;
		}

		var prevInnermostTargetId = prevTargetIds[prevTargetIds.length - 1];
		var innermostTargetId = targetIds[targetIds.length - 1];

		if (prevInnermostTargetId !== innermostTargetId) {
			if (prevInnermostTargetId) {
				result.push(prevInnermostTargetId);
			}
			if (innermostTargetId) {
				result.push(innermostTargetId);
			}
		}

		return result;
	}

	function areDirty(state, handlerIds) {
		if (state === NONE) {
			return false;
		}

		if (state === ALL || typeof handlerIds === 'undefined') {
			return true;
		}

		return (0, _intersection2.default)(handlerIds, state).length > 0;
	}

/***/ },

/***/ 1580:
/***/ function(module, exports, __webpack_require__) {

	var arrayFilter = __webpack_require__(798),
	    baseRest = __webpack_require__(559),
	    baseXor = __webpack_require__(1581),
	    isArrayLikeObject = __webpack_require__(541);

	/**
	 * Creates an array of unique values that is the
	 * [symmetric difference](https://en.wikipedia.org/wiki/Symmetric_difference)
	 * of the given arrays. The order of result values is determined by the order
	 * they occur in the arrays.
	 *
	 * @static
	 * @memberOf _
	 * @since 2.4.0
	 * @category Array
	 * @param {...Array} [arrays] The arrays to inspect.
	 * @returns {Array} Returns the new array of filtered values.
	 * @see _.difference, _.without
	 * @example
	 *
	 * _.xor([2, 1], [2, 3]);
	 * // => [1, 3]
	 */
	var xor = baseRest(function(arrays) {
	  return baseXor(arrayFilter(arrays, isArrayLikeObject));
	});

	module.exports = xor;


/***/ },

/***/ 1581:
/***/ function(module, exports, __webpack_require__) {

	var baseDifference = __webpack_require__(1561),
	    baseFlatten = __webpack_require__(854),
	    baseUniq = __webpack_require__(1557);

	/**
	 * The base implementation of methods like `_.xor`, without support for
	 * iteratee shorthands, that accepts an array of arrays to inspect.
	 *
	 * @private
	 * @param {Array} arrays The arrays to inspect.
	 * @param {Function} [iteratee] The iteratee invoked per element.
	 * @param {Function} [comparator] The comparator invoked per element.
	 * @returns {Array} Returns the new array of values.
	 */
	function baseXor(arrays, iteratee, comparator) {
	  var length = arrays.length;
	  if (length < 2) {
	    return length ? baseUniq(arrays[0]) : [];
	  }
	  var index = -1,
	      result = Array(length);

	  while (++index < length) {
	    var array = arrays[index],
	        othIndex = -1;

	    while (++othIndex < length) {
	      if (othIndex != index) {
	        result[index] = baseDifference(result[index] || array, arrays[othIndex], iteratee, comparator);
	      }
	    }
	  }
	  return baseUniq(baseFlatten(result, 1), iteratee, comparator);
	}

	module.exports = baseXor;


/***/ },

/***/ 1582:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = stateId;
	function stateId() {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

		return state + 1;
	}

/***/ },

/***/ 1583:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isArray = __webpack_require__(282);

	var _isArray2 = _interopRequireDefault(_isArray);

	var _matchesType = __webpack_require__(1575);

	var _matchesType2 = _interopRequireDefault(_matchesType);

	var _HandlerRegistry = __webpack_require__(1584);

	var _HandlerRegistry2 = _interopRequireDefault(_HandlerRegistry);

	var _dragOffset = __webpack_require__(1573);

	var _dirtyHandlerIds = __webpack_require__(1579);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var DragDropMonitor = function () {
		function DragDropMonitor(store) {
			_classCallCheck(this, DragDropMonitor);

			this.store = store;
			this.registry = new _HandlerRegistry2.default(store);
		}

		_createClass(DragDropMonitor, [{
			key: 'subscribeToStateChange',
			value: function subscribeToStateChange(listener) {
				var _this = this;

				var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
				var handlerIds = options.handlerIds;

				(0, _invariant2.default)(typeof listener === 'function', 'listener must be a function.');
				(0, _invariant2.default)(typeof handlerIds === 'undefined' || (0, _isArray2.default)(handlerIds), 'handlerIds, when specified, must be an array of strings.');

				var prevStateId = this.store.getState().stateId;
				var handleChange = function handleChange() {
					var state = _this.store.getState();
					var currentStateId = state.stateId;
					try {
						var canSkipListener = currentStateId === prevStateId || currentStateId === prevStateId + 1 && !(0, _dirtyHandlerIds.areDirty)(state.dirtyHandlerIds, handlerIds);

						if (!canSkipListener) {
							listener();
						}
					} finally {
						prevStateId = currentStateId;
					}
				};

				return this.store.subscribe(handleChange);
			}
		}, {
			key: 'subscribeToOffsetChange',
			value: function subscribeToOffsetChange(listener) {
				var _this2 = this;

				(0, _invariant2.default)(typeof listener === 'function', 'listener must be a function.');

				var previousState = this.store.getState().dragOffset;
				var handleChange = function handleChange() {
					var nextState = _this2.store.getState().dragOffset;
					if (nextState === previousState) {
						return;
					}

					previousState = nextState;
					listener();
				};

				return this.store.subscribe(handleChange);
			}
		}, {
			key: 'canDragSource',
			value: function canDragSource(sourceId) {
				var source = this.registry.getSource(sourceId);
				(0, _invariant2.default)(source, 'Expected to find a valid source.');

				if (this.isDragging()) {
					return false;
				}

				return source.canDrag(this, sourceId);
			}
		}, {
			key: 'canDropOnTarget',
			value: function canDropOnTarget(targetId) {
				var target = this.registry.getTarget(targetId);
				(0, _invariant2.default)(target, 'Expected to find a valid target.');

				if (!this.isDragging() || this.didDrop()) {
					return false;
				}

				var targetType = this.registry.getTargetType(targetId);
				var draggedItemType = this.getItemType();
				return (0, _matchesType2.default)(targetType, draggedItemType) && target.canDrop(this, targetId);
			}
		}, {
			key: 'isDragging',
			value: function isDragging() {
				return Boolean(this.getItemType());
			}
		}, {
			key: 'isDraggingSource',
			value: function isDraggingSource(sourceId) {
				var source = this.registry.getSource(sourceId, true);
				(0, _invariant2.default)(source, 'Expected to find a valid source.');

				if (!this.isDragging() || !this.isSourcePublic()) {
					return false;
				}

				var sourceType = this.registry.getSourceType(sourceId);
				var draggedItemType = this.getItemType();
				if (sourceType !== draggedItemType) {
					return false;
				}

				return source.isDragging(this, sourceId);
			}
		}, {
			key: 'isOverTarget',
			value: function isOverTarget(targetId) {
				var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { shallow: false };
				var shallow = options.shallow;

				if (!this.isDragging()) {
					return false;
				}

				var targetType = this.registry.getTargetType(targetId);
				var draggedItemType = this.getItemType();
				if (!(0, _matchesType2.default)(targetType, draggedItemType)) {
					return false;
				}

				var targetIds = this.getTargetIds();
				if (!targetIds.length) {
					return false;
				}

				var index = targetIds.indexOf(targetId);
				if (shallow) {
					return index === targetIds.length - 1;
				} else {
					return index > -1;
				}
			}
		}, {
			key: 'getItemType',
			value: function getItemType() {
				return this.store.getState().dragOperation.itemType;
			}
		}, {
			key: 'getItem',
			value: function getItem() {
				return this.store.getState().dragOperation.item;
			}
		}, {
			key: 'getSourceId',
			value: function getSourceId() {
				return this.store.getState().dragOperation.sourceId;
			}
		}, {
			key: 'getTargetIds',
			value: function getTargetIds() {
				return this.store.getState().dragOperation.targetIds;
			}
		}, {
			key: 'getDropResult',
			value: function getDropResult() {
				return this.store.getState().dragOperation.dropResult;
			}
		}, {
			key: 'didDrop',
			value: function didDrop() {
				return this.store.getState().dragOperation.didDrop;
			}
		}, {
			key: 'isSourcePublic',
			value: function isSourcePublic() {
				return this.store.getState().dragOperation.isSourcePublic;
			}
		}, {
			key: 'getInitialClientOffset',
			value: function getInitialClientOffset() {
				return this.store.getState().dragOffset.initialClientOffset;
			}
		}, {
			key: 'getInitialSourceClientOffset',
			value: function getInitialSourceClientOffset() {
				return this.store.getState().dragOffset.initialSourceClientOffset;
			}
		}, {
			key: 'getClientOffset',
			value: function getClientOffset() {
				return this.store.getState().dragOffset.clientOffset;
			}
		}, {
			key: 'getSourceClientOffset',
			value: function getSourceClientOffset() {
				return (0, _dragOffset.getSourceClientOffset)(this.store.getState().dragOffset);
			}
		}, {
			key: 'getDifferenceFromInitialOffset',
			value: function getDifferenceFromInitialOffset() {
				return (0, _dragOffset.getDifferenceFromInitialOffset)(this.store.getState().dragOffset);
			}
		}]);

		return DragDropMonitor;
	}();

	exports.default = DragDropMonitor;

/***/ },

/***/ 1584:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isArray = __webpack_require__(282);

	var _isArray2 = _interopRequireDefault(_isArray);

	var _asap = __webpack_require__(1585);

	var _asap2 = _interopRequireDefault(_asap);

	var _registry = __webpack_require__(1577);

	var _getNextUniqueId = __webpack_require__(1587);

	var _getNextUniqueId2 = _interopRequireDefault(_getNextUniqueId);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var HandlerRoles = {
		SOURCE: 'SOURCE',
		TARGET: 'TARGET'
	};

	function validateSourceContract(source) {
		(0, _invariant2.default)(typeof source.canDrag === 'function', 'Expected canDrag to be a function.');
		(0, _invariant2.default)(typeof source.beginDrag === 'function', 'Expected beginDrag to be a function.');
		(0, _invariant2.default)(typeof source.endDrag === 'function', 'Expected endDrag to be a function.');
	}

	function validateTargetContract(target) {
		(0, _invariant2.default)(typeof target.canDrop === 'function', 'Expected canDrop to be a function.');
		(0, _invariant2.default)(typeof target.hover === 'function', 'Expected hover to be a function.');
		(0, _invariant2.default)(typeof target.drop === 'function', 'Expected beginDrag to be a function.');
	}

	function validateType(type, allowArray) {
		if (allowArray && (0, _isArray2.default)(type)) {
			type.forEach(function (t) {
				return validateType(t, false);
			});
			return;
		}

		(0, _invariant2.default)(typeof type === 'string' || (typeof type === 'undefined' ? 'undefined' : _typeof(type)) === 'symbol', allowArray ? 'Type can only be a string, a symbol, or an array of either.' : 'Type can only be a string or a symbol.');
	}

	function getNextHandlerId(role) {
		var id = (0, _getNextUniqueId2.default)().toString();
		switch (role) {
			case HandlerRoles.SOURCE:
				return 'S' + id;
			case HandlerRoles.TARGET:
				return 'T' + id;
			default:
				(0, _invariant2.default)(false, 'Unknown role: ' + role);
		}
	}

	function parseRoleFromHandlerId(handlerId) {
		switch (handlerId[0]) {
			case 'S':
				return HandlerRoles.SOURCE;
			case 'T':
				return HandlerRoles.TARGET;
			default:
				(0, _invariant2.default)(false, 'Cannot parse handler ID: ' + handlerId);
		}
	}

	var HandlerRegistry = function () {
		function HandlerRegistry(store) {
			_classCallCheck(this, HandlerRegistry);

			this.store = store;

			this.types = {};
			this.handlers = {};

			this.pinnedSourceId = null;
			this.pinnedSource = null;
		}

		_createClass(HandlerRegistry, [{
			key: 'addSource',
			value: function addSource(type, source) {
				validateType(type);
				validateSourceContract(source);

				var sourceId = this.addHandler(HandlerRoles.SOURCE, type, source);
				this.store.dispatch((0, _registry.addSource)(sourceId));
				return sourceId;
			}
		}, {
			key: 'addTarget',
			value: function addTarget(type, target) {
				validateType(type, true);
				validateTargetContract(target);

				var targetId = this.addHandler(HandlerRoles.TARGET, type, target);
				this.store.dispatch((0, _registry.addTarget)(targetId));
				return targetId;
			}
		}, {
			key: 'addHandler',
			value: function addHandler(role, type, handler) {
				var id = getNextHandlerId(role);
				this.types[id] = type;
				this.handlers[id] = handler;

				return id;
			}
		}, {
			key: 'containsHandler',
			value: function containsHandler(handler) {
				var _this = this;

				return Object.keys(this.handlers).some(function (key) {
					return _this.handlers[key] === handler;
				});
			}
		}, {
			key: 'getSource',
			value: function getSource(sourceId, includePinned) {
				(0, _invariant2.default)(this.isSourceId(sourceId), 'Expected a valid source ID.');

				var isPinned = includePinned && sourceId === this.pinnedSourceId;
				var source = isPinned ? this.pinnedSource : this.handlers[sourceId];

				return source;
			}
		}, {
			key: 'getTarget',
			value: function getTarget(targetId) {
				(0, _invariant2.default)(this.isTargetId(targetId), 'Expected a valid target ID.');
				return this.handlers[targetId];
			}
		}, {
			key: 'getSourceType',
			value: function getSourceType(sourceId) {
				(0, _invariant2.default)(this.isSourceId(sourceId), 'Expected a valid source ID.');
				return this.types[sourceId];
			}
		}, {
			key: 'getTargetType',
			value: function getTargetType(targetId) {
				(0, _invariant2.default)(this.isTargetId(targetId), 'Expected a valid target ID.');
				return this.types[targetId];
			}
		}, {
			key: 'isSourceId',
			value: function isSourceId(handlerId) {
				var role = parseRoleFromHandlerId(handlerId);
				return role === HandlerRoles.SOURCE;
			}
		}, {
			key: 'isTargetId',
			value: function isTargetId(handlerId) {
				var role = parseRoleFromHandlerId(handlerId);
				return role === HandlerRoles.TARGET;
			}
		}, {
			key: 'removeSource',
			value: function removeSource(sourceId) {
				var _this2 = this;

				(0, _invariant2.default)(this.getSource(sourceId), 'Expected an existing source.');
				this.store.dispatch((0, _registry.removeSource)(sourceId));

				(0, _asap2.default)(function () {
					delete _this2.handlers[sourceId];
					delete _this2.types[sourceId];
				});
			}
		}, {
			key: 'removeTarget',
			value: function removeTarget(targetId) {
				var _this3 = this;

				(0, _invariant2.default)(this.getTarget(targetId), 'Expected an existing target.');
				this.store.dispatch((0, _registry.removeTarget)(targetId));

				(0, _asap2.default)(function () {
					delete _this3.handlers[targetId];
					delete _this3.types[targetId];
				});
			}
		}, {
			key: 'pinSource',
			value: function pinSource(sourceId) {
				var source = this.getSource(sourceId);
				(0, _invariant2.default)(source, 'Expected an existing source.');

				this.pinnedSourceId = sourceId;
				this.pinnedSource = source;
			}
		}, {
			key: 'unpinSource',
			value: function unpinSource() {
				(0, _invariant2.default)(this.pinnedSource, 'No source is pinned at the time.');

				this.pinnedSourceId = null;
				this.pinnedSource = null;
			}
		}]);

		return HandlerRegistry;
	}();

	exports.default = HandlerRegistry;

/***/ },

/***/ 1585:
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	// rawAsap provides everything we need except exception management.
	var rawAsap = __webpack_require__(1586);
	// RawTasks are recycled to reduce GC churn.
	var freeTasks = [];
	// We queue errors to ensure they are thrown in right order (FIFO).
	// Array-as-queue is good enough here, since we are just dealing with exceptions.
	var pendingErrors = [];
	var requestErrorThrow = rawAsap.makeRequestCallFromTimer(throwFirstError);

	function throwFirstError() {
	    if (pendingErrors.length) {
	        throw pendingErrors.shift();
	    }
	}

	/**
	 * Calls a task as soon as possible after returning, in its own event, with priority
	 * over other events like animation, reflow, and repaint. An error thrown from an
	 * event will not interrupt, nor even substantially slow down the processing of
	 * other events, but will be rather postponed to a lower priority event.
	 * @param {{call}} task A callable object, typically a function that takes no
	 * arguments.
	 */
	module.exports = asap;
	function asap(task) {
	    var rawTask;
	    if (freeTasks.length) {
	        rawTask = freeTasks.pop();
	    } else {
	        rawTask = new RawTask();
	    }
	    rawTask.task = task;
	    rawAsap(rawTask);
	}

	// We wrap tasks with recyclable task objects.  A task object implements
	// `call`, just like a function.
	function RawTask() {
	    this.task = null;
	}

	// The sole purpose of wrapping the task is to catch the exception and recycle
	// the task object after its single use.
	RawTask.prototype.call = function () {
	    try {
	        this.task.call();
	    } catch (error) {
	        if (asap.onerror) {
	            // This hook exists purely for testing purposes.
	            // Its name will be periodically randomized to break any code that
	            // depends on its existence.
	            asap.onerror(error);
	        } else {
	            // In a web browser, exceptions are not fatal. However, to avoid
	            // slowing down the queue of pending tasks, we rethrow the error in a
	            // lower priority turn.
	            pendingErrors.push(error);
	            requestErrorThrow();
	        }
	    } finally {
	        this.task = null;
	        freeTasks[freeTasks.length] = this;
	    }
	};


/***/ },

/***/ 1586:
/***/ function(module, exports) {

	/* WEBPACK VAR INJECTION */(function(global) {"use strict";

	// Use the fastest means possible to execute a task in its own turn, with
	// priority over other events including IO, animation, reflow, and redraw
	// events in browsers.
	//
	// An exception thrown by a task will permanently interrupt the processing of
	// subsequent tasks. The higher level `asap` function ensures that if an
	// exception is thrown by a task, that the task queue will continue flushing as
	// soon as possible, but if you use `rawAsap` directly, you are responsible to
	// either ensure that no exceptions are thrown from your task, or to manually
	// call `rawAsap.requestFlush` if an exception is thrown.
	module.exports = rawAsap;
	function rawAsap(task) {
	    if (!queue.length) {
	        requestFlush();
	        flushing = true;
	    }
	    // Equivalent to push, but avoids a function call.
	    queue[queue.length] = task;
	}

	var queue = [];
	// Once a flush has been requested, no further calls to `requestFlush` are
	// necessary until the next `flush` completes.
	var flushing = false;
	// `requestFlush` is an implementation-specific method that attempts to kick
	// off a `flush` event as quickly as possible. `flush` will attempt to exhaust
	// the event queue before yielding to the browser's own event loop.
	var requestFlush;
	// The position of the next task to execute in the task queue. This is
	// preserved between calls to `flush` so that it can be resumed if
	// a task throws an exception.
	var index = 0;
	// If a task schedules additional tasks recursively, the task queue can grow
	// unbounded. To prevent memory exhaustion, the task queue will periodically
	// truncate already-completed tasks.
	var capacity = 1024;

	// The flush function processes all tasks that have been scheduled with
	// `rawAsap` unless and until one of those tasks throws an exception.
	// If a task throws an exception, `flush` ensures that its state will remain
	// consistent and will resume where it left off when called again.
	// However, `flush` does not make any arrangements to be called again if an
	// exception is thrown.
	function flush() {
	    while (index < queue.length) {
	        var currentIndex = index;
	        // Advance the index before calling the task. This ensures that we will
	        // begin flushing on the next task the task throws an error.
	        index = index + 1;
	        queue[currentIndex].call();
	        // Prevent leaking memory for long chains of recursive calls to `asap`.
	        // If we call `asap` within tasks scheduled by `asap`, the queue will
	        // grow, but to avoid an O(n) walk for every task we execute, we don't
	        // shift tasks off the queue after they have been executed.
	        // Instead, we periodically shift 1024 tasks off the queue.
	        if (index > capacity) {
	            // Manually shift all values starting at the index back to the
	            // beginning of the queue.
	            for (var scan = 0, newLength = queue.length - index; scan < newLength; scan++) {
	                queue[scan] = queue[scan + index];
	            }
	            queue.length -= index;
	            index = 0;
	        }
	    }
	    queue.length = 0;
	    index = 0;
	    flushing = false;
	}

	// `requestFlush` is implemented using a strategy based on data collected from
	// every available SauceLabs Selenium web driver worker at time of writing.
	// https://docs.google.com/spreadsheets/d/1mG-5UYGup5qxGdEMWkhP6BWCz053NUb2E1QoUTU16uA/edit#gid=783724593

	// Safari 6 and 6.1 for desktop, iPad, and iPhone are the only browsers that
	// have WebKitMutationObserver but not un-prefixed MutationObserver.
	// Must use `global` or `self` instead of `window` to work in both frames and web
	// workers. `global` is a provision of Browserify, Mr, Mrs, or Mop.

	/* globals self */
	var scope = typeof global !== "undefined" ? global : self;
	var BrowserMutationObserver = scope.MutationObserver || scope.WebKitMutationObserver;

	// MutationObservers are desirable because they have high priority and work
	// reliably everywhere they are implemented.
	// They are implemented in all modern browsers.
	//
	// - Android 4-4.3
	// - Chrome 26-34
	// - Firefox 14-29
	// - Internet Explorer 11
	// - iPad Safari 6-7.1
	// - iPhone Safari 7-7.1
	// - Safari 6-7
	if (typeof BrowserMutationObserver === "function") {
	    requestFlush = makeRequestCallFromMutationObserver(flush);

	// MessageChannels are desirable because they give direct access to the HTML
	// task queue, are implemented in Internet Explorer 10, Safari 5.0-1, and Opera
	// 11-12, and in web workers in many engines.
	// Although message channels yield to any queued rendering and IO tasks, they
	// would be better than imposing the 4ms delay of timers.
	// However, they do not work reliably in Internet Explorer or Safari.

	// Internet Explorer 10 is the only browser that has setImmediate but does
	// not have MutationObservers.
	// Although setImmediate yields to the browser's renderer, it would be
	// preferrable to falling back to setTimeout since it does not have
	// the minimum 4ms penalty.
	// Unfortunately there appears to be a bug in Internet Explorer 10 Mobile (and
	// Desktop to a lesser extent) that renders both setImmediate and
	// MessageChannel useless for the purposes of ASAP.
	// https://github.com/kriskowal/q/issues/396

	// Timers are implemented universally.
	// We fall back to timers in workers in most engines, and in foreground
	// contexts in the following browsers.
	// However, note that even this simple case requires nuances to operate in a
	// broad spectrum of browsers.
	//
	// - Firefox 3-13
	// - Internet Explorer 6-9
	// - iPad Safari 4.3
	// - Lynx 2.8.7
	} else {
	    requestFlush = makeRequestCallFromTimer(flush);
	}

	// `requestFlush` requests that the high priority event queue be flushed as
	// soon as possible.
	// This is useful to prevent an error thrown in a task from stalling the event
	// queue if the exception handled by Node.js’s
	// `process.on("uncaughtException")` or by a domain.
	rawAsap.requestFlush = requestFlush;

	// To request a high priority event, we induce a mutation observer by toggling
	// the text of a text node between "1" and "-1".
	function makeRequestCallFromMutationObserver(callback) {
	    var toggle = 1;
	    var observer = new BrowserMutationObserver(callback);
	    var node = document.createTextNode("");
	    observer.observe(node, {characterData: true});
	    return function requestCall() {
	        toggle = -toggle;
	        node.data = toggle;
	    };
	}

	// The message channel technique was discovered by Malte Ubl and was the
	// original foundation for this library.
	// http://www.nonblocking.io/2011/06/windownexttick.html

	// Safari 6.0.5 (at least) intermittently fails to create message ports on a
	// page's first load. Thankfully, this version of Safari supports
	// MutationObservers, so we don't need to fall back in that case.

	// function makeRequestCallFromMessageChannel(callback) {
	//     var channel = new MessageChannel();
	//     channel.port1.onmessage = callback;
	//     return function requestCall() {
	//         channel.port2.postMessage(0);
	//     };
	// }

	// For reasons explained above, we are also unable to use `setImmediate`
	// under any circumstances.
	// Even if we were, there is another bug in Internet Explorer 10.
	// It is not sufficient to assign `setImmediate` to `requestFlush` because
	// `setImmediate` must be called *by name* and therefore must be wrapped in a
	// closure.
	// Never forget.

	// function makeRequestCallFromSetImmediate(callback) {
	//     return function requestCall() {
	//         setImmediate(callback);
	//     };
	// }

	// Safari 6.0 has a problem where timers will get lost while the user is
	// scrolling. This problem does not impact ASAP because Safari 6.0 supports
	// mutation observers, so that implementation is used instead.
	// However, if we ever elect to use timers in Safari, the prevalent work-around
	// is to add a scroll event listener that calls for a flush.

	// `setTimeout` does not call the passed callback if the delay is less than
	// approximately 7 in web workers in Firefox 8 through 18, and sometimes not
	// even then.

	function makeRequestCallFromTimer(callback) {
	    return function requestCall() {
	        // We dispatch a timeout with a specified delay of 0 for engines that
	        // can reliably accommodate that request. This will usually be snapped
	        // to a 4 milisecond delay, but once we're flushing, there's no delay
	        // between events.
	        var timeoutHandle = setTimeout(handleTimer, 0);
	        // However, since this timer gets frequently dropped in Firefox
	        // workers, we enlist an interval handle that will try to fire
	        // an event 20 times per second until it succeeds.
	        var intervalHandle = setInterval(handleTimer, 50);

	        function handleTimer() {
	            // Whichever timer succeeds will cancel both timers and
	            // execute the callback.
	            clearTimeout(timeoutHandle);
	            clearInterval(intervalHandle);
	            callback();
	        }
	    };
	}

	// This is for `asap.js` only.
	// Its name will be periodically randomized to break any code that depends on
	// its existence.
	rawAsap.makeRequestCallFromTimer = makeRequestCallFromTimer;

	// ASAP was originally a nextTick shim included in Q. This was factored out
	// into this ASAP package. It was later adapted to RSVP which made further
	// amendments. These decisions, particularly to marginalize MessageChannel and
	// to capture the MutationObserver implementation in a closure, were integrated
	// back into ASAP proper.
	// https://github.com/tildeio/rsvp.js/blob/cddf7232546a9cf858524b75cde6f9edf72620a7/lib/rsvp/asap.js

	/* WEBPACK VAR INJECTION */}.call(exports, (function() { return this; }())))

/***/ },

/***/ 1587:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = getNextUniqueId;
	var nextUniqueId = 0;

	function getNextUniqueId() {
		return nextUniqueId++;
	}

/***/ },

/***/ 1588:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var DragSource = function () {
		function DragSource() {
			_classCallCheck(this, DragSource);
		}

		_createClass(DragSource, [{
			key: "canDrag",
			value: function canDrag() {
				return true;
			}
		}, {
			key: "isDragging",
			value: function isDragging(monitor, handle) {
				return handle === monitor.getSourceId();
			}
		}, {
			key: "endDrag",
			value: function endDrag() {}
		}]);

		return DragSource;
	}();

	exports.default = DragSource;

/***/ },

/***/ 1589:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var DropTarget = function () {
		function DropTarget() {
			_classCallCheck(this, DropTarget);
		}

		_createClass(DropTarget, [{
			key: "canDrop",
			value: function canDrop() {
				return true;
			}
		}, {
			key: "hover",
			value: function hover() {}
		}, {
			key: "drop",
			value: function drop() {}
		}]);

		return DropTarget;
	}();

	exports.default = DropTarget;

/***/ },

/***/ 1590:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = createBackend;

	var _noop = __webpack_require__(1559);

	var _noop2 = _interopRequireDefault(_noop);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var TestBackend = function () {
		function TestBackend(manager) {
			_classCallCheck(this, TestBackend);

			this.actions = manager.getActions();
		}

		_createClass(TestBackend, [{
			key: 'setup',
			value: function setup() {
				this.didCallSetup = true;
			}
		}, {
			key: 'teardown',
			value: function teardown() {
				this.didCallTeardown = true;
			}
		}, {
			key: 'connectDragSource',
			value: function connectDragSource() {
				return _noop2.default;
			}
		}, {
			key: 'connectDragPreview',
			value: function connectDragPreview() {
				return _noop2.default;
			}
		}, {
			key: 'connectDropTarget',
			value: function connectDropTarget() {
				return _noop2.default;
			}
		}, {
			key: 'simulateBeginDrag',
			value: function simulateBeginDrag(sourceIds, options) {
				this.actions.beginDrag(sourceIds, options);
			}
		}, {
			key: 'simulatePublishDragSource',
			value: function simulatePublishDragSource() {
				this.actions.publishDragSource();
			}
		}, {
			key: 'simulateHover',
			value: function simulateHover(targetIds, options) {
				this.actions.hover(targetIds, options);
			}
		}, {
			key: 'simulateDrop',
			value: function simulateDrop() {
				this.actions.drop();
			}
		}, {
			key: 'simulateEndDrag',
			value: function simulateEndDrag() {
				this.actions.endDrag();
			}
		}]);

		return TestBackend;
	}();

	function createBackend(manager) {
		return new TestBackend(manager);
	}

/***/ },

/***/ 1591:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = checkDecoratorArguments;
	function checkDecoratorArguments(functionName, signature) {
		if (false) {
			for (var i = 0; i < (arguments.length <= 2 ? 0 : arguments.length - 2); i += 1) {
				var arg = arguments.length <= i + 2 ? undefined : arguments[i + 2];
				if (arg && arg.prototype && arg.prototype.render) {
					// eslint-disable-next-line no-console
					console.error('You seem to be applying the arguments in the wrong order. ' + ('It should be ' + functionName + '(' + signature + ')(Component), not the other way around. ') + 'Read more: http://react-dnd.github.io/react-dnd/docs-troubleshooting.html#you-seem-to-be-applying-the-arguments-in-the-wrong-order');
					return;
				}
			}
		}
	}

/***/ },

/***/ 1592:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = undefined;

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _class, _temp;

	var _react = __webpack_require__(89);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _DragDropContext = __webpack_require__(1569);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	/**
	 * This class is a React-Component based version of the DragDropContext.
	 * This is an alternative to decorating an application component with an ES7 decorator.
	 */
	var DragDropContextProvider = (_temp = _class = function (_Component) {
		_inherits(DragDropContextProvider, _Component);

		function DragDropContextProvider(props, context) {
			_classCallCheck(this, DragDropContextProvider);

			/**
	     * This property determines which window global to use for creating the DragDropManager.
	     * If a window has been injected explicitly via props, that is used first. If it is available
	     * as a context value, then use that, otherwise use the browser global.
	     */
			var _this = _possibleConstructorReturn(this, (DragDropContextProvider.__proto__ || Object.getPrototypeOf(DragDropContextProvider)).call(this, props, context));

			var getWindow = function getWindow() {
				if (props && props.window) {
					return props.window;
				} else if (context && context.window) {
					return context.window;
				} else if (typeof window !== 'undefined') {
					return window;
				}
				return undefined;
			};

			_this.backend = (0, _DragDropContext.unpackBackendForEs5Users)(props.backend);
			_this.childContext = (0, _DragDropContext.createChildContext)(_this.backend, {
				window: getWindow()
			});
			return _this;
		}

		_createClass(DragDropContextProvider, [{
			key: 'componentWillReceiveProps',
			value: function componentWillReceiveProps(nextProps) {
				if (nextProps.backend !== this.props.backend || nextProps.window !== this.props.window) {
					throw new Error('DragDropContextProvider backend and window props must not change.');
				}
			}
		}, {
			key: 'getChildContext',
			value: function getChildContext() {
				return this.childContext;
			}
		}, {
			key: 'render',
			value: function render() {
				return _react.Children.only(this.props.children);
			}
		}]);

		return DragDropContextProvider;
	}(_react.Component), _class.propTypes = {
		backend: _propTypes2.default.oneOfType([_propTypes2.default.func, _propTypes2.default.object]).isRequired,
		children: _propTypes2.default.element.isRequired,
		window: _propTypes2.default.object // eslint-disable-line react/forbid-prop-types
	}, _class.defaultProps = {
		window: undefined
	}, _class.childContextTypes = _DragDropContext.CHILD_CONTEXT_TYPES, _class.displayName = 'DragDropContextProvider', _class.contextTypes = {
		window: _propTypes2.default.object
	}, _temp);
	exports.default = DragDropContextProvider;

/***/ },

/***/ 1593:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = DragLayer;

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _hoistNonReactStatics = __webpack_require__(380);

	var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _shallowEqual = __webpack_require__(1594);

	var _shallowEqual2 = _interopRequireDefault(_shallowEqual);

	var _shallowEqualScalar = __webpack_require__(1595);

	var _shallowEqualScalar2 = _interopRequireDefault(_shallowEqualScalar);

	var _checkDecoratorArguments = __webpack_require__(1591);

	var _checkDecoratorArguments2 = _interopRequireDefault(_checkDecoratorArguments);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	function DragLayer(collect) {
		var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

		_checkDecoratorArguments2.default.apply(undefined, ['DragLayer', 'collect[, options]'].concat(Array.prototype.slice.call(arguments))); // eslint-disable-line prefer-rest-params
		(0, _invariant2.default)(typeof collect === 'function', 'Expected "collect" provided as the first argument to DragLayer to be a function that collects props to inject into the component. ', 'Instead, received %s. Read more: http://react-dnd.github.io/react-dnd/docs-drag-layer.html', collect);
		(0, _invariant2.default)((0, _isPlainObject2.default)(options), 'Expected "options" provided as the second argument to DragLayer to be a plain object when specified. ' + 'Instead, received %s. Read more: http://react-dnd.github.io/react-dnd/docs-drag-layer.html', options);

		return function decorateLayer(DecoratedComponent) {
			var _class, _temp;

			var _options$arePropsEqua = options.arePropsEqual,
			    arePropsEqual = _options$arePropsEqua === undefined ? _shallowEqualScalar2.default : _options$arePropsEqua;

			var displayName = DecoratedComponent.displayName || DecoratedComponent.name || 'Component';

			var DragLayerContainer = (_temp = _class = function (_Component) {
				_inherits(DragLayerContainer, _Component);

				_createClass(DragLayerContainer, [{
					key: 'getDecoratedComponentInstance',
					value: function getDecoratedComponentInstance() {
						(0, _invariant2.default)(this.child, 'In order to access an instance of the decorated component it can not be a stateless component.');
						return this.child;
					}
				}, {
					key: 'shouldComponentUpdate',
					value: function shouldComponentUpdate(nextProps, nextState) {
						return !arePropsEqual(nextProps, this.props) || !(0, _shallowEqual2.default)(nextState, this.state);
					}
				}]);

				function DragLayerContainer(props, context) {
					_classCallCheck(this, DragLayerContainer);

					var _this = _possibleConstructorReturn(this, (DragLayerContainer.__proto__ || Object.getPrototypeOf(DragLayerContainer)).call(this, props));

					_this.handleChange = _this.handleChange.bind(_this);

					_this.manager = context.dragDropManager;
					(0, _invariant2.default)(_typeof(_this.manager) === 'object', 'Could not find the drag and drop manager in the context of %s. ' + 'Make sure to wrap the top-level component of your app with DragDropContext. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-troubleshooting.html#could-not-find-the-drag-and-drop-manager-in-the-context', displayName, displayName);

					_this.state = _this.getCurrentState();
					return _this;
				}

				_createClass(DragLayerContainer, [{
					key: 'componentDidMount',
					value: function componentDidMount() {
						this.isCurrentlyMounted = true;

						var monitor = this.manager.getMonitor();
						this.unsubscribeFromOffsetChange = monitor.subscribeToOffsetChange(this.handleChange);
						this.unsubscribeFromStateChange = monitor.subscribeToStateChange(this.handleChange);

						this.handleChange();
					}
				}, {
					key: 'componentWillUnmount',
					value: function componentWillUnmount() {
						this.isCurrentlyMounted = false;

						this.unsubscribeFromOffsetChange();
						this.unsubscribeFromStateChange();
					}
				}, {
					key: 'handleChange',
					value: function handleChange() {
						if (!this.isCurrentlyMounted) {
							return;
						}

						var nextState = this.getCurrentState();
						if (!(0, _shallowEqual2.default)(nextState, this.state)) {
							this.setState(nextState);
						}
					}
				}, {
					key: 'getCurrentState',
					value: function getCurrentState() {
						var monitor = this.manager.getMonitor();
						return collect(monitor);
					}
				}, {
					key: 'render',
					value: function render() {
						var _this2 = this;

						return _react2.default.createElement(DecoratedComponent, _extends({}, this.props, this.state, {
							ref: function ref(child) {
								_this2.child = child;
							}
						}));
					}
				}]);

				return DragLayerContainer;
			}(_react.Component), _class.DecoratedComponent = DecoratedComponent, _class.displayName = 'DragLayer(' + displayName + ')', _class.contextTypes = {
				dragDropManager: _propTypes2.default.object.isRequired
			}, _temp);


			return (0, _hoistNonReactStatics2.default)(DragLayerContainer, DecoratedComponent);
		};
	}

/***/ },

/***/ 1594:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = shallowEqual;
	function shallowEqual(objA, objB) {
		if (objA === objB) {
			return true;
		}

		var keysA = Object.keys(objA);
		var keysB = Object.keys(objB);

		if (keysA.length !== keysB.length) {
			return false;
		}

		// Test for A's keys different from B.
		var hasOwn = Object.prototype.hasOwnProperty;
		for (var i = 0; i < keysA.length; i += 1) {
			if (!hasOwn.call(objB, keysA[i]) || objA[keysA[i]] !== objB[keysA[i]]) {
				return false;
			}

			var valA = objA[keysA[i]];
			var valB = objB[keysA[i]];

			if (valA !== valB) {
				return false;
			}
		}

		return true;
	}

/***/ },

/***/ 1595:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	exports.default = shallowEqualScalar;
	function shallowEqualScalar(objA, objB) {
		if (objA === objB) {
			return true;
		}

		if ((typeof objA === 'undefined' ? 'undefined' : _typeof(objA)) !== 'object' || objA === null || (typeof objB === 'undefined' ? 'undefined' : _typeof(objB)) !== 'object' || objB === null) {
			return false;
		}

		var keysA = Object.keys(objA);
		var keysB = Object.keys(objB);

		if (keysA.length !== keysB.length) {
			return false;
		}

		// Test for A's keys different from B.
		var hasOwn = Object.prototype.hasOwnProperty;
		for (var i = 0; i < keysA.length; i += 1) {
			if (!hasOwn.call(objB, keysA[i])) {
				return false;
			}

			var valA = objA[keysA[i]];
			var valB = objB[keysA[i]];

			if (valA !== valB || (typeof valA === 'undefined' ? 'undefined' : _typeof(valA)) === 'object' || (typeof valB === 'undefined' ? 'undefined' : _typeof(valB)) === 'object') {
				return false;
			}
		}

		return true;
	}

/***/ },

/***/ 1596:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = DragSource;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	var _checkDecoratorArguments = __webpack_require__(1591);

	var _checkDecoratorArguments2 = _interopRequireDefault(_checkDecoratorArguments);

	var _decorateHandler = __webpack_require__(1597);

	var _decorateHandler2 = _interopRequireDefault(_decorateHandler);

	var _registerSource = __webpack_require__(1603);

	var _registerSource2 = _interopRequireDefault(_registerSource);

	var _createSourceFactory = __webpack_require__(1604);

	var _createSourceFactory2 = _interopRequireDefault(_createSourceFactory);

	var _createSourceMonitor = __webpack_require__(1605);

	var _createSourceMonitor2 = _interopRequireDefault(_createSourceMonitor);

	var _createSourceConnector = __webpack_require__(1606);

	var _createSourceConnector2 = _interopRequireDefault(_createSourceConnector);

	var _isValidType = __webpack_require__(1610);

	var _isValidType2 = _interopRequireDefault(_isValidType);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function DragSource(type, spec, collect) {
		var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

		_checkDecoratorArguments2.default.apply(undefined, ['DragSource', 'type, spec, collect[, options]'].concat(Array.prototype.slice.call(arguments)));
		var getType = type;
		if (typeof type !== 'function') {
			(0, _invariant2.default)((0, _isValidType2.default)(type), 'Expected "type" provided as the first argument to DragSource to be ' + 'a string, or a function that returns a string given the current props. ' + 'Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', type);
			getType = function getType() {
				return type;
			};
		}
		(0, _invariant2.default)((0, _isPlainObject2.default)(spec), 'Expected "spec" provided as the second argument to DragSource to be ' + 'a plain object. Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', spec);
		var createSource = (0, _createSourceFactory2.default)(spec);
		(0, _invariant2.default)(typeof collect === 'function', 'Expected "collect" provided as the third argument to DragSource to be ' + 'a function that returns a plain object of props to inject. ' + 'Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', collect);
		(0, _invariant2.default)((0, _isPlainObject2.default)(options), 'Expected "options" provided as the fourth argument to DragSource to be ' + 'a plain object when specified. ' + 'Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', collect);

		return function decorateSource(DecoratedComponent) {
			return (0, _decorateHandler2.default)({
				connectBackend: function connectBackend(backend, sourceId) {
					return backend.connectDragSource(sourceId);
				},
				containerDisplayName: 'DragSource',
				createHandler: createSource,
				registerHandler: _registerSource2.default,
				createMonitor: _createSourceMonitor2.default,
				createConnector: _createSourceConnector2.default,
				DecoratedComponent: DecoratedComponent,
				getType: getType,
				collect: collect,
				options: options
			});
		};
	}

/***/ },

/***/ 1597:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = decorateHandler;

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _disposables = __webpack_require__(1598);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _hoistNonReactStatics = __webpack_require__(380);

	var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

	var _shallowEqual = __webpack_require__(1594);

	var _shallowEqual2 = _interopRequireDefault(_shallowEqual);

	var _shallowEqualScalar = __webpack_require__(1595);

	var _shallowEqualScalar2 = _interopRequireDefault(_shallowEqualScalar);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var isClassComponent = function isClassComponent(Comp) {
		return Boolean(Comp && Comp.prototype && typeof Comp.prototype.render === 'function');
	};

	function decorateHandler(_ref) {
		var _class, _temp;

		var DecoratedComponent = _ref.DecoratedComponent,
		    createHandler = _ref.createHandler,
		    createMonitor = _ref.createMonitor,
		    createConnector = _ref.createConnector,
		    registerHandler = _ref.registerHandler,
		    containerDisplayName = _ref.containerDisplayName,
		    getType = _ref.getType,
		    collect = _ref.collect,
		    options = _ref.options;
		var _options$arePropsEqua = options.arePropsEqual,
		    arePropsEqual = _options$arePropsEqua === undefined ? _shallowEqualScalar2.default : _options$arePropsEqua;

		var displayName = DecoratedComponent.displayName || DecoratedComponent.name || 'Component';

		var DragDropContainer = (_temp = _class = function (_Component) {
			_inherits(DragDropContainer, _Component);

			_createClass(DragDropContainer, [{
				key: 'getHandlerId',
				value: function getHandlerId() {
					return this.handlerId;
				}
			}, {
				key: 'getDecoratedComponentInstance',
				value: function getDecoratedComponentInstance() {
					return this.decoratedComponentInstance;
				}
			}, {
				key: 'shouldComponentUpdate',
				value: function shouldComponentUpdate(nextProps, nextState) {
					return !arePropsEqual(nextProps, this.props) || !(0, _shallowEqual2.default)(nextState, this.state);
				}
			}]);

			function DragDropContainer(props, context) {
				_classCallCheck(this, DragDropContainer);

				var _this = _possibleConstructorReturn(this, (DragDropContainer.__proto__ || Object.getPrototypeOf(DragDropContainer)).call(this, props, context));

				_this.handleChange = _this.handleChange.bind(_this);
				_this.handleChildRef = _this.handleChildRef.bind(_this);

				(0, _invariant2.default)(_typeof(_this.context.dragDropManager) === 'object', 'Could not find the drag and drop manager in the context of %s. ' + 'Make sure to wrap the top-level component of your app with DragDropContext. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-troubleshooting.html#could-not-find-the-drag-and-drop-manager-in-the-context', displayName, displayName);

				_this.manager = _this.context.dragDropManager;
				_this.handlerMonitor = createMonitor(_this.manager);
				_this.handlerConnector = createConnector(_this.manager.getBackend());
				_this.handler = createHandler(_this.handlerMonitor);

				_this.disposable = new _disposables.SerialDisposable();
				_this.receiveProps(props);
				_this.state = _this.getCurrentState();
				_this.dispose();
				return _this;
			}

			_createClass(DragDropContainer, [{
				key: 'componentDidMount',
				value: function componentDidMount() {
					this.isCurrentlyMounted = true;
					this.disposable = new _disposables.SerialDisposable();
					this.currentType = null;
					this.receiveProps(this.props);
					this.handleChange();
				}
			}, {
				key: 'componentWillReceiveProps',
				value: function componentWillReceiveProps(nextProps) {
					if (!arePropsEqual(nextProps, this.props)) {
						this.receiveProps(nextProps);
						this.handleChange();
					}
				}
			}, {
				key: 'componentWillUnmount',
				value: function componentWillUnmount() {
					this.dispose();
					this.isCurrentlyMounted = false;
				}
			}, {
				key: 'receiveProps',
				value: function receiveProps(props) {
					this.handler.receiveProps(props);
					this.receiveType(getType(props));
				}
			}, {
				key: 'receiveType',
				value: function receiveType(type) {
					if (type === this.currentType) {
						return;
					}

					this.currentType = type;

					var _registerHandler = registerHandler(type, this.handler, this.manager),
					    handlerId = _registerHandler.handlerId,
					    unregister = _registerHandler.unregister;

					this.handlerId = handlerId;
					this.handlerMonitor.receiveHandlerId(handlerId);
					this.handlerConnector.receiveHandlerId(handlerId);

					var globalMonitor = this.manager.getMonitor();
					var unsubscribe = globalMonitor.subscribeToStateChange(this.handleChange, { handlerIds: [handlerId] });

					this.disposable.setDisposable(new _disposables.CompositeDisposable(new _disposables.Disposable(unsubscribe), new _disposables.Disposable(unregister)));
				}
			}, {
				key: 'handleChange',
				value: function handleChange() {
					if (!this.isCurrentlyMounted) {
						return;
					}

					var nextState = this.getCurrentState();
					if (!(0, _shallowEqual2.default)(nextState, this.state)) {
						this.setState(nextState);
					}
				}
			}, {
				key: 'dispose',
				value: function dispose() {
					this.disposable.dispose();
					this.handlerConnector.receiveHandlerId(null);
				}
			}, {
				key: 'handleChildRef',
				value: function handleChildRef(component) {
					this.decoratedComponentInstance = component;
					this.handler.receiveComponent(component);
				}
			}, {
				key: 'getCurrentState',
				value: function getCurrentState() {
					var nextState = collect(this.handlerConnector.hooks, this.handlerMonitor);

					if (false) {
						(0, _invariant2.default)((0, _isPlainObject2.default)(nextState), 'Expected `collect` specified as the second argument to ' + '%s for %s to return a plain object of props to inject. ' + 'Instead, received %s.', containerDisplayName, displayName, nextState);
					}

					return nextState;
				}
			}, {
				key: 'render',
				value: function render() {
					return _react2.default.createElement(DecoratedComponent, _extends({}, this.props, this.state, {
						ref: isClassComponent(DecoratedComponent) ? this.handleChildRef : null
					}));
				}
			}]);

			return DragDropContainer;
		}(_react.Component), _class.DecoratedComponent = DecoratedComponent, _class.displayName = containerDisplayName + '(' + displayName + ')', _class.contextTypes = {
			dragDropManager: _propTypes2.default.object.isRequired
		}, _temp);


		return (0, _hoistNonReactStatics2.default)(DragDropContainer, DecoratedComponent);
	}

/***/ },

/***/ 1598:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _isDisposable2 = __webpack_require__(1599);

	var _isDisposable3 = _interopRequireDefault(_isDisposable2);

	exports.isDisposable = _isDisposable3['default'];

	var _Disposable2 = __webpack_require__(1600);

	var _Disposable3 = _interopRequireDefault(_Disposable2);

	exports.Disposable = _Disposable3['default'];

	var _CompositeDisposable2 = __webpack_require__(1601);

	var _CompositeDisposable3 = _interopRequireDefault(_CompositeDisposable2);

	exports.CompositeDisposable = _CompositeDisposable3['default'];

	var _SerialDisposable2 = __webpack_require__(1602);

	var _SerialDisposable3 = _interopRequireDefault(_SerialDisposable2);

	exports.SerialDisposable = _SerialDisposable3['default'];

/***/ },

/***/ 1599:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;
	exports['default'] = isDisposable;

	function isDisposable(obj) {
	  return Boolean(obj && typeof obj.dispose === 'function');
	}

	module.exports = exports['default'];

/***/ },

/***/ 1600:
/***/ function(module, exports) {

	"use strict";

	exports.__esModule = true;

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var noop = function noop() {};

	/**
	 * The basic disposable.
	 */

	var Disposable = (function () {
	  _createClass(Disposable, null, [{
	    key: "empty",
	    value: { dispose: noop },
	    enumerable: true
	  }]);

	  function Disposable(action) {
	    _classCallCheck(this, Disposable);

	    this.isDisposed = false;
	    this.action = action || noop;
	  }

	  Disposable.prototype.dispose = function dispose() {
	    if (!this.isDisposed) {
	      this.action.call(null);
	      this.isDisposed = true;
	    }
	  };

	  return Disposable;
	})();

	exports["default"] = Disposable;
	module.exports = exports["default"];

/***/ },

/***/ 1601:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _isDisposable = __webpack_require__(1599);

	var _isDisposable2 = _interopRequireDefault(_isDisposable);

	/**
	 * Represents a group of disposable resources that are disposed together.
	 */

	var CompositeDisposable = (function () {
	  function CompositeDisposable() {
	    for (var _len = arguments.length, disposables = Array(_len), _key = 0; _key < _len; _key++) {
	      disposables[_key] = arguments[_key];
	    }

	    _classCallCheck(this, CompositeDisposable);

	    if (Array.isArray(disposables[0]) && disposables.length === 1) {
	      disposables = disposables[0];
	    }

	    for (var i = 0; i < disposables.length; i++) {
	      if (!_isDisposable2['default'](disposables[i])) {
	        throw new Error('Expected a disposable');
	      }
	    }

	    this.disposables = disposables;
	    this.isDisposed = false;
	  }

	  /**
	   * Adds a disposable to the CompositeDisposable or disposes the disposable if the CompositeDisposable is disposed.
	   * @param {Disposable} item Disposable to add.
	   */

	  CompositeDisposable.prototype.add = function add(item) {
	    if (this.isDisposed) {
	      item.dispose();
	    } else {
	      this.disposables.push(item);
	    }
	  };

	  /**
	   * Removes and disposes the first occurrence of a disposable from the CompositeDisposable.
	   * @param {Disposable} item Disposable to remove.
	   * @returns {Boolean} true if found; false otherwise.
	   */

	  CompositeDisposable.prototype.remove = function remove(item) {
	    if (this.isDisposed) {
	      return false;
	    }

	    var index = this.disposables.indexOf(item);
	    if (index === -1) {
	      return false;
	    }

	    this.disposables.splice(index, 1);
	    item.dispose();
	    return true;
	  };

	  /**
	   * Disposes all disposables in the group and removes them from the group.
	   */

	  CompositeDisposable.prototype.dispose = function dispose() {
	    if (this.isDisposed) {
	      return;
	    }

	    var len = this.disposables.length;
	    var currentDisposables = new Array(len);
	    for (var i = 0; i < len; i++) {
	      currentDisposables[i] = this.disposables[i];
	    }

	    this.isDisposed = true;
	    this.disposables = [];
	    this.length = 0;

	    for (var i = 0; i < len; i++) {
	      currentDisposables[i].dispose();
	    }
	  };

	  return CompositeDisposable;
	})();

	exports['default'] = CompositeDisposable;
	module.exports = exports['default'];

/***/ },

/***/ 1602:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _isDisposable = __webpack_require__(1599);

	var _isDisposable2 = _interopRequireDefault(_isDisposable);

	var SerialDisposable = (function () {
	  function SerialDisposable() {
	    _classCallCheck(this, SerialDisposable);

	    this.isDisposed = false;
	    this.current = null;
	  }

	  /**
	   * Gets the underlying disposable.
	   * @return The underlying disposable.
	   */

	  SerialDisposable.prototype.getDisposable = function getDisposable() {
	    return this.current;
	  };

	  /**
	   * Sets the underlying disposable.
	   * @param {Disposable} value The new underlying disposable.
	   */

	  SerialDisposable.prototype.setDisposable = function setDisposable() {
	    var value = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];

	    if (value != null && !_isDisposable2['default'](value)) {
	      throw new Error('Expected either an empty value or a valid disposable');
	    }

	    var isDisposed = this.isDisposed;
	    var previous = undefined;

	    if (!isDisposed) {
	      previous = this.current;
	      this.current = value;
	    }

	    if (previous) {
	      previous.dispose();
	    }

	    if (isDisposed && value) {
	      value.dispose();
	    }
	  };

	  /**
	   * Disposes the underlying disposable as well as all future replacements.
	   */

	  SerialDisposable.prototype.dispose = function dispose() {
	    if (this.isDisposed) {
	      return;
	    }

	    this.isDisposed = true;
	    var previous = this.current;
	    this.current = null;

	    if (previous) {
	      previous.dispose();
	    }
	  };

	  return SerialDisposable;
	})();

	exports['default'] = SerialDisposable;
	module.exports = exports['default'];

/***/ },

/***/ 1603:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = registerSource;
	function registerSource(type, source, manager) {
		var registry = manager.getRegistry();
		var sourceId = registry.addSource(type, source);

		function unregisterSource() {
			registry.removeSource(sourceId);
		}

		return {
			handlerId: sourceId,
			unregister: unregisterSource
		};
	}

/***/ },

/***/ 1604:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = createSourceFactory;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var ALLOWED_SPEC_METHODS = ['canDrag', 'beginDrag', 'isDragging', 'endDrag'];
	var REQUIRED_SPEC_METHODS = ['beginDrag'];

	function createSourceFactory(spec) {
		Object.keys(spec).forEach(function (key) {
			(0, _invariant2.default)(ALLOWED_SPEC_METHODS.indexOf(key) > -1, 'Expected the drag source specification to only have ' + 'some of the following keys: %s. ' + 'Instead received a specification with an unexpected "%s" key. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', ALLOWED_SPEC_METHODS.join(', '), key);
			(0, _invariant2.default)(typeof spec[key] === 'function', 'Expected %s in the drag source specification to be a function. ' + 'Instead received a specification with %s: %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', key, key, spec[key]);
		});
		REQUIRED_SPEC_METHODS.forEach(function (key) {
			(0, _invariant2.default)(typeof spec[key] === 'function', 'Expected %s in the drag source specification to be a function. ' + 'Instead received a specification with %s: %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', key, key, spec[key]);
		});

		var Source = function () {
			function Source(monitor) {
				_classCallCheck(this, Source);

				this.monitor = monitor;
				this.props = null;
				this.component = null;
			}

			_createClass(Source, [{
				key: 'receiveProps',
				value: function receiveProps(props) {
					this.props = props;
				}
			}, {
				key: 'receiveComponent',
				value: function receiveComponent(component) {
					this.component = component;
				}
			}, {
				key: 'canDrag',
				value: function canDrag() {
					if (!spec.canDrag) {
						return true;
					}

					return spec.canDrag(this.props, this.monitor);
				}
			}, {
				key: 'isDragging',
				value: function isDragging(globalMonitor, sourceId) {
					if (!spec.isDragging) {
						return sourceId === globalMonitor.getSourceId();
					}

					return spec.isDragging(this.props, this.monitor);
				}
			}, {
				key: 'beginDrag',
				value: function beginDrag() {
					var item = spec.beginDrag(this.props, this.monitor, this.component);
					if (false) {
						(0, _invariant2.default)((0, _isPlainObject2.default)(item), 'beginDrag() must return a plain object that represents the dragged item. ' + 'Instead received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source.html', item);
					}
					return item;
				}
			}, {
				key: 'endDrag',
				value: function endDrag() {
					if (!spec.endDrag) {
						return;
					}

					spec.endDrag(this.props, this.monitor, this.component);
				}
			}]);

			return Source;
		}();

		return function createSource(monitor) {
			return new Source(monitor);
		};
	}

/***/ },

/***/ 1605:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = createSourceMonitor;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var isCallingCanDrag = false;
	var isCallingIsDragging = false;

	var SourceMonitor = function () {
		function SourceMonitor(manager) {
			_classCallCheck(this, SourceMonitor);

			this.internalMonitor = manager.getMonitor();
		}

		_createClass(SourceMonitor, [{
			key: 'receiveHandlerId',
			value: function receiveHandlerId(sourceId) {
				this.sourceId = sourceId;
			}
		}, {
			key: 'canDrag',
			value: function canDrag() {
				(0, _invariant2.default)(!isCallingCanDrag, 'You may not call monitor.canDrag() inside your canDrag() implementation. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source-monitor.html');

				try {
					isCallingCanDrag = true;
					return this.internalMonitor.canDragSource(this.sourceId);
				} finally {
					isCallingCanDrag = false;
				}
			}
		}, {
			key: 'isDragging',
			value: function isDragging() {
				(0, _invariant2.default)(!isCallingIsDragging, 'You may not call monitor.isDragging() inside your isDragging() implementation. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drag-source-monitor.html');

				try {
					isCallingIsDragging = true;
					return this.internalMonitor.isDraggingSource(this.sourceId);
				} finally {
					isCallingIsDragging = false;
				}
			}
		}, {
			key: 'getItemType',
			value: function getItemType() {
				return this.internalMonitor.getItemType();
			}
		}, {
			key: 'getItem',
			value: function getItem() {
				return this.internalMonitor.getItem();
			}
		}, {
			key: 'getDropResult',
			value: function getDropResult() {
				return this.internalMonitor.getDropResult();
			}
		}, {
			key: 'didDrop',
			value: function didDrop() {
				return this.internalMonitor.didDrop();
			}
		}, {
			key: 'getInitialClientOffset',
			value: function getInitialClientOffset() {
				return this.internalMonitor.getInitialClientOffset();
			}
		}, {
			key: 'getInitialSourceClientOffset',
			value: function getInitialSourceClientOffset() {
				return this.internalMonitor.getInitialSourceClientOffset();
			}
		}, {
			key: 'getSourceClientOffset',
			value: function getSourceClientOffset() {
				return this.internalMonitor.getSourceClientOffset();
			}
		}, {
			key: 'getClientOffset',
			value: function getClientOffset() {
				return this.internalMonitor.getClientOffset();
			}
		}, {
			key: 'getDifferenceFromInitialOffset',
			value: function getDifferenceFromInitialOffset() {
				return this.internalMonitor.getDifferenceFromInitialOffset();
			}
		}]);

		return SourceMonitor;
	}();

	function createSourceMonitor(manager) {
		return new SourceMonitor(manager);
	}

/***/ },

/***/ 1606:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = createSourceConnector;

	var _wrapConnectorHooks = __webpack_require__(1607);

	var _wrapConnectorHooks2 = _interopRequireDefault(_wrapConnectorHooks);

	var _areOptionsEqual = __webpack_require__(1609);

	var _areOptionsEqual2 = _interopRequireDefault(_areOptionsEqual);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function createSourceConnector(backend) {
		var currentHandlerId = void 0;

		var currentDragSourceNode = void 0;
		var currentDragSourceOptions = void 0;
		var disconnectCurrentDragSource = void 0;

		var currentDragPreviewNode = void 0;
		var currentDragPreviewOptions = void 0;
		var disconnectCurrentDragPreview = void 0;

		function reconnectDragSource() {
			if (disconnectCurrentDragSource) {
				disconnectCurrentDragSource();
				disconnectCurrentDragSource = null;
			}

			if (currentHandlerId && currentDragSourceNode) {
				disconnectCurrentDragSource = backend.connectDragSource(currentHandlerId, currentDragSourceNode, currentDragSourceOptions);
			}
		}

		function reconnectDragPreview() {
			if (disconnectCurrentDragPreview) {
				disconnectCurrentDragPreview();
				disconnectCurrentDragPreview = null;
			}

			if (currentHandlerId && currentDragPreviewNode) {
				disconnectCurrentDragPreview = backend.connectDragPreview(currentHandlerId, currentDragPreviewNode, currentDragPreviewOptions);
			}
		}

		function receiveHandlerId(handlerId) {
			if (handlerId === currentHandlerId) {
				return;
			}

			currentHandlerId = handlerId;
			reconnectDragSource();
			reconnectDragPreview();
		}

		var hooks = (0, _wrapConnectorHooks2.default)({
			dragSource: function connectDragSource(node, options) {
				if (node === currentDragSourceNode && (0, _areOptionsEqual2.default)(options, currentDragSourceOptions)) {
					return;
				}

				currentDragSourceNode = node;
				currentDragSourceOptions = options;

				reconnectDragSource();
			},

			dragPreview: function connectDragPreview(node, options) {
				if (node === currentDragPreviewNode && (0, _areOptionsEqual2.default)(options, currentDragPreviewOptions)) {
					return;
				}

				currentDragPreviewNode = node;
				currentDragPreviewOptions = options;

				reconnectDragPreview();
			}
		});

		return {
			receiveHandlerId: receiveHandlerId,
			hooks: hooks
		};
	}

/***/ },

/***/ 1607:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = wrapConnectorHooks;

	var _react = __webpack_require__(89);

	var _cloneWithRef = __webpack_require__(1608);

	var _cloneWithRef2 = _interopRequireDefault(_cloneWithRef);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function throwIfCompositeComponentElement(element) {
		// Custom components can no longer be wrapped directly in React DnD 2.0
		// so that we don't need to depend on findDOMNode() from react-dom.
		if (typeof element.type === 'string') {
			return;
		}

		var displayName = element.type.displayName || element.type.name || 'the component';

		throw new Error('Only native element nodes can now be passed to React DnD connectors.' + ('You can either wrap ' + displayName + ' into a <div>, or turn it into a ') + 'drag source or a drop target itself.');
	}

	function wrapHookToRecognizeElement(hook) {
		return function () {
			var elementOrNode = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;
			var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

			// When passed a node, call the hook straight away.
			if (!(0, _react.isValidElement)(elementOrNode)) {
				var node = elementOrNode;
				hook(node, options);
				return undefined;
			}

			// If passed a ReactElement, clone it and attach this function as a ref.
			// This helps us achieve a neat API where user doesn't even know that refs
			// are being used under the hood.
			var element = elementOrNode;
			throwIfCompositeComponentElement(element);

			// When no options are passed, use the hook directly
			var ref = options ? function (node) {
				return hook(node, options);
			} : hook;

			return (0, _cloneWithRef2.default)(element, ref);
		};
	}

	function wrapConnectorHooks(hooks) {
		var wrappedHooks = {};

		Object.keys(hooks).forEach(function (key) {
			var hook = hooks[key];
			var wrappedHook = wrapHookToRecognizeElement(hook);
			wrappedHooks[key] = function () {
				return wrappedHook;
			};
		});

		return wrappedHooks;
	}

/***/ },

/***/ 1608:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = cloneWithRef;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _react = __webpack_require__(89);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function cloneWithRef(element, newRef) {
		var previousRef = element.ref;
		(0, _invariant2.default)(typeof previousRef !== 'string', 'Cannot connect React DnD to an element with an existing string ref. ' + 'Please convert it to use a callback ref instead, or wrap it into a <span> or <div>. ' + 'Read more: https://facebook.github.io/react/docs/more-about-refs.html#the-ref-callback-attribute');

		if (!previousRef) {
			// When there is no ref on the element, use the new ref directly
			return (0, _react.cloneElement)(element, {
				ref: newRef
			});
		}

		return (0, _react.cloneElement)(element, {
			ref: function ref(node) {
				newRef(node);

				if (previousRef) {
					previousRef(node);
				}
			}
		});
	}

/***/ },

/***/ 1609:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = areOptionsEqual;

	var _shallowEqual = __webpack_require__(1594);

	var _shallowEqual2 = _interopRequireDefault(_shallowEqual);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function areOptionsEqual(nextOptions, currentOptions) {
		if (currentOptions === nextOptions) {
			return true;
		}

		return currentOptions !== null && nextOptions !== null && (0, _shallowEqual2.default)(currentOptions, nextOptions);
	}

/***/ },

/***/ 1610:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	exports.default = isValidType;

	var _isArray = __webpack_require__(282);

	var _isArray2 = _interopRequireDefault(_isArray);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function isValidType(type, allowArray) {
		return typeof type === 'string' || (typeof type === 'undefined' ? 'undefined' : _typeof(type)) === 'symbol' || allowArray && (0, _isArray2.default)(type) && type.every(function (t) {
			return isValidType(t, false);
		});
	}

/***/ },

/***/ 1611:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = DropTarget;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	var _checkDecoratorArguments = __webpack_require__(1591);

	var _checkDecoratorArguments2 = _interopRequireDefault(_checkDecoratorArguments);

	var _decorateHandler = __webpack_require__(1597);

	var _decorateHandler2 = _interopRequireDefault(_decorateHandler);

	var _registerTarget = __webpack_require__(1612);

	var _registerTarget2 = _interopRequireDefault(_registerTarget);

	var _createTargetFactory = __webpack_require__(1613);

	var _createTargetFactory2 = _interopRequireDefault(_createTargetFactory);

	var _createTargetMonitor = __webpack_require__(1614);

	var _createTargetMonitor2 = _interopRequireDefault(_createTargetMonitor);

	var _createTargetConnector = __webpack_require__(1615);

	var _createTargetConnector2 = _interopRequireDefault(_createTargetConnector);

	var _isValidType = __webpack_require__(1610);

	var _isValidType2 = _interopRequireDefault(_isValidType);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function DropTarget(type, spec, collect) {
		var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

		_checkDecoratorArguments2.default.apply(undefined, ['DropTarget', 'type, spec, collect[, options]'].concat(Array.prototype.slice.call(arguments)));
		var getType = type;
		if (typeof type !== 'function') {
			(0, _invariant2.default)((0, _isValidType2.default)(type, true), 'Expected "type" provided as the first argument to DropTarget to be ' + 'a string, an array of strings, or a function that returns either given ' + 'the current props. Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', type);
			getType = function getType() {
				return type;
			};
		}
		(0, _invariant2.default)((0, _isPlainObject2.default)(spec), 'Expected "spec" provided as the second argument to DropTarget to be ' + 'a plain object. Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', spec);
		var createTarget = (0, _createTargetFactory2.default)(spec);
		(0, _invariant2.default)(typeof collect === 'function', 'Expected "collect" provided as the third argument to DropTarget to be ' + 'a function that returns a plain object of props to inject. ' + 'Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', collect);
		(0, _invariant2.default)((0, _isPlainObject2.default)(options), 'Expected "options" provided as the fourth argument to DropTarget to be ' + 'a plain object when specified. ' + 'Instead, received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', collect);

		return function decorateTarget(DecoratedComponent) {
			return (0, _decorateHandler2.default)({
				connectBackend: function connectBackend(backend, targetId) {
					return backend.connectDropTarget(targetId);
				},
				containerDisplayName: 'DropTarget',
				createHandler: createTarget,
				registerHandler: _registerTarget2.default,
				createMonitor: _createTargetMonitor2.default,
				createConnector: _createTargetConnector2.default,
				DecoratedComponent: DecoratedComponent,
				getType: getType,
				collect: collect,
				options: options
			});
		};
	}

/***/ },

/***/ 1612:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = registerTarget;
	function registerTarget(type, target, manager) {
		var registry = manager.getRegistry();
		var targetId = registry.addTarget(type, target);

		function unregisterTarget() {
			registry.removeTarget(targetId);
		}

		return {
			handlerId: targetId,
			unregister: unregisterTarget
		};
	}

/***/ },

/***/ 1613:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = createTargetFactory;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	var _isPlainObject = __webpack_require__(545);

	var _isPlainObject2 = _interopRequireDefault(_isPlainObject);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var ALLOWED_SPEC_METHODS = ['canDrop', 'hover', 'drop'];

	function createTargetFactory(spec) {
		Object.keys(spec).forEach(function (key) {
			(0, _invariant2.default)(ALLOWED_SPEC_METHODS.indexOf(key) > -1, 'Expected the drop target specification to only have ' + 'some of the following keys: %s. ' + 'Instead received a specification with an unexpected "%s" key. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', ALLOWED_SPEC_METHODS.join(', '), key);
			(0, _invariant2.default)(typeof spec[key] === 'function', 'Expected %s in the drop target specification to be a function. ' + 'Instead received a specification with %s: %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', key, key, spec[key]);
		});

		var Target = function () {
			function Target(monitor) {
				_classCallCheck(this, Target);

				this.monitor = monitor;
				this.props = null;
				this.component = null;
			}

			_createClass(Target, [{
				key: 'receiveProps',
				value: function receiveProps(props) {
					this.props = props;
				}
			}, {
				key: 'receiveMonitor',
				value: function receiveMonitor(monitor) {
					this.monitor = monitor;
				}
			}, {
				key: 'receiveComponent',
				value: function receiveComponent(component) {
					this.component = component;
				}
			}, {
				key: 'canDrop',
				value: function canDrop() {
					if (!spec.canDrop) {
						return true;
					}

					return spec.canDrop(this.props, this.monitor);
				}
			}, {
				key: 'hover',
				value: function hover() {
					if (!spec.hover) {
						return;
					}

					spec.hover(this.props, this.monitor, this.component);
				}
			}, {
				key: 'drop',
				value: function drop() {
					if (!spec.drop) {
						return undefined;
					}

					var dropResult = spec.drop(this.props, this.monitor, this.component);
					if (false) {
						(0, _invariant2.default)(typeof dropResult === 'undefined' || (0, _isPlainObject2.default)(dropResult), 'drop() must either return undefined, or an object that represents the drop result. ' + 'Instead received %s. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target.html', dropResult);
					}
					return dropResult;
				}
			}]);

			return Target;
		}();

		return function createTarget(monitor) {
			return new Target(monitor);
		};
	}

/***/ },

/***/ 1614:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	exports.default = createTargetMonitor;

	var _invariant = __webpack_require__(475);

	var _invariant2 = _interopRequireDefault(_invariant);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var isCallingCanDrop = false;

	var TargetMonitor = function () {
		function TargetMonitor(manager) {
			_classCallCheck(this, TargetMonitor);

			this.internalMonitor = manager.getMonitor();
		}

		_createClass(TargetMonitor, [{
			key: 'receiveHandlerId',
			value: function receiveHandlerId(targetId) {
				this.targetId = targetId;
			}
		}, {
			key: 'canDrop',
			value: function canDrop() {
				(0, _invariant2.default)(!isCallingCanDrop, 'You may not call monitor.canDrop() inside your canDrop() implementation. ' + 'Read more: http://react-dnd.github.io/react-dnd/docs-drop-target-monitor.html');

				try {
					isCallingCanDrop = true;
					return this.internalMonitor.canDropOnTarget(this.targetId);
				} finally {
					isCallingCanDrop = false;
				}
			}
		}, {
			key: 'isOver',
			value: function isOver(options) {
				return this.internalMonitor.isOverTarget(this.targetId, options);
			}
		}, {
			key: 'getItemType',
			value: function getItemType() {
				return this.internalMonitor.getItemType();
			}
		}, {
			key: 'getItem',
			value: function getItem() {
				return this.internalMonitor.getItem();
			}
		}, {
			key: 'getDropResult',
			value: function getDropResult() {
				return this.internalMonitor.getDropResult();
			}
		}, {
			key: 'didDrop',
			value: function didDrop() {
				return this.internalMonitor.didDrop();
			}
		}, {
			key: 'getInitialClientOffset',
			value: function getInitialClientOffset() {
				return this.internalMonitor.getInitialClientOffset();
			}
		}, {
			key: 'getInitialSourceClientOffset',
			value: function getInitialSourceClientOffset() {
				return this.internalMonitor.getInitialSourceClientOffset();
			}
		}, {
			key: 'getSourceClientOffset',
			value: function getSourceClientOffset() {
				return this.internalMonitor.getSourceClientOffset();
			}
		}, {
			key: 'getClientOffset',
			value: function getClientOffset() {
				return this.internalMonitor.getClientOffset();
			}
		}, {
			key: 'getDifferenceFromInitialOffset',
			value: function getDifferenceFromInitialOffset() {
				return this.internalMonitor.getDifferenceFromInitialOffset();
			}
		}]);

		return TargetMonitor;
	}();

	function createTargetMonitor(manager) {
		return new TargetMonitor(manager);
	}

/***/ },

/***/ 1615:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports.default = createTargetConnector;

	var _wrapConnectorHooks = __webpack_require__(1607);

	var _wrapConnectorHooks2 = _interopRequireDefault(_wrapConnectorHooks);

	var _areOptionsEqual = __webpack_require__(1609);

	var _areOptionsEqual2 = _interopRequireDefault(_areOptionsEqual);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function createTargetConnector(backend) {
		var currentHandlerId = void 0;

		var currentDropTargetNode = void 0;
		var currentDropTargetOptions = void 0;
		var disconnectCurrentDropTarget = void 0;

		function reconnectDropTarget() {
			if (disconnectCurrentDropTarget) {
				disconnectCurrentDropTarget();
				disconnectCurrentDropTarget = null;
			}

			if (currentHandlerId && currentDropTargetNode) {
				disconnectCurrentDropTarget = backend.connectDropTarget(currentHandlerId, currentDropTargetNode, currentDropTargetOptions);
			}
		}

		function receiveHandlerId(handlerId) {
			if (handlerId === currentHandlerId) {
				return;
			}

			currentHandlerId = handlerId;
			reconnectDropTarget();
		}

		var hooks = (0, _wrapConnectorHooks2.default)({
			dropTarget: function connectDropTarget(node, options) {
				if (node === currentDropTargetNode && (0, _areOptionsEqual2.default)(options, currentDropTargetOptions)) {
					return;
				}

				currentDropTargetNode = node;
				currentDropTargetOptions = options;

				reconnectDropTarget();
			}
		});

		return {
			receiveHandlerId: receiveHandlerId,
			hooks: hooks
		};
	}

/***/ },

/***/ 1616:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _provider = __webpack_require__(1617);

	Object.defineProperty(exports, 'Provider', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_provider).default;
	  }
	});

	var _header = __webpack_require__(1619);

	Object.defineProperty(exports, 'Header', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_header).default;
	  }
	});

	var _body = __webpack_require__(1625);

	Object.defineProperty(exports, 'Body', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_body).default;
	  }
	});

	var _bodyRow = __webpack_require__(1626);

	Object.defineProperty(exports, 'BodyRow', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_bodyRow).default;
	  }
	});

	var _evaluateFormatters = __webpack_require__(1621);

	Object.defineProperty(exports, 'evaluateFormatters', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_evaluateFormatters).default;
	  }
	});

	var _evaluateTransforms = __webpack_require__(1622);

	Object.defineProperty(exports, 'evaluateTransforms', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_evaluateTransforms).default;
	  }
	});

	var _mergeProps = __webpack_require__(1623);

	Object.defineProperty(exports, 'mergeProps', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_mergeProps).default;
	  }
	});

	var _columnsAreEqual = __webpack_require__(1627);

	Object.defineProperty(exports, 'columnsAreEqual', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_columnsAreEqual).default;
	  }
	});

	var _resolveRowKey = __webpack_require__(1629);

	Object.defineProperty(exports, 'resolveRowKey', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_resolveRowKey).default;
	  }
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ },

/***/ 1617:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _types = __webpack_require__(1618);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var componentDefaults = _types.tableDefaults.components;

	// TODO: shouldComponentUpdate

	var Provider = function (_React$Component) {
	  _inherits(Provider, _React$Component);

	  function Provider() {
	    _classCallCheck(this, Provider);

	    return _possibleConstructorReturn(this, (Provider.__proto__ || Object.getPrototypeOf(Provider)).apply(this, arguments));
	  }

	  _createClass(Provider, [{
	    key: 'getChildContext',
	    value: function getChildContext() {
	      var _props = this.props,
	          columns = _props.columns,
	          components = _props.components;


	      return {
	        columns: columns,
	        components: {
	          table: components.table || componentDefaults.table,
	          header: _extends({}, componentDefaults.header, components.header),
	          body: _extends({}, componentDefaults.body, components.body)
	        }
	      };
	    }
	  }, {
	    key: 'render',
	    value: function render() {
	      var _props2 = this.props,
	          columns = _props2.columns,
	          components = _props2.components,
	          children = _props2.children,
	          props = _objectWithoutProperties(_props2, ['columns', 'components', 'children']);

	      return _react2.default.createElement(components.table || _types.tableDefaults.components.table, props, children);
	    }
	  }]);

	  return Provider;
	}(_react2.default.Component);

	exports.default = Provider;

	 false ? Provider.propTypes = _extends({}, _types.tableTypes, {
	  children: _propTypes2.default.any
	}) : void 0;
	Provider.defaultProps = _extends({}, _types.tableDefaults);
	Provider.childContextTypes = _types.tableContextTypes;

/***/ },

/***/ 1618:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.tableDefaults = exports.tableHeaderRowDefaults = exports.tableHeaderRowTypes = exports.tableHeaderContextTypes = exports.tableHeaderTypes = exports.tableBodyRowDefaults = exports.tableBodyRowTypes = exports.tableBodyContextTypes = exports.tableBodyDefaults = exports.tableBodyTypes = exports.tableContextTypes = exports.tableTypes = undefined;

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var arrayOfObjectColumns = _propTypes2.default.arrayOf(_propTypes2.default.shape({
	  header: _propTypes2.default.shape({
	    label: _propTypes2.default.string,
	    transforms: _propTypes2.default.arrayOf(_propTypes2.default.func),
	    formatters: _propTypes2.default.arrayOf(_propTypes2.default.func),
	    props: _propTypes2.default.object
	  }),
	  cell: _propTypes2.default.shape({
	    property: _propTypes2.default.oneOfType([_propTypes2.default.number, _propTypes2.default.string]),
	    transforms: _propTypes2.default.arrayOf(_propTypes2.default.func),
	    formatters: _propTypes2.default.arrayOf(_propTypes2.default.func),
	    props: _propTypes2.default.object
	  })
	}));
	var arrayOfArrayColumns = _propTypes2.default.arrayOf(_propTypes2.default.array);
	var rowsType = _propTypes2.default.oneOfType([arrayOfObjectColumns, arrayOfArrayColumns]);
	var rowKeyType = _propTypes2.default.oneOfType([_propTypes2.default.func, _propTypes2.default.string]);
	var rowDataType = _propTypes2.default.oneOfType([_propTypes2.default.array, _propTypes2.default.object]);
	var tableTypes = {
	  columns: _propTypes2.default.array.isRequired,
	  components: _propTypes2.default.object
	};
	var tableContextTypes = {
	  columns: _propTypes2.default.array.isRequired,
	  components: _propTypes2.default.object
	};
	var tableBodyDefaults = {
	  onRow: function onRow() {}
	};
	var tableBodyTypes = {
	  onRow: _propTypes2.default.func,
	  rows: rowsType.isRequired,
	  rowKey: rowKeyType
	};
	var tableBodyContextTypes = {
	  columns: _propTypes2.default.array.isRequired,
	  components: _propTypes2.default.object
	};
	var tableBodyRowDefaults = {
	  onRow: function onRow() {
	    return {};
	  }
	};
	var tableBodyRowTypes = {
	  columns: _propTypes2.default.array.isRequired,
	  components: _propTypes2.default.object,
	  onRow: _propTypes2.default.func,
	  rowIndex: _propTypes2.default.number.isRequired,
	  rowData: rowDataType.isRequired,
	  rowKey: _propTypes2.default.string.isRequired
	};
	var tableHeaderTypes = {
	  headerRows: _propTypes2.default.arrayOf(arrayOfObjectColumns),
	  children: _propTypes2.default.any
	};
	var tableHeaderContextTypes = {
	  columns: _propTypes2.default.array.isRequired,
	  components: _propTypes2.default.object
	};
	var tableHeaderRowDefaults = {
	  onRow: function onRow() {
	    return {};
	  }
	};
	var tableHeaderRowTypes = {
	  components: _propTypes2.default.object,
	  onRow: _propTypes2.default.func,
	  rowIndex: _propTypes2.default.number.isRequired,
	  rowData: rowDataType.isRequired
	};
	var tableDefaults = {
	  components: {
	    table: 'table',
	    header: {
	      wrapper: 'thead',
	      row: 'tr',
	      cell: 'th'
	    },
	    body: {
	      wrapper: 'tbody',
	      row: 'tr',
	      cell: 'td'
	    }
	  }
	};

	exports.tableTypes = tableTypes;
	exports.tableContextTypes = tableContextTypes;
	exports.tableBodyTypes = tableBodyTypes;
	exports.tableBodyDefaults = tableBodyDefaults;
	exports.tableBodyContextTypes = tableBodyContextTypes;
	exports.tableBodyRowTypes = tableBodyRowTypes;
	exports.tableBodyRowDefaults = tableBodyRowDefaults;
	exports.tableHeaderTypes = tableHeaderTypes;
	exports.tableHeaderContextTypes = tableHeaderContextTypes;
	exports.tableHeaderRowTypes = tableHeaderRowTypes;
	exports.tableHeaderRowDefaults = tableHeaderRowDefaults;
	exports.tableDefaults = tableDefaults;

/***/ },

/***/ 1619:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _types = __webpack_require__(1618);

	var _headerRow = __webpack_require__(1620);

	var _headerRow2 = _interopRequireDefault(_headerRow);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var Header = function (_React$Component) {
	  _inherits(Header, _React$Component);

	  // eslint-disable-line max-len, react/prefer-stateless-function
	  function Header(props) {
	    _classCallCheck(this, Header);

	    var _this = _possibleConstructorReturn(this, (Header.__proto__ || Object.getPrototypeOf(Header)).call(this, props));

	    _this.ref = null;
	    return _this;
	  }

	  _createClass(Header, [{
	    key: 'render',
	    value: function render() {
	      var _this2 = this;

	      var _props = this.props,
	          children = _props.children,
	          headerRows = _props.headerRows,
	          onRow = _props.onRow,
	          props = _objectWithoutProperties(_props, ['children', 'headerRows', 'onRow']);

	      var _context = this.context,
	          components = _context.components,
	          columns = _context.columns;


	      props.ref = function (header) {
	        _this2.ref = header;
	      };

	      // If headerRows aren't passed, default to bodyColumns as header rows
	      return _react2.default.createElement(components.header.wrapper, props, [(headerRows || [columns]).map(function (rowData, rowIndex) {
	        return _react2.default.createElement(_headerRow2.default, {
	          key: rowIndex + '-header-row',
	          components: components.header,
	          onRow: onRow,
	          rowData: rowData,
	          rowIndex: rowIndex
	        });
	      })].concat(children));
	    }
	  }, {
	    key: 'getRef',
	    value: function getRef() {
	      return this.ref;
	    }
	  }]);

	  return Header;
	}(_react2.default.Component);

	 false ? Header.propTypes = _types.tableHeaderTypes : void 0;
	Header.contextTypes = _types.tableHeaderContextTypes;

	exports.default = Header;

/***/ },

/***/ 1620:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _evaluateFormatters = __webpack_require__(1621);

	var _evaluateFormatters2 = _interopRequireDefault(_evaluateFormatters);

	var _evaluateTransforms = __webpack_require__(1622);

	var _evaluateTransforms2 = _interopRequireDefault(_evaluateTransforms);

	var _mergeProps = __webpack_require__(1623);

	var _mergeProps2 = _interopRequireDefault(_mergeProps);

	var _types = __webpack_require__(1618);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var HeaderRow = function HeaderRow(_ref) {
	  var rowData = _ref.rowData,
	      rowIndex = _ref.rowIndex,
	      components = _ref.components,
	      onRow = _ref.onRow;
	  return _react2.default.createElement(components.row, onRow(rowData, { rowIndex: rowIndex }), rowData.map(function (column, columnIndex) {
	    var property = column.property,
	        _column$header = column.header,
	        header = _column$header === undefined ? {} : _column$header,
	        _column$props = column.props,
	        props = _column$props === undefined ? {} : _column$props;

	    var evaluatedProperty = property || header && header.property;
	    var label = header.label,
	        _header$transforms = header.transforms,
	        transforms = _header$transforms === undefined ? [] : _header$transforms,
	        _header$formatters = header.formatters,
	        formatters = _header$formatters === undefined ? [] : _header$formatters;

	    var extraParameters = {
	      columnIndex: columnIndex,
	      property: evaluatedProperty,
	      column: column
	    };
	    var transformedProps = (0, _evaluateTransforms2.default)(transforms, label, extraParameters);

	    if (!transformedProps) {
	      console.warn('Table.Header - Failed to receive a transformed result'); // eslint-disable-line max-len, no-console
	    }

	    return _react2.default.createElement(components.cell, _extends({
	      key: columnIndex + '-header'
	    }, (0, _mergeProps2.default)(props, header && header.props, transformedProps)), transformedProps.children || (0, _evaluateFormatters2.default)(formatters)(label, extraParameters));
	  }));
	};
	HeaderRow.defaultProps = _types.tableHeaderRowDefaults;
	 false ? HeaderRow.propTypes = _types.tableHeaderRowTypes : void 0;

	exports.default = HeaderRow;

/***/ },

/***/ 1621:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function evaluateFormatters(formatters) {
	  return function (value, extra) {
	    return formatters.reduce(function (parameters, formatter) {
	      return {
	        value: formatter(parameters.value, parameters.extra),
	        extra: extra
	      };
	    }, { value: value, extra: extra }).value;
	  };
	}

	exports.default = evaluateFormatters;

/***/ },

/***/ 1622:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _isFunction2 = __webpack_require__(302);

	var _isFunction3 = _interopRequireDefault(_isFunction2);

	var _mergeProps = __webpack_require__(1623);

	var _mergeProps2 = _interopRequireDefault(_mergeProps);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

	function evaluateTransforms() {
	  var transforms = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
	  var value = arguments[1];
	  var extraParameters = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

	  if (false) {
	    if (!transforms.every(_isFunction3.default)) {
	      throw new Error('All transforms weren\'t functions!', transforms);
	    }
	  }

	  if (transforms.length === 0) {
	    return {};
	  }

	  return _mergeProps2.default.apply(undefined, _toConsumableArray(transforms.map(function (transform) {
	    return transform(value, extraParameters);
	  })));
	}

	exports.default = evaluateTransforms;

/***/ },

/***/ 1623:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _mergeWith2 = __webpack_require__(1624);

	var _mergeWith3 = _interopRequireDefault(_mergeWith2);

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _classnames = __webpack_require__(171);

	var _classnames2 = _interopRequireDefault(_classnames);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

	function mergePropPair() {
	  for (var _len = arguments.length, props = Array(_len), _key = 0; _key < _len; _key++) {
	    props[_key] = arguments[_key];
	  }

	  var firstProps = props[0];
	  var restProps = props.slice(1);

	  if (!restProps.length) {
	    return (0, _mergeWith3.default)({}, firstProps);
	  }

	  // Avoid mutating the first prop collection
	  return _mergeWith3.default.apply(undefined, [(0, _mergeWith3.default)({}, firstProps)].concat(_toConsumableArray(restProps), [function (a, b, key) {
	    if (key === 'children') {
	      // Children have to be merged in reverse order for Reactabular
	      // logic to work.
	      return _extends({}, b, a);
	    }

	    if (key === 'className') {
	      // Process class names through classNames to merge properly
	      // as a string.
	      return (0, _classnames2.default)(a, b);
	    }

	    return undefined;
	  }]));
	}

	exports.default = mergePropPair;

/***/ },

/***/ 1624:
/***/ function(module, exports, __webpack_require__) {

	var baseMerge = __webpack_require__(520),
	    createAssigner = __webpack_require__(558);

	/**
	 * This method is like `_.merge` except that it accepts `customizer` which
	 * is invoked to produce the merged values of the destination and source
	 * properties. If `customizer` returns `undefined`, merging is handled by the
	 * method instead. The `customizer` is invoked with six arguments:
	 * (objValue, srcValue, key, object, source, stack).
	 *
	 * **Note:** This method mutates `object`.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Object
	 * @param {Object} object The destination object.
	 * @param {...Object} sources The source objects.
	 * @param {Function} customizer The function to customize assigned values.
	 * @returns {Object} Returns `object`.
	 * @example
	 *
	 * function customizer(objValue, srcValue) {
	 *   if (_.isArray(objValue)) {
	 *     return objValue.concat(srcValue);
	 *   }
	 * }
	 *
	 * var object = { 'a': [1], 'b': [2] };
	 * var other = { 'a': [3], 'b': [4] };
	 *
	 * _.mergeWith(object, other, customizer);
	 * // => { 'a': [1, 3], 'b': [2, 4] }
	 */
	var mergeWith = createAssigner(function(object, source, srcIndex, customizer) {
	  baseMerge(object, source, srcIndex, customizer);
	});

	module.exports = mergeWith;


/***/ },

/***/ 1625:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _isFunction2 = __webpack_require__(302);

	var _isFunction3 = _interopRequireDefault(_isFunction2);

	var _isEqual2 = __webpack_require__(927);

	var _isEqual3 = _interopRequireDefault(_isEqual2);

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _types = __webpack_require__(1618);

	var _bodyRow = __webpack_require__(1626);

	var _bodyRow2 = _interopRequireDefault(_bodyRow);

	var _resolveRowKey = __webpack_require__(1629);

	var _resolveRowKey2 = _interopRequireDefault(_resolveRowKey);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var Body = function (_React$Component) {
	  _inherits(Body, _React$Component);

	  function Body(props) {
	    _classCallCheck(this, Body);

	    var _this = _possibleConstructorReturn(this, (Body.__proto__ || Object.getPrototypeOf(Body)).call(this, props));

	    _this.ref = null;
	    return _this;
	  }

	  _createClass(Body, [{
	    key: 'shouldComponentUpdate',
	    value: function shouldComponentUpdate(nextProps, nextState, nextContext) {
	      // eslint-disable-line no-unused-vars
	      // Skip checking props against `onRow` since that can be bound at render().
	      // That's not particularly good practice but you never know how the users
	      // prefer to define the handler.

	      // Check for wrapper based override.
	      var components = nextContext.components;


	      if (components && components.body && components.body.wrapper.shouldComponentUpdate) {
	        if ((0, _isFunction3.default)(components.body.wrapper.shouldComponentUpdate)) {
	          return components.body.wrapper.shouldComponentUpdate.call(this, nextProps, nextState, nextContext);
	        }

	        return true;
	      }

	      return !((0, _isEqual3.default)(omitOnRow(this.props), omitOnRow(nextProps)) && (0, _isEqual3.default)(this.context, nextContext));
	    }
	  }, {
	    key: 'render',
	    value: function render() {
	      var _this2 = this;

	      var _props = this.props,
	          onRow = _props.onRow,
	          rows = _props.rows,
	          rowKey = _props.rowKey,
	          props = _objectWithoutProperties(_props, ['onRow', 'rows', 'rowKey']);

	      var _context = this.context,
	          columns = _context.columns,
	          components = _context.components;


	      props.ref = function (body) {
	        _this2.ref = body;
	      };

	      return _react2.default.createElement(components.body.wrapper, props, rows.map(function (rowData, index) {
	        var rowIndex = rowData._index || index;
	        var key = (0, _resolveRowKey2.default)({ rowData: rowData, rowIndex: rowIndex, rowKey: rowKey });

	        return _react2.default.createElement(_bodyRow2.default, {
	          key: key,
	          components: components.body,
	          onRow: onRow,
	          rowKey: key,
	          rowIndex: rowIndex,
	          rowData: rowData,
	          columns: columns
	        });
	      }));
	    }
	  }, {
	    key: 'getRef',
	    value: function getRef() {
	      return this.ref;
	    }
	  }]);

	  return Body;
	}(_react2.default.Component);

	 false ? Body.propTypes = _types.tableBodyTypes : void 0;
	Body.defaultProps = _types.tableBodyDefaults;
	Body.contextTypes = _types.tableBodyContextTypes;

	function omitOnRow(props) {
	  var onRow = props.onRow,
	      ret = _objectWithoutProperties(props, ['onRow']); // eslint-disable-line no-unused-vars

	  return ret;
	}

	exports.default = Body;

/***/ },

/***/ 1626:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _isFunction2 = __webpack_require__(302);

	var _isFunction3 = _interopRequireDefault(_isFunction2);

	var _isEqual2 = __webpack_require__(927);

	var _isEqual3 = _interopRequireDefault(_isEqual2);

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _columnsAreEqual = __webpack_require__(1627);

	var _columnsAreEqual2 = _interopRequireDefault(_columnsAreEqual);

	var _evaluateFormatters = __webpack_require__(1621);

	var _evaluateFormatters2 = _interopRequireDefault(_evaluateFormatters);

	var _evaluateTransforms = __webpack_require__(1622);

	var _evaluateTransforms2 = _interopRequireDefault(_evaluateTransforms);

	var _mergeProps = __webpack_require__(1623);

	var _mergeProps2 = _interopRequireDefault(_mergeProps);

	var _types = __webpack_require__(1618);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var BodyRow = function (_React$Component) {
	  _inherits(BodyRow, _React$Component);

	  function BodyRow() {
	    _classCallCheck(this, BodyRow);

	    return _possibleConstructorReturn(this, (BodyRow.__proto__ || Object.getPrototypeOf(BodyRow)).apply(this, arguments));
	  }

	  _createClass(BodyRow, [{
	    key: 'shouldComponentUpdate',
	    value: function shouldComponentUpdate(nextProps) {
	      // eslint-disable-line no-unused-vars
	      var previousProps = this.props;

	      // Check for row based override.
	      var components = nextProps.components;


	      if (components && components.row && components.row.shouldComponentUpdate) {
	        if ((0, _isFunction3.default)(components.row.shouldComponentUpdate)) {
	          return components.row.shouldComponentUpdate.call(this, nextProps);
	        }

	        return true;
	      }

	      return !((0, _columnsAreEqual2.default)(previousProps.columns, nextProps.columns) && (0, _isEqual3.default)(previousProps.rowData, nextProps.rowData));
	    }
	  }, {
	    key: 'render',
	    value: function render() {
	      var _props = this.props,
	          columns = _props.columns,
	          components = _props.components,
	          onRow = _props.onRow,
	          rowKey = _props.rowKey,
	          rowIndex = _props.rowIndex,
	          rowData = _props.rowData;


	      return _react2.default.createElement(components.row, onRow(rowData, { rowIndex: rowIndex, rowKey: rowKey }), columns.map(function (column, columnIndex) {
	        var property = column.property,
	            cell = column.cell,
	            props = column.props;

	        var evaluatedProperty = property || cell && cell.property;

	        var _ref = cell || {},
	            _ref$transforms = _ref.transforms,
	            transforms = _ref$transforms === undefined ? [] : _ref$transforms,
	            _ref$formatters = _ref.formatters,
	            formatters = _ref$formatters === undefined ? [] : _ref$formatters; // TODO: test against this case


	        var extraParameters = {
	          columnIndex: columnIndex,
	          property: evaluatedProperty,
	          column: column,
	          rowData: rowData,
	          rowIndex: rowIndex,
	          rowKey: rowKey
	        };
	        var transformed = (0, _evaluateTransforms2.default)(transforms, rowData[evaluatedProperty], extraParameters);

	        if (!transformed) {
	          console.warn('Table.Body - Failed to receive a transformed result'); // eslint-disable-line max-len, no-console
	        }

	        return _react2.default.createElement(components.cell, _extends({
	          key: columnIndex + '-cell'
	        }, (0, _mergeProps2.default)(props, cell && cell.props, transformed)), transformed.children || (0, _evaluateFormatters2.default)(formatters)(rowData['_' + evaluatedProperty] || rowData[evaluatedProperty], extraParameters));
	      }));
	    }
	  }]);

	  return BodyRow;
	}(_react2.default.Component);

	BodyRow.defaultProps = _types.tableBodyRowDefaults;
	 false ? BodyRow.propTypes = _types.tableBodyRowTypes : void 0;

	exports.default = BodyRow;

/***/ },

/***/ 1627:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _isEqualWith2 = __webpack_require__(1628);

	var _isEqualWith3 = _interopRequireDefault(_isEqualWith2);

	var _isFunction2 = __webpack_require__(302);

	var _isFunction3 = _interopRequireDefault(_isFunction2);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function columnsAreEqual(oldColumns, newColumns) {
	  return (0, _isEqualWith3.default)(oldColumns, newColumns, function (a, b) {
	    if ((0, _isFunction3.default)(a) && (0, _isFunction3.default)(b)) {
	      return true;
	    }

	    return undefined;
	  });
	}

	exports.default = columnsAreEqual;

/***/ },

/***/ 1628:
/***/ function(module, exports, __webpack_require__) {

	var baseIsEqual = __webpack_require__(825);

	/**
	 * This method is like `_.isEqual` except that it accepts `customizer` which
	 * is invoked to compare values. If `customizer` returns `undefined`, comparisons
	 * are handled by the method instead. The `customizer` is invoked with up to
	 * six arguments: (objValue, othValue [, index|key, object, other, stack]).
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to compare.
	 * @param {*} other The other value to compare.
	 * @param {Function} [customizer] The function to customize comparisons.
	 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
	 * @example
	 *
	 * function isGreeting(value) {
	 *   return /^h(?:i|ello)$/.test(value);
	 * }
	 *
	 * function customizer(objValue, othValue) {
	 *   if (isGreeting(objValue) && isGreeting(othValue)) {
	 *     return true;
	 *   }
	 * }
	 *
	 * var array = ['hello', 'goodbye'];
	 * var other = ['hi', 'goodbye'];
	 *
	 * _.isEqualWith(array, other, customizer);
	 * // => true
	 */
	function isEqualWith(value, other, customizer) {
	  customizer = typeof customizer == 'function' ? customizer : undefined;
	  var result = customizer ? customizer(value, other) : undefined;
	  return result === undefined ? baseIsEqual(value, other, undefined, customizer) : !!result;
	}

	module.exports = isEqualWith;


/***/ },

/***/ 1629:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _isArray2 = __webpack_require__(282);

	var _isArray3 = _interopRequireDefault(_isArray2);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function resolveRowKey(_ref) {
	  var rowData = _ref.rowData,
	      rowIndex = _ref.rowIndex,
	      rowKey = _ref.rowKey;

	  if (typeof rowKey === 'function') {
	    return rowKey({ rowData: rowData, rowIndex: rowIndex }) + '-row';
	  } else if (false) {
	    // Arrays cannot have rowKeys by definition so we have to go by index there.
	    if (!(0, _isArray3.default)(rowData) && rowData[rowKey] === undefined) {
	      console.warn( // eslint-disable-line no-console
	      'Table.Body - Missing valid rowKey!', rowData, rowKey);
	    }
	  }

	  if (rowData[rowKey] === 0) {
	    return rowData[rowKey] + '-row';
	  }

	  return (rowData[rowKey] || rowIndex) + '-row';
	}

	exports.default = resolveRowKey;

/***/ },

/***/ 1630:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.Row = exports.Header = exports.move = exports.moveRows = exports.moveLabels = exports.moveChildrenLabels = exports.draggableRow = undefined;

	var _draggableRow = __webpack_require__(1631);

	var _draggableRow2 = _interopRequireDefault(_draggableRow);

	var _header = __webpack_require__(1632);

	var _header2 = _interopRequireDefault(_header);

	var _row = __webpack_require__(1633);

	var _row2 = _interopRequireDefault(_row);

	var _move = __webpack_require__(1634);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.draggableRow = _draggableRow2.default;
	exports.moveChildrenLabels = _move.moveChildrenLabels;
	exports.moveLabels = _move.moveLabels;
	exports.moveRows = _move.moveRows;
	exports.move = _move.move;
	exports.Header = _header2.default;
	exports.Row = _row2.default;

/***/ },

/***/ 1631:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _propTypes = __webpack_require__(94);

	var _propTypes2 = _interopRequireDefault(_propTypes);

	var _reactDnd = __webpack_require__(1568);

	var _reactDom = __webpack_require__(151);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	var DragTypes = {
	  ROW: 'row'
	};
	var rowSource = {
	  canDrag: function canDrag(_ref) {
	    var rowId = _ref.rowId,
	        onCanMove = _ref.onCanMove;

	    return onCanMove ? onCanMove({ rowId: rowId }) : true;
	  },
	  beginDrag: function beginDrag(_ref2) {
	    var rowId = _ref2.rowId,
	        onMoveStart = _ref2.onMoveStart;

	    onMoveStart && onMoveStart({ rowId: rowId });

	    return { rowId: rowId };
	  },
	  endDrag: function endDrag(_ref3) {
	    var rowId = _ref3.rowId,
	        onMoveEnd = _ref3.onMoveEnd;

	    onMoveEnd && onMoveEnd({ rowId: rowId });
	  }
	};
	var rowTarget = {
	  hover: function hover(targetProps, monitor) {
	    var targetRowId = targetProps.rowId;
	    var sourceProps = monitor.getItem();
	    var sourceRowId = sourceProps.rowId;

	    // TODO: check if sourceRowId and targetRowId are undefined -> warning
	    if (sourceRowId !== targetRowId) {
	      targetProps.onMove({ sourceRowId: sourceRowId, targetRowId: targetRowId });
	    }
	  }
	};

	var dragSource = (0, _reactDnd.DragSource)( // eslint-disable-line new-cap
	DragTypes.ROW, rowSource, function (connect) {
	  return {
	    connectDragSource: connect.dragSource()
	  };
	});
	var dropTarget = (0, _reactDnd.DropTarget)( // eslint-disable-line new-cap
	DragTypes.ROW, rowTarget, function (connect) {
	  return {
	    connectDropTarget: connect.dropTarget()
	  };
	});
	var DraggableRow = function DraggableRow(_ref4) {
	  var _parent = _ref4._parent,
	      connectDragSource = _ref4.connectDragSource,
	      connectDropTarget = _ref4.connectDropTarget,
	      onCanMove = _ref4.onCanMove,
	      onMoveStart = _ref4.onMoveStart,
	      onMoveEnd = _ref4.onMoveEnd,
	      onMove = _ref4.onMove,
	      rowId = _ref4.rowId,
	      props = _objectWithoutProperties(_ref4, ['_parent', 'connectDragSource', 'connectDropTarget', 'onCanMove', 'onMoveStart', 'onMoveEnd', 'onMove', 'rowId']);

	  return (
	    // If you want to drag using a handle instead, then you need to pass
	    // connectDragSource to a customized cell (DndCell) through React
	    // context and wrap the handle there. You also need to annotate
	    // this function using connectDragPreview.
	    //
	    // https://github.com/gaearon/react-dnd/releases/tag/v2.0.0 - ref trick
	    _react2.default.createElement(_parent, _extends({}, props, {
	      ref: function ref(e) {
	        if (!e) {
	          return;
	        }

	        var node = (0, _reactDom.findDOMNode)(e);

	        // Chaining is not allowed
	        // https://github.com/gaearon/react-dnd/issues/305#issuecomment-164490014
	        connectDropTarget(node);
	        connectDragSource(node);
	      }
	    }))
	  );
	};
	 false ? DraggableRow.propTypes = {
	  _parent: _propTypes2.default.oneOfType([_propTypes2.default.func, _propTypes2.default.node]).isRequired,
	  connectDragSource: _propTypes2.default.func.isRequired,
	  connectDropTarget: _propTypes2.default.func.isRequired,
	  onMove: _propTypes2.default.func.isRequired,
	  onCanMove: _propTypes2.default.func,
	  onMoveStart: _propTypes2.default.func,
	  onMoveEnd: _propTypes2.default.func,
	  rowId: _propTypes2.default.any.isRequired
	} : void 0;

	var SourceTargetDraggableRow = dragSource(dropTarget(DraggableRow));

	var draggableRow = function draggableRow(_parent) {
	  function draggable(children) {
	    return _react2.default.createElement(SourceTargetDraggableRow, _extends({
	      _parent: _parent
	    }, children));
	  }

	  // Copy possible shouldComponentUpdate over or otherwise features
	  // like virtualization won't work.
	  draggable.shouldComponentUpdate = _parent.shouldComponentUpdate;

	  return draggable;
	};

	exports.default = draggableRow;

/***/ },

/***/ 1632:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _react = __webpack_require__(89);

	var _react2 = _interopRequireDefault(_react);

	var _reactDnd = __webpack_require__(1568);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

	var DragTypes = {
	  HEADER: 'header'
	};
	var headerSource = {
	  beginDrag: function beginDrag(_ref) {
	    var label = _ref.label;

	    return { label: label };
	  }
	};
	var headerTarget = {
	  hover: function hover(targetProps, monitor) {
	    var targetLabel = targetProps.label;
	    var sourceProps = monitor.getItem();
	    var sourceLabel = sourceProps.label;

	    if (sourceLabel !== targetLabel && targetProps.onMove) {
	      targetProps.onMove({ sourceLabel: sourceLabel, targetLabel: targetLabel });
	    }
	  },
	  drop: function drop(targetProps) {
	    if (targetProps.onFinishMove) {
	      targetProps.onFinishMove();
	    }
	  }
	};

	var dragSource = (0, _reactDnd.DragSource)( // eslint-disable-line new-cap
	DragTypes.HEADER, headerSource, function (connect) {
	  return {
	    connectDragSource: connect.dragSource()
	  };
	});
	var dropTarget = (0, _reactDnd.DropTarget)( // eslint-disable-line new-cap
	DragTypes.HEADER, headerTarget, function (connect) {
	  return {
	    connectDropTarget: connect.dropTarget()
	  };
	});
	var header = function header(_ref2) {
	  var connectDragSource = _ref2.connectDragSource,
	      connectDropTarget = _ref2.connectDropTarget,
	      label = _ref2.label,
	      children = _ref2.children,
	      onMove = _ref2.onMove,
	      onFinishMove = _ref2.onFinishMove,
	      props = _objectWithoutProperties(_ref2, ['connectDragSource', 'connectDropTarget', 'label', 'children', 'onMove', 'onFinishMove']);

	  return connectDragSource(connectDropTarget(_react2.default.createElement(
	    'th',
	    props,
	    children
	  )));
	};

	exports.default = dragSource(dropTarget(header));

/***/ },

/***/ 1633:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _draggableRow = __webpack_require__(1631);

	var _draggableRow2 = _interopRequireDefault(_draggableRow);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = (0, _draggableRow2.default)('tr');

/***/ },

/***/ 1634:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.move = exports.moveRows = exports.moveLabels = exports.moveChildrenLabels = undefined;

	var _findIndex4 = __webpack_require__(846);

	var _findIndex5 = _interopRequireDefault(_findIndex4);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function moveChildrenLabels(columns, _ref) {
	  var sourceLabel = _ref.sourceLabel,
	      targetLabel = _ref.targetLabel;

	  var sourceIndex = (0, _findIndex5.default)(columns, function (column) {
	    return (0, _findIndex5.default)(column.children, { header: { label: sourceLabel } }) >= 0;
	  });

	  if (sourceIndex < 0) {
	    return null;
	  }

	  var targetIndex = (0, _findIndex5.default)(columns, function (column) {
	    return (0, _findIndex5.default)(column.children, { header: { label: targetLabel } }) >= 0;
	  });

	  if (targetIndex < 0) {
	    return null;
	  }

	  // Allow drag and drop only within the same column
	  if (sourceIndex !== targetIndex) {
	    return null;
	  }

	  var movedChildren = moveLabels(columns[sourceIndex].children, {
	    sourceLabel: sourceLabel, targetLabel: targetLabel
	  });

	  if (!movedChildren) {
	    return null;
	  }

	  return {
	    target: sourceIndex,
	    columns: movedChildren.columns
	  };
	}

	function moveLabels(columns, _ref2) {
	  var sourceLabel = _ref2.sourceLabel,
	      targetLabel = _ref2.targetLabel;

	  if (!columns) {
	    throw new Error('dnd.moveLabels - Missing columns!');
	  }

	  var sourceIndex = (0, _findIndex5.default)(columns, { header: { label: sourceLabel } });

	  if (sourceIndex < 0) {
	    return null;
	  }

	  var targetIndex = (0, _findIndex5.default)(columns, { header: { label: targetLabel } });

	  if (targetIndex < 0) {
	    return null;
	  }

	  var movedColumns = move(columns, sourceIndex, targetIndex);

	  return {
	    source: movedColumns[sourceIndex],
	    target: movedColumns[targetIndex],
	    columns: movedColumns
	  };
	}

	var moveRows = function moveRows() {
	  var _ref3 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
	      sourceRowId = _ref3.sourceRowId,
	      targetRowId = _ref3.targetRowId,
	      _ref3$idField = _ref3.idField,
	      idField = _ref3$idField === undefined ? 'id' : _ref3$idField;

	  return function (rows) {
	    var sourceIndex = (0, _findIndex5.default)(rows, _defineProperty({}, idField, sourceRowId));

	    if (sourceIndex < 0) {
	      return null;
	    }

	    var targetIndex = (0, _findIndex5.default)(rows, _defineProperty({}, idField, targetRowId));

	    if (targetIndex < 0) {
	      return null;
	    }

	    return move(rows, sourceIndex, targetIndex);
	  };
	};

	function move(data, sourceIndex, targetIndex) {
	  // Idea
	  // a, b, c, d, e -> move(b, d) -> a, c, d, b, e
	  // a, b, c, d, e -> move(d, a) -> d, a, b, c, e
	  // a, b, c, d, e -> move(a, d) -> b, c, d, a, e
	  var sourceItem = data[sourceIndex];

	  // 1. detach - a, c, d, e - a, b, c, e, - b, c, d, e
	  var ret = data.slice(0, sourceIndex).concat(data.slice(sourceIndex + 1));

	  // 2. attach - a, c, d, b, e - d, a, b, c, e - b, c, d, a, e
	  return ret.slice(0, targetIndex).concat([sourceItem]).concat(ret.slice(targetIndex));
	}

	exports.moveChildrenLabels = moveChildrenLabels;
	exports.moveLabels = moveLabels;
	exports.moveRows = moveRows;
	exports.move = move;

/***/ },

/***/ 1635:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _resolve = __webpack_require__(1636);

	Object.defineProperty(exports, 'resolve', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_resolve).default;
	  }
	});

	var _nested = __webpack_require__(1637);

	Object.defineProperty(exports, 'nested', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_nested).default;
	  }
	});

	var _byFunction = __webpack_require__(1638);

	Object.defineProperty(exports, 'byFunction', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_byFunction).default;
	  }
	});

	var _countRowSpan = __webpack_require__(1639);

	Object.defineProperty(exports, 'countRowSpan', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_countRowSpan).default;
	  }
	});

	var _columnChildren = __webpack_require__(1640);

	Object.defineProperty(exports, 'columnChildren', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_columnChildren).default;
	  }
	});

	var _headerRows = __webpack_require__(1641);

	Object.defineProperty(exports, 'headerRows', {
	  enumerable: true,
	  get: function get() {
	    return _interopRequireDefault(_headerRows).default;
	  }
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ },

/***/ 1636:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function resolve(_ref) {
	  var columns = _ref.columns,
	      _ref$method = _ref.method,
	      method = _ref$method === undefined ? function () {
	    return function (rowData) {
	      return rowData;
	    };
	  } : _ref$method,
	      _ref$indexKey = _ref.indexKey,
	      indexKey = _ref$indexKey === undefined ? '_index' : _ref$indexKey;

	  if (!columns) {
	    throw new Error('resolve - Missing columns!');
	  }

	  return function () {
	    var rows = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

	    var methodsByColumnIndex = columns.map(function (column) {
	      return method({ column: column });
	    });

	    return rows.map(function (rowData, rowIndex) {
	      var ret = {};

	      columns.forEach(function (column, columnIndex) {
	        var result = methodsByColumnIndex[columnIndex](rowData);

	        delete result.undefined;

	        ret = _extends(_defineProperty({}, indexKey, rowIndex), rowData, ret, result);
	      });

	      return ret;
	    });
	  };
	}

	exports.default = resolve;

/***/ },

/***/ 1637:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _isFunction2 = __webpack_require__(302);

	var _isFunction3 = _interopRequireDefault(_isFunction2);

	var _has2 = __webpack_require__(278);

	var _has3 = _interopRequireDefault(_has2);

	var _get2 = __webpack_require__(370);

	var _get3 = _interopRequireDefault(_get2);

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function nested(_ref) {
	  var column = _ref.column;

	  return function (rowData) {
	    var property = column.property;


	    if (!property) {
	      return {};
	    }

	    // if users provide a custom getter instead of a
	    // path for _.get, use that getter ...
	    if ((0, _isFunction3.default)(property)) {
	      return _extends({}, rowData, _defineProperty({}, property, property(rowData)));
	    }

	    // ... otherwise, make sure property exists, then _.get it
	    if (!(0, _has3.default)(rowData, property)) {
	      return {};
	    }

	    return _extends({}, rowData, _defineProperty({}, property, (0, _get3.default)(rowData, property)));
	  };
	}

	exports.default = nested;

/***/ },

/***/ 1638:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _get2 = __webpack_require__(370);

	var _get3 = _interopRequireDefault(_get2);

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function byFunction(path) {
	  return function (_ref) {
	    var _ref$column = _ref.column,
	        column = _ref$column === undefined ? {} : _ref$column;
	    return function (rowData) {
	      var property = column.property;


	      if (!property) {
	        return rowData;
	      }

	      var value = rowData[property];
	      var resolver = (0, _get3.default)(column, path);
	      var ret = _extends({}, rowData, _defineProperty({}, property, value));

	      if (resolver) {
	        ret['_' + property] = resolver(value, {
	          property: property,
	          rowData: rowData
	        });
	      }

	      return ret;
	    };
	  };
	}

	exports.default = byFunction;

/***/ },

/***/ 1639:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function countRowSpan(columns) {
	  var maximumCount = 0;

	  columns.forEach(function (column) {
	    if (column.children && column.children.length) {
	      maximumCount = Math.max(maximumCount, countRowSpan(column.children));
	    }
	  });

	  return maximumCount + 1;
	}

	exports.default = countRowSpan;

/***/ },

/***/ 1640:
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function columnChildren(_ref) {
	  var columns = _ref.columns,
	      _ref$childrenField = _ref.childrenField,
	      childrenField = _ref$childrenField === undefined ? 'children' : _ref$childrenField;

	  if (!columns) {
	    throw new Error('resolve.columnChildren - Missing columns!');
	  }

	  var ret = [];

	  columns.forEach(function (column) {
	    // If a column has children, skip cell specific configuration
	    if (column[childrenField] && column[childrenField].length) {
	      ret = ret.concat(columnChildren({
	        columns: column[childrenField],
	        childrenField: childrenField
	      }));
	    } else {
	      ret.push(column);
	    }
	  });

	  return ret;
	}

	exports.default = columnChildren;

/***/ },

/***/ 1641:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _omit2 = __webpack_require__(1642);

	var _omit3 = _interopRequireDefault(_omit2);

	var _countRowSpan = __webpack_require__(1639);

	var _countRowSpan2 = _interopRequireDefault(_countRowSpan);

	var _countColSpan = __webpack_require__(1647);

	var _countColSpan2 = _interopRequireDefault(_countColSpan);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

	function resolveHeaderRows(_ref) {
	  var columns = _ref.columns,
	      _ref$childrenField = _ref.childrenField,
	      childrenField = _ref$childrenField === undefined ? 'children' : _ref$childrenField;

	  var resolvedChildren = [];

	  var ret = columns.map(function (column) {
	    var children = column[childrenField];
	    var col = (0, _omit3.default)(column, [childrenField]);

	    if (children && children.length) {
	      resolveHeaderRows({ columns: children, childrenField: childrenField }).forEach(function (cells, depth) {
	        resolvedChildren[depth] = [].concat(_toConsumableArray(resolvedChildren[depth] || []), _toConsumableArray(cells));
	      });

	      return Object.assign({}, col, {
	        props: Object.assign({
	          colSpan: (0, _countColSpan2.default)(children, 0)
	        }, col.props)
	      });
	    }

	    return Object.assign({}, col, {
	      props: Object.assign({
	        rowSpan: (0, _countRowSpan2.default)(columns)
	      }, col.props)
	    });
	  });

	  return resolvedChildren.length ? [ret].concat(resolvedChildren) : [ret];
	}

	exports.default = resolveHeaderRows;

/***/ },

/***/ 1642:
/***/ function(module, exports, __webpack_require__) {

	var arrayMap = __webpack_require__(329),
	    baseClone = __webpack_require__(792),
	    baseUnset = __webpack_require__(1643),
	    castPath = __webpack_require__(281),
	    copyObject = __webpack_require__(552),
	    customOmitClone = __webpack_require__(1646),
	    flatRest = __webpack_require__(852),
	    getAllKeysIn = __webpack_require__(805);

	/** Used to compose bitmasks for cloning. */
	var CLONE_DEEP_FLAG = 1,
	    CLONE_FLAT_FLAG = 2,
	    CLONE_SYMBOLS_FLAG = 4;

	/**
	 * The opposite of `_.pick`; this method creates an object composed of the
	 * own and inherited enumerable property paths of `object` that are not omitted.
	 *
	 * **Note:** This method is considerably slower than `_.pick`.
	 *
	 * @static
	 * @since 0.1.0
	 * @memberOf _
	 * @category Object
	 * @param {Object} object The source object.
	 * @param {...(string|string[])} [paths] The property paths to omit.
	 * @returns {Object} Returns the new object.
	 * @example
	 *
	 * var object = { 'a': 1, 'b': '2', 'c': 3 };
	 *
	 * _.omit(object, ['a', 'c']);
	 * // => { 'b': '2' }
	 */
	var omit = flatRest(function(object, paths) {
	  var result = {};
	  if (object == null) {
	    return result;
	  }
	  var isDeep = false;
	  paths = arrayMap(paths, function(path) {
	    path = castPath(path, object);
	    isDeep || (isDeep = path.length > 1);
	    return path;
	  });
	  copyObject(object, getAllKeysIn(object), result);
	  if (isDeep) {
	    result = baseClone(result, CLONE_DEEP_FLAG | CLONE_FLAT_FLAG | CLONE_SYMBOLS_FLAG, customOmitClone);
	  }
	  var length = paths.length;
	  while (length--) {
	    baseUnset(result, paths[length]);
	  }
	  return result;
	});

	module.exports = omit;


/***/ },

/***/ 1643:
/***/ function(module, exports, __webpack_require__) {

	var castPath = __webpack_require__(281),
	    last = __webpack_require__(1010),
	    parent = __webpack_require__(1644),
	    toKey = __webpack_require__(334);

	/**
	 * The base implementation of `_.unset`.
	 *
	 * @private
	 * @param {Object} object The object to modify.
	 * @param {Array|string} path The property path to unset.
	 * @returns {boolean} Returns `true` if the property is deleted, else `false`.
	 */
	function baseUnset(object, path) {
	  path = castPath(path, object);
	  object = parent(object, path);
	  return object == null || delete object[toKey(last(path))];
	}

	module.exports = baseUnset;


/***/ },

/***/ 1644:
/***/ function(module, exports, __webpack_require__) {

	var baseGet = __webpack_require__(371),
	    baseSlice = __webpack_require__(1645);

	/**
	 * Gets the parent value at `path` of `object`.
	 *
	 * @private
	 * @param {Object} object The object to query.
	 * @param {Array} path The path to get the parent value of.
	 * @returns {*} Returns the parent value.
	 */
	function parent(object, path) {
	  return path.length < 2 ? object : baseGet(object, baseSlice(path, 0, -1));
	}

	module.exports = parent;


/***/ },

/***/ 1645:
/***/ function(module, exports) {

	/**
	 * The base implementation of `_.slice` without an iteratee call guard.
	 *
	 * @private
	 * @param {Array} array The array to slice.
	 * @param {number} [start=0] The start position.
	 * @param {number} [end=array.length] The end position.
	 * @returns {Array} Returns the slice of `array`.
	 */
	function baseSlice(array, start, end) {
	  var index = -1,
	      length = array.length;

	  if (start < 0) {
	    start = -start > length ? 0 : (length + start);
	  }
	  end = end > length ? length : end;
	  if (end < 0) {
	    end += length;
	  }
	  length = start > end ? 0 : ((end - start) >>> 0);
	  start >>>= 0;

	  var result = Array(length);
	  while (++index < length) {
	    result[index] = array[index + start];
	  }
	  return result;
	}

	module.exports = baseSlice;


/***/ },

/***/ 1646:
/***/ function(module, exports, __webpack_require__) {

	var isPlainObject = __webpack_require__(545);

	/**
	 * Used by `_.omit` to customize its `_.cloneDeep` use to only clone plain
	 * objects.
	 *
	 * @private
	 * @param {*} value The value to inspect.
	 * @param {string} key The key of the property to inspect.
	 * @returns {*} Returns the uncloned value or `undefined` to defer cloning to `_.cloneDeep`.
	 */
	function customOmitClone(value) {
	  return isPlainObject(value) ? undefined : value;
	}

	module.exports = customOmitClone;


/***/ },

/***/ 1647:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	function countColSpan(columns, returnCount) {
	  var count = returnCount;
	  if (columns && columns.length > 0) {
	    columns.forEach(function (column) {
	      if (column.children && column.children.length > 0) {
	        count = countColSpan(column.children, count);
	      } else {
	        count += 1;
	      }
	    });
	  }
	  return count;
	}

	exports.default = countColSpan;

/***/ },

/***/ 1702:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	exports['default'] = promiseMiddleware;

	var _fluxStandardAction = __webpack_require__(1703);

	function isPromise(val) {
	  return val && typeof val.then === 'function';
	}

	function promiseMiddleware(_ref) {
	  var dispatch = _ref.dispatch;

	  return function (next) {
	    return function (action) {
	      if (!_fluxStandardAction.isFSA(action)) {
	        return isPromise(action) ? action.then(dispatch) : next(action);
	      }

	      return isPromise(action.payload) ? action.payload.then(function (result) {
	        return dispatch(_extends({}, action, { payload: result }));
	      }, function (error) {
	        return dispatch(_extends({}, action, { payload: error, error: true }));
	      }) : next(action);
	    };
	  };
	}

	module.exports = exports['default'];

/***/ },

/***/ 1703:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;
	exports.isFSA = isFSA;
	exports.isError = isError;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _lodashIsplainobject = __webpack_require__(1704);

	var _lodashIsplainobject2 = _interopRequireDefault(_lodashIsplainobject);

	var validKeys = ['type', 'payload', 'error', 'meta'];

	function isValidKey(key) {
	  return validKeys.indexOf(key) > -1;
	}

	function isFSA(action) {
	  return _lodashIsplainobject2['default'](action) && typeof action.type !== 'undefined' && Object.keys(action).every(isValidKey);
	}

	function isError(action) {
	  return action.error === true;
	}

/***/ },

/***/ 1704:
/***/ function(module, exports, __webpack_require__) {

	/**
	 * lodash 3.2.0 (Custom Build) <https://lodash.com/>
	 * Build: `lodash modern modularize exports="npm" -o ./`
	 * Copyright 2012-2015 The Dojo Foundation <http://dojofoundation.org/>
	 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
	 * Copyright 2009-2015 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
	 * Available under MIT license <https://lodash.com/license>
	 */
	var baseFor = __webpack_require__(1705),
	    isArguments = __webpack_require__(386),
	    keysIn = __webpack_require__(1706);

	/** `Object#toString` result references. */
	var objectTag = '[object Object]';

	/**
	 * Checks if `value` is object-like.
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
	 */
	function isObjectLike(value) {
	  return !!value && typeof value == 'object';
	}

	/** Used for native method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Used to resolve the [`toStringTag`](http://ecma-international.org/ecma-262/6.0/#sec-object.prototype.tostring)
	 * of values.
	 */
	var objToString = objectProto.toString;

	/**
	 * The base implementation of `_.forIn` without support for callback
	 * shorthands and `this` binding.
	 *
	 * @private
	 * @param {Object} object The object to iterate over.
	 * @param {Function} iteratee The function invoked per iteration.
	 * @returns {Object} Returns `object`.
	 */
	function baseForIn(object, iteratee) {
	  return baseFor(object, iteratee, keysIn);
	}

	/**
	 * Checks if `value` is a plain object, that is, an object created by the
	 * `Object` constructor or one with a `[[Prototype]]` of `null`.
	 *
	 * **Note:** This method assumes objects created by the `Object` constructor
	 * have no inherited enumerable properties.
	 *
	 * @static
	 * @memberOf _
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a plain object, else `false`.
	 * @example
	 *
	 * function Foo() {
	 *   this.a = 1;
	 * }
	 *
	 * _.isPlainObject(new Foo);
	 * // => false
	 *
	 * _.isPlainObject([1, 2, 3]);
	 * // => false
	 *
	 * _.isPlainObject({ 'x': 0, 'y': 0 });
	 * // => true
	 *
	 * _.isPlainObject(Object.create(null));
	 * // => true
	 */
	function isPlainObject(value) {
	  var Ctor;

	  // Exit early for non `Object` objects.
	  if (!(isObjectLike(value) && objToString.call(value) == objectTag && !isArguments(value)) ||
	      (!hasOwnProperty.call(value, 'constructor') && (Ctor = value.constructor, typeof Ctor == 'function' && !(Ctor instanceof Ctor)))) {
	    return false;
	  }
	  // IE < 9 iterates inherited properties before own properties. If the first
	  // iterated property is an object's own property then there are no inherited
	  // enumerable properties.
	  var result;
	  // In most environments an object's own properties are iterated before
	  // its inherited properties. If the last iterated property is an object's
	  // own property then there are no inherited enumerable properties.
	  baseForIn(value, function(subValue, key) {
	    result = key;
	  });
	  return result === undefined || hasOwnProperty.call(value, result);
	}

	module.exports = isPlainObject;


/***/ },

/***/ 1705:
/***/ function(module, exports) {

	/**
	 * lodash 3.0.3 (Custom Build) <https://lodash.com/>
	 * Build: `lodash modularize exports="npm" -o ./`
	 * Copyright 2012-2016 The Dojo Foundation <http://dojofoundation.org/>
	 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
	 * Copyright 2009-2016 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
	 * Available under MIT license <https://lodash.com/license>
	 */

	/**
	 * The base implementation of `baseForIn` and `baseForOwn` which iterates
	 * over `object` properties returned by `keysFunc` invoking `iteratee` for
	 * each property. Iteratee functions may exit iteration early by explicitly
	 * returning `false`.
	 *
	 * @private
	 * @param {Object} object The object to iterate over.
	 * @param {Function} iteratee The function invoked per iteration.
	 * @param {Function} keysFunc The function to get the keys of `object`.
	 * @returns {Object} Returns `object`.
	 */
	var baseFor = createBaseFor();

	/**
	 * Creates a base function for methods like `_.forIn`.
	 *
	 * @private
	 * @param {boolean} [fromRight] Specify iterating from right to left.
	 * @returns {Function} Returns the new base function.
	 */
	function createBaseFor(fromRight) {
	  return function(object, iteratee, keysFunc) {
	    var index = -1,
	        iterable = Object(object),
	        props = keysFunc(object),
	        length = props.length;

	    while (length--) {
	      var key = props[fromRight ? length : ++index];
	      if (iteratee(iterable[key], key, iterable) === false) {
	        break;
	      }
	    }
	    return object;
	  };
	}

	module.exports = baseFor;


/***/ },

/***/ 1706:
/***/ function(module, exports, __webpack_require__) {

	/**
	 * lodash 3.0.8 (Custom Build) <https://lodash.com/>
	 * Build: `lodash modern modularize exports="npm" -o ./`
	 * Copyright 2012-2015 The Dojo Foundation <http://dojofoundation.org/>
	 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
	 * Copyright 2009-2015 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
	 * Available under MIT license <https://lodash.com/license>
	 */
	var isArguments = __webpack_require__(386),
	    isArray = __webpack_require__(387);

	/** Used to detect unsigned integer values. */
	var reIsUint = /^\d+$/;

	/** Used for native method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Used as the [maximum length](https://people.mozilla.org/~jorendorff/es6-draft.html#sec-number.max_safe_integer)
	 * of an array-like value.
	 */
	var MAX_SAFE_INTEGER = 9007199254740991;

	/**
	 * Checks if `value` is a valid array-like index.
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
	 * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
	 */
	function isIndex(value, length) {
	  value = (typeof value == 'number' || reIsUint.test(value)) ? +value : -1;
	  length = length == null ? MAX_SAFE_INTEGER : length;
	  return value > -1 && value % 1 == 0 && value < length;
	}

	/**
	 * Checks if `value` is a valid array-like length.
	 *
	 * **Note:** This function is based on [`ToLength`](https://people.mozilla.org/~jorendorff/es6-draft.html#sec-tolength).
	 *
	 * @private
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
	 */
	function isLength(value) {
	  return typeof value == 'number' && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
	}

	/**
	 * Checks if `value` is the [language type](https://es5.github.io/#x8) of `Object`.
	 * (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
	 *
	 * @static
	 * @memberOf _
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
	 * @example
	 *
	 * _.isObject({});
	 * // => true
	 *
	 * _.isObject([1, 2, 3]);
	 * // => true
	 *
	 * _.isObject(1);
	 * // => false
	 */
	function isObject(value) {
	  // Avoid a V8 JIT bug in Chrome 19-20.
	  // See https://code.google.com/p/v8/issues/detail?id=2291 for more details.
	  var type = typeof value;
	  return !!value && (type == 'object' || type == 'function');
	}

	/**
	 * Creates an array of the own and inherited enumerable property names of `object`.
	 *
	 * **Note:** Non-object values are coerced to objects.
	 *
	 * @static
	 * @memberOf _
	 * @category Object
	 * @param {Object} object The object to query.
	 * @returns {Array} Returns the array of property names.
	 * @example
	 *
	 * function Foo() {
	 *   this.a = 1;
	 *   this.b = 2;
	 * }
	 *
	 * Foo.prototype.c = 3;
	 *
	 * _.keysIn(new Foo);
	 * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
	 */
	function keysIn(object) {
	  if (object == null) {
	    return [];
	  }
	  if (!isObject(object)) {
	    object = Object(object);
	  }
	  var length = object.length;
	  length = (length && isLength(length) &&
	    (isArray(object) || isArguments(object)) && length) || 0;

	  var Ctor = object.constructor,
	      index = -1,
	      isProto = typeof Ctor == 'function' && Ctor.prototype === object,
	      result = Array(length),
	      skipIndexes = length > 0;

	  while (++index < length) {
	    result[index] = (index + '');
	  }
	  for (var key in object) {
	    if (!(skipIndexes && isIndex(key, length)) &&
	        !(key == 'constructor' && (isProto || !hasOwnProperty.call(object, key)))) {
	      result.push(key);
	    }
	  }
	  return result;
	}

	module.exports = keysIn;


/***/ }

});